// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:get_it/get_it.dart';
import 'package:medivic/controllers/notificationController.dart';
import 'package:medivic/providers/appointmentSetupProvider.dart';
import 'package:medivic/providers/authProvider.dart';
import 'package:medivic/providers/blogsProvider.dart';
import 'package:medivic/providers/consultationProvider.dart';
import 'package:medivic/providers/doctorProvider.dart';
import 'package:medivic/providers/doctorsDataProvider.dart';
import 'package:medivic/providers/hospitalDataProvider.dart';
import 'package:medivic/providers/illnessOptionsProvider.dart';
import 'package:medivic/providers/medicineCourseProvider.dart';
import 'package:medivic/providers/savedBlogsProvider.dart';
import 'package:medivic/providers/searchProvider.dart';
import 'package:medivic/providers/userProvider.dart';
import 'package:medivic/services/api/algoliaApi.dart';
import 'package:medivic/services/authentication/authentication.dart';
import 'package:medivic/services/authentication/firebaseAuthService.dart';
import 'package:medivic/services/pushNotification/pushNotificationService.dart';
import 'package:medivic/utils/inactivityTimer.dart';

GetIt locator = GetIt.instance;

void setupLocator() {
  locator.registerLazySingleton<AuthService>(() => FirebaseAuthService());
  locator.registerLazySingleton<InactivityTimer>(() => InactivityTimer());
  locator.registerLazySingleton<UserProvider>(() => UserProvider());
  locator.registerLazySingleton<SearchProvider>(() => SearchProvider());
  locator.registerLazySingleton<MedicineCourseProvider>(
      () => MedicineCourseProvider());
  locator.registerLazySingleton<SavedBlogsProvider>(() => SavedBlogsProvider());
  locator.registerLazySingleton<ConsultationProvider>(
      () => ConsultationProvider());
  locator.registerLazySingleton<DoctorProvider>(() => DoctorProvider());
  locator.registerLazySingleton<DoctorDataProvider>(() => DoctorDataProvider());
  locator.registerLazySingleton<HospitalDataProvider>(
      () => HospitalDataProvider());
  locator.registerLazySingleton<BlogsProvider>(() => BlogsProvider());
  locator.registerLazySingleton<AppointmentSetupProvider>(
      () => AppointmentSetupProvider());
  locator.registerLazySingleton<AlgoliaApi>(() => AlgoliaApi());
  locator.registerLazySingleton<PushNotificationService>(
      () => PushNotificationService());
  locator.registerLazySingleton<NotificationController>(
      () => NotificationController());
  locator.registerLazySingleton<IllnessOptionsProvider>(
      () => IllnessOptionsProvider());
  locator.registerLazySingleton<UIAuthProvider>(() => UIAuthProvider());
}

abstract class LocatorService {
  static InactivityTimer inActivityTimer()=>locator<InactivityTimer>();
  static FirebaseAuthService authService() => locator<AuthService>();

  static SearchProvider searchProvider() => locator<SearchProvider>();

  static UserProvider userProvider() => locator<UserProvider>();

  static DoctorProvider doctorProvider() => locator<DoctorProvider>();

  static DoctorDataProvider doctorDataProvider() =>
      locator<DoctorDataProvider>();

  static HospitalDataProvider hospitalDataProvider() =>
      locator<HospitalDataProvider>();

  static BlogsProvider blogsProvider() => locator<BlogsProvider>();

  static MedicineCourseProvider medicineCourseProvider() =>
      locator<MedicineCourseProvider>();

  static SavedBlogsProvider savedBlogsProvider() =>
      locator<SavedBlogsProvider>();

  static ConsultationProvider consultationProvider() =>
      locator<ConsultationProvider>();

  static AppointmentSetupProvider appointmentSetupProvider() =>
      locator<AppointmentSetupProvider>();

  static AlgoliaApi algoliaApi() => locator<AlgoliaApi>();

  static PushNotificationService pushNotificationService() =>
      locator<PushNotificationService>();

  static NotificationController notificationController() =>
      locator<NotificationController>();

  static IllnessOptionsProvider illnessOptionsProvider() =>
      locator<IllnessOptionsProvider>();

  static UIAuthProvider uiAuthProvider() => locator<UIAuthProvider>();

  /// Clears all the data from the registered providers
  static void reset() {
    locator.resetLazySingleton<ConsultationProvider>();
    locator.resetLazySingleton<DoctorProvider>();
    locator.resetLazySingleton<DoctorDataProvider>();
    locator.resetLazySingleton<MedicineCourseProvider>();
    locator.resetLazySingleton<SavedBlogsProvider>();
    locator.resetLazySingleton<SearchProvider>();
    locator.resetLazySingleton<UserProvider>();
  }
}
