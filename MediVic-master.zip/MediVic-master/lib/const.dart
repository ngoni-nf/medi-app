import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:medivic/utils/hex_color.dart';

const themeColor = Color(0xfff5a623);
const primaryColor = Color(0xff203152);
const greyColor = Color(0xffaeaeae);
const greyColor2 = Color(0xffE8E8E8);
const appBarColor = Color.fromRGBO(47, 167, 20, 1);
const darkBlueColor = Color.fromRGBO(35, 54, 128, 1);
const greenColor = Color.fromRGBO(76, 176, 80, 1);
const colorHex = '#233680';
const fontMontserrat = "Montserrat";

const TextStyle styleAppbarTitle = TextStyle(
    color: Colors.white,
    fontWeight: FontWeight.w400,
    fontFamily: fontMontserrat,
    fontSize: 16);

const String urlAboutUs = 'https://www.medivic.co.za/about-us';
const String urlFAQs = 'https://www.medivic.co.za/mobile-faqs';
const String urlConsultTerms =
    'https://www.medivic.co.za/consult-terms-conditions';
const String urlStdTerms =
    'https://www.medivic.co.za/standard-terms-and-conditions';
const String urlPrivacy = 'https://www.medivic.co.za/privacy-policy';