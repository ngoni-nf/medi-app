import 'package:flutter/material.dart';

import '../const.dart';

class AppButton extends StatelessWidget {
  const AppButton(
      {this.text, this.onPressed, this.fontSize, this.padding, this.bgColor});

  final String text;
  final Function onPressed;
  final double fontSize;
  final double padding;
  final Color bgColor;

  @override
  Widget build(BuildContext context) {
    return RaisedButton(
      padding: EdgeInsets.all(padding ?? 10),
      onPressed: onPressed,
      child: Text(
        text,
        style: TextStyle(
          fontWeight: FontWeight.normal,
          fontSize: fontSize ?? 18,
          fontFamily: fontMontserrat,
          color: Colors.white,
        ),
      ),
      color: bgColor ?? appBarColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(30.0),
        side: BorderSide(color: bgColor ?? appBarColor),
      ),
    );
  }
}

class ProgressButton extends StatelessWidget {
  const ProgressButton(
    this.buttonText,
    this.onPressed,
    this.progress,
    this.progressText, {
    this.padding = 16,
    this.fontSize = 20,
  });

  final String buttonText;
  final Function onPressed;
  final bool progress;
  final String progressText;
  final double padding, fontSize;

  @override
  Widget build(BuildContext context) {
    return progress
        ? Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const CircularProgressIndicator(backgroundColor: appBarColor),
                const SizedBox(width: 16),
                Text(progressText,style: TextStyle(fontFamily: fontMontserrat),),
              ],
            ),
          )
        : AppButton(
            text: buttonText,
            onPressed: onPressed,
            fontSize: fontSize,
            padding: padding,
          );
  }
}
