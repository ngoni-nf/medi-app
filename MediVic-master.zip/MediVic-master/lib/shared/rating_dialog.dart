import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:provider/provider.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

import '../const.dart';
import '../locator.dart';

class RatingDialog extends StatefulWidget {
  final String doctorId;
  final double rating;
  final String comment;

  const RatingDialog({Key key, this.doctorId, this.rating, this.comment})
      : super(key: key);

  @override
  _RatingDialogState createState() => _RatingDialogState();
}

class _RatingDialogState extends State<RatingDialog> {
  double rating;
  String comments;
  bool _isLoading = false;

  Map<String, dynamic> giveRating(
      String docId, patientId, String comment, double rating) {
    return {
      'doctorId': docId,
      'patientId': patientId,
      'rating': rating,
      'comment': comment,
      'createdAt': DateTime.now(),
    };
  }

  dialogContent() {
    return SingleChildScrollView(
      child: StatefulBuilder(
        builder: (context, setState) {
          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const Text(
                  'Rating',
                  style: TextStyle(fontFamily: fontMontserrat),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(
                  height: 10,
                ),
                TextFormField(
                  initialValue: widget.comment,
                  decoration: const InputDecoration(
                      hintText:
                          'Comment',
                      hintStyle: TextStyle(fontFamily: fontMontserrat)),
                  onChanged: (value) {
                    comments = value;
                  },
                ),
                const SizedBox(
                  height: 10,
                ),
                SmoothStarRating(
                  allowHalfRating: false,
                  onRated: (v) {
                    rating = v;
                  },
                  starCount: 5,
                  rating: widget.rating != null && widget.rating > 0
                      ? widget.rating
                      : 0,
                  size: 40.0,
                  isReadOnly: false,
                  color: appBarColor,
                  borderColor: appBarColor,
                  spacing: 0.0,
                ),
                Visibility(
                    visible: _isLoading,
                    child: const CircularProgressIndicator(
                      backgroundColor: appBarColor,
                    )),
                const SizedBox(
                  width: 30,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    FlatButton(
                      child: const Text('Cancel',
                          style: TextStyle(fontFamily: fontMontserrat)),
                      onPressed: _isLoading
                          ? null
                          : () {
                              Navigator.of(context).pop();
                            },
                    ),
                    FlatButton(
                      child: const Text('Submit',
                          style: TextStyle(fontFamily: fontMontserrat)),
                      onPressed: _isLoading
                          ? null
                          : () async {
                              if (comments.isNotEmpty && rating > 0) {
                                setState(() {
                                  _isLoading = true;
                                });
                                await FirestoreService.giveRatings(
                                        giveRating(
                                            widget.doctorId,
                                            LocatorService.userProvider()
                                                .user
                                                .uid,
                                            comments,
                                            rating),
                                        doctorId: widget.doctorId)
                                    .then((value) {
                                      setState(() {
                                        _isLoading = false;
                                      });
                                      Fluttertoast.showToast(
                                          msg: 'Successfully save');
                                      Navigator.of(context).pop();
                                    })
                                    .timeout(const Duration(seconds: 30))
                                    .catchError((error) {
                                      setState(() {
                                        _isLoading = false;
                                      });
                                      Fluttertoast.showToast(msg: 'Something went wrong');
                                    });
                              } else
                                Fluttertoast.showToast(
                                    msg: 'Please give rating and comment');
                            },
                    )
                  ],
                )
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    rating = widget.rating ?? 0;
    comments = widget.comment ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(Consts.padding),
      ),
      elevation: 0.0,
      backgroundColor: Colors.white,
      child: dialogContent(),
    );
  }
}

class Consts {
  Consts._();

  static const double padding = 16.0;
  static const double avatarRadius = 66.0;
}
