// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/shared/specialityContainer.dart';
import 'package:medivic/themes/themeGuide.dart';

import '../const.dart';

///
/// ## `Description`
///
/// Returns the layout widget for the list of doctors.
///
class DoctorListItem extends StatelessWidget {
  const DoctorListItem({Key key, this.doctor}) : super(key: key);

  final Doctor doctor;

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(10),
      height: 156,
      child: Container(
        padding: const EdgeInsets.all(5.0),
        decoration: BoxDecoration(
          color: _theme.accentColor,
          borderRadius: ThemeGuide.borderRadius,
          boxShadow: const [
            BoxShadow(
              color: Color.fromRGBO(220, 220, 220, 0.6),
              blurRadius: 10,
              spreadRadius: 2,
              offset: Offset(0.0, 2.0),
            ),
          ],
        ),
        child: Row(
          children: <Widget>[
            Container(
              height: 100,
              width: 90,
              decoration: BoxDecoration(
                borderRadius: ThemeGuide.borderRadius,
                color: Colors.black12,
                image: DecorationImage(
                  image: CachedNetworkImageProvider(
                      doctor.imageUrl ?? 'https://via.placeholder.com/100'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 5,
                  horizontal: 10,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Text(
                      '${AppStrings.dr} ' + doctor.name,
                      style: _theme.textTheme.subtitle1.copyWith(
                        fontWeight: FontWeight.w500,
                        fontFamily: fontMontserrat,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Flexible(
                      child: Text(
                        '${AppStrings.exp}: ' +
                            doctor.experience +
                            ' ${AppStrings.years}',
                        style: _theme.textTheme.bodyText1.copyWith(
                          fontSize: _theme.textTheme.caption.fontSize,
                          fontFamily: fontMontserrat,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Flexible(
                      child: Text(
                        '${doctor.address.street ?? ''} ${doctor.address.city ?? ''} ${doctor.address.state ?? ''} ${doctor.address.country ?? ''}',
                        style: _theme.textTheme.caption.copyWith(
                          color: _theme.disabledColor,
                          fontFamily: fontMontserrat,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    SpecialityContainer.small(
                      speciality: doctor.specialities[0].toUpperCase(),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              height: 55,
              // width: 55,
              decoration: BoxDecoration(
                color: Theme.of(context).disabledColor.withOpacity(0.15),
                borderRadius: ThemeGuide.borderRadius,
              ),
              child: Center(
                child: Text(
                  '${Config.CURRENCY_SYMBOL.isNotEmpty ? Config.CURRENCY_SYMBOL : Config.CURRENCY}${doctor.fee ?? ' '}',
                  style: _theme.textTheme.subtitle1.copyWith(
                    fontWeight: FontWeight.w500,
                    fontFamily: fontMontserrat,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
