// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/shared/authScreenWidgets/authSreenWidgets.dart';
import 'package:medivic/themes/themeGuide.dart';
import 'package:medivic/utils/validators.dart';

class ForgotPasswordForm extends StatefulWidget {
  const ForgotPasswordForm({Key key}) : super(key: key);

  @override
  _ForgotPasswordFormState createState() => _ForgotPasswordFormState();
}

class _ForgotPasswordFormState extends State<ForgotPasswordForm> {
  String email;
  bool _isLoading = false;
  String errorText = '';
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Forgot Password',
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              AppStrings.forgotPassword,
              style: Theme.of(context).textTheme.headline6,
            ),
            const SizedBox(
              height: 10,
            ),
            ClipRRect(
              borderRadius: ThemeGuide.borderRadius,
              child: Form(
                key: _formKey,
                child: TextFormField(
                  maxLines: 1,
                  onChanged: (val) => email = val,
                  decoration: const InputDecoration(
                    hintText: AppStrings.email,
                  ),
                  validator: validateEmail,
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Flexible(
              child: Text(
                AppStrings.resetPasswordMessage,
                style: Theme.of(context).textTheme.caption,
                textAlign: TextAlign.center,
              ),
            ),
            ShowError(
              text: errorText,
            ),
            Submit(
              color: appBarColor,
              isLoading: _isLoading,
              lable: AppStrings.submit,
              onPress: () => submit(),
            ),
          ],
        ),
      ),
    );
  }

  String validateEmail(String val) {
    if (val.isEmpty) {
      return AppStrings.invalidEmailEmpty;
    }

    if (Validator.isEmailValid(val)) {
      return null;
    }
    return AppStrings.invalidEmailErrorText;
  }

  Future<void> submit() async {
    if (_formKey.currentState.validate()) {
      try {
        setState(() {
          _isLoading = !_isLoading;
          errorText = '';
        });

        // Send password reset email
        await LocatorService.authService().sendPasswordResetEmail(email).then((_) {
          Fluttertoast.showToast(msg: AppStrings.resetLinkSentMessage);
          Navigator.of(context).pop();
        });

        setState(() {
          _isLoading = !_isLoading;
          errorText = '';
        });
      } catch (e) {
        log('It is not listening');
        setState(() {
          _isLoading = !_isLoading;
          errorText = e.message.toString();
        });
      }
    }
  }
}
