import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:medivic/const.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/services/api/firestoreService.dart';

class DialogAddDocument extends StatefulWidget {
  @override
  _DialogAddDocumentState createState() => _DialogAddDocumentState();
}

class _DialogAddDocumentState extends State<DialogAddDocument> {
  PickedFile pickedFile;
  File filePicker;
  String fileName;
  bool isUploading = false, isValidFile = false;
  TextEditingController controllerName = TextEditingController();
  TextEditingController controllerDescription = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      child: Container(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                    child: Text(
                  'File Upload',
                  style: TextStyle(
                      fontFamily: fontMontserrat,
                      color: appBarColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                )),
                SizedBox(
                  height: 20,
                ),
                TextFormField(
                  controller: controllerName,
                  decoration: const InputDecoration(labelText: 'File Name'),
                ),
                SizedBox(
                  height: 10,
                ),
                TextFormField(
                  controller: controllerDescription,
                  decoration: const InputDecoration(labelText: 'Description'),
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    SizedBox(
                      height: 30,
                      child: RaisedButton(
                        onPressed: () => filePick(),
                        child: Text(
                          'Pick',
                          style: TextStyle(
                              fontFamily: fontMontserrat, color: Colors.white),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    if (!isUploading)
                      SizedBox(
                        height: 30,
                        child: RaisedButton(
                          onPressed:
                              !isValidFile ? null : () => uploadDocumentNew(),
                          child: Text(
                            'Upload',
                            style: TextStyle(
                                fontFamily: fontMontserrat,
                                color: Colors.white),
                          ),
                        ),
                      )
                    else
                      const CircularProgressIndicator(
                        backgroundColor: darkBlueColor,
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void pickFile() async {
    if (isUploading) return;

    pickedFile = await ImagePicker().getImage(source: ImageSource.gallery);
    setState(() {
      fileName = pickedFile.path.split('/').last;
      controllerName.text = fileName;
    });
  }

  void filePick() async {
    if (isUploading) return;
    filePicker = await FilePicker.getFile(
      type: FileType.custom,
      allowedExtensions: ['.jpg', '.pdf','.png'],
    );
    fileName = filePicker.path.split('/').last;
    if (fileName.contains('png') ||
        fileName.contains('jpg') ||
        fileName.contains('pdf') ||
        fileName.contains('jpeg')) {
      setState(() {
        controllerName.text = fileName;
        isValidFile = true;
      });
    } else {
      Fluttertoast.showToast(msg: 'You can upload only image and pdf');
      setState(() {
        isValidFile = false;
      });
    }
  }

  void uploadDocumentNew() async {
    if (filePicker != null) {
      fileName = controllerName.text;
      setState(() {
        isUploading = true;
      });
      String userId = LocatorService.userProvider().user.uid;
      bool isUploaded = await FirestoreService.uploadDocument(
          userId, File(filePicker.path), fileName);
      if (isUploaded) {
        Fluttertoast.showToast(msg: 'File uploaded successfully');
        Navigator.pop(context, true);
      } else {
        Fluttertoast.showToast(
            msg: 'Something happend wrong. Please try again');
        setState(() {
          isUploading = false;
        });
      }
    }
  }

  void uploadDocument() async {
    if (pickedFile != null) {
      fileName = controllerName.text;
      setState(() {
        isUploading = true;
      });
      String userId = LocatorService.userProvider().user.uid;
      bool isUploaded = await FirestoreService.uploadDocument(
          userId, File(pickedFile.path), fileName);
      if (isUploaded) {
        Fluttertoast.showToast(msg: 'File uploaded successfully');
        Navigator.pop(context, true);
      } else {
        Fluttertoast.showToast(
            msg: 'Something happend wrong. Please try again');
        setState(() {
          isUploading = false;
        });
      }
    }
  }
}
