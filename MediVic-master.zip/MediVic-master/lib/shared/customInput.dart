// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:medivic/const.dart';

/// Input Class that renders an Input Text field.
/// Takes in a `placeholder` to label the field.
class CustomInput extends StatelessWidget {
  const CustomInput({
    Key key,
    @required this.placeholder,
    @required this.onChange,
    this.validator,
    this.data,
    this.keyboardType = TextInputType.text,
    this.prefixText,
    this.inputFormatters,
    this.icon,
    this.controller,
    this.iconAsset,
    this.isEnable = true,
  }) : super(key: key);

  final String placeholder, prefixText, data;
  final String iconAsset;
  final Function validator;
  final Function onChange;
  final TextInputType keyboardType;
  final List<TextInputFormatter> inputFormatters;
  final IconData icon;
  final TextEditingController controller;
  final bool isEnable;

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);

    bool obscureText;
    if (placeholder.toString().toLowerCase() == 'password' ||
        placeholder.toString().toLowerCase() == 'confirm password') {
      obscureText = true;
    } else {
      obscureText = false;
    }

    return Container(
      margin: const EdgeInsets.only(top: 10.0),
      padding: const EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        color: _theme.inputDecorationTheme.fillColor,
        borderRadius: BorderRadius.circular(30.0),
      ),
      child: TextFormField(
        initialValue: data,
        controller: controller,
        inputFormatters: inputFormatters,
        validator: validator,
        onChanged: onChange,
        autocorrect: false,
        keyboardType: keyboardType,
        cursorColor: _theme.cursorColor,
        autofocus: false,
        enabled: isEnable,
        obscureText: obscureText,
        style: const TextStyle(
          fontSize: 16.0,
          fontWeight: FontWeight.w500,
          fontFamily: fontMontserrat,
          color: darkBlueColor,
        ),
        textCapitalization: TextCapitalization.none,
        decoration: InputDecoration(
          errorMaxLines: 2,
          prefixIcon: Container(
            width: 20,
            margin: const EdgeInsets.only(right: 10.0),
            // decoration: BoxDecoration(
            //   // borderRadius: BorderRadius.circular(30.0),
            //   border: Border.all(
            //     color: Colors.black38,
            //   ),
            //   shape: BoxShape.circle,
            // ),
            child: Image.asset(
              iconAsset ?? 'lib/assets/icons/form/age.png',
            ),
          ),
          prefixStyle: const TextStyle(
              fontSize: 16.0,
              color: Colors.black54,
              fontWeight: FontWeight.w600,
              fontFamily: fontMontserrat),
          prefixText: prefixText,
          border: InputBorder.none,
          hintText: placeholder,
          hintStyle: const TextStyle(
            fontSize: 16.0,
            fontFamily: fontMontserrat,
            color: darkBlueColor,
          ),
          contentPadding: const EdgeInsets.all(10.0),
        ),
      ),
    );
  }
}
