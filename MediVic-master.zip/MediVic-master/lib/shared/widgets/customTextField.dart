import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:medivic/const.dart';
import 'package:medivic/themes/themeGuide.dart';

class CustomTextField extends StatelessWidget {
  const CustomTextField({
    Key key,
    this.data,
    this.hint,
    this.lableText,
    this.onChange,
    this.iconData,
    this.myfocusnode,
    this.maxLines,
    this.keyboardType = TextInputType.text,
    this.validator,
    this.inputFormatters,
    this.isEnable = true,
    this.controller,
  }) : super(key: key);

  final String lableText;
  final String data, hint;
  final void Function(String) onChange;
  final IconData iconData;
  final Function validator;
  final List<TextInputFormatter> inputFormatters;
  final int maxLines;
  final TextInputType keyboardType;
  final bool isEnable;
  final TextEditingController controller;
  final FocusNode myfocusnode;

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: ClipRRect(
        borderRadius: ThemeGuide.borderRadius,
        child: TextFormField(
          initialValue: data,
          validator: validator,
          enabled: isEnable,
          inputFormatters: inputFormatters,
          cursorColor: _theme.cursorColor,
          textInputAction: TextInputAction.done,
          maxLines: maxLines ?? 1,
          onChanged: onChange,
          focusNode: myfocusnode,
          textAlignVertical: TextAlignVertical.center,
          keyboardType: keyboardType,
          controller: controller,
          style: const TextStyle(color: Colors.black, fontSize: 18, fontFamily: fontMontserrat),
          decoration: InputDecoration(
            labelText: lableText??'',
            // hintText: hint ?? '',
            errorStyle: const TextStyle(
              fontFamily: fontMontserrat,color: Colors.red,
            ),
            hintStyle: const TextStyle(fontFamily: fontMontserrat),
            // prefixIcon: Icon(
            //   iconData,
            // ),
          ),
        ),
      ),
    );
  }
}