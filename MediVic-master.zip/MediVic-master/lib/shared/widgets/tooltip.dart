import 'package:flutter/material.dart';

class ToolTip extends StatelessWidget {
  ToolTip({this.child, this.message});

  final Widget child;
  final String message;
  final GlobalKey _toolTipKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      key: _toolTipKey,
      child: GestureDetector(
        child: child,
        onTap: () {
          final dynamic tooltip = _toolTipKey.currentState;
          tooltip.ensureTooltipVisible();
        },
      ),
      message: message,
    );
  }
}
