// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:medivic/const.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/controllers/uiController.dart';
import 'package:medivic/shared/widgets/illnessOptionsModal.dart';
import 'package:flutter/material.dart';
import 'package:medivic/screens/home/categoryOptions.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:medivic/themes/themeGuide.dart';
import 'package:medivic/locator.dart';

class CategoryOptionsModal extends StatelessWidget {
  final choiceList =  const CategoryOptions().choiceList;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.choose + ' ' + AppStrings.illness),
        backgroundColor:  appBarColor,
        actions: <Widget>[
          FlatButton(
            child: const Text(AppStrings.seeAll),
            onPressed: () {
              NavigationController.navigator.pop();
              LocatorService.illnessOptionsProvider().setRouteTo = () {};
              UiController.showModal(context, IllnessOptionsModal());
            },
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(color: Colors.white10),
        child: ListView.builder(
          physics: const BouncingScrollPhysics(),
          itemCount: choiceList.length,
          itemBuilder: (context, i) {
            return _buildItem(context, choiceList[i]);
          },
        ),
      ),
    );
  }

  Widget _buildItem(BuildContext context, Map<String, String> obj) {
    return GestureDetector(
      onTap: () {
        LocatorService.consultationProvider().setTitle = obj['heading'];
        Navigator.of(context).pop();
      },
      child: Container(
        margin: ThemeGuide.padding,
        padding: ThemeGuide.padding10,
        decoration: ThemeGuide.boxDecorationBlack,
        child: Row(
          children: <Widget>[
            SvgPicture.asset(
              obj['svgUrl'],
              fit: BoxFit.contain,
              height: 80,
            ),
            const SizedBox(width: 20),
            Text(
              obj['heading'],
              style: Theme.of(context).textTheme.headline6,
            ),
          ],
        ),
      ),
    );
  }
}
