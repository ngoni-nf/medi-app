import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:medivic/const.dart';
import 'package:webview_flutter/webview_flutter.dart';

class WebViewScreen extends StatefulWidget {
  final String url;
  final String title;

  const WebViewScreen({Key key, @required this.url, @required this.title}) : super(key: key);

  @override
  _WebViewScreenState createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  bool isLoading;

  @override
  void initState() {
    super.initState();
    isLoading = true;
  }

  @override
  Widget build(BuildContext context) {
    return WebviewScaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: appBarColor,
        title: Text(
          widget.title,
          style: styleAppbarTitle,
          maxLines: 2,
        ),
      ), url: widget.url,
      // body: Stack(
      //   children: [
      //     WebView(
      //       initialUrl: widget.url,
      //       javascriptMode: JavascriptMode.unrestricted,
      //       gestureNavigationEnabled: true,
      //       onPageFinished: (url) {
      //         setState(() {
      //           isLoading = false;
      //         });
      //       },
      //     ),
      //     if (isLoading)
      //       const Center(
      //         child: CircularProgressIndicator(
      //           backgroundColor: greenColor,
      //         ),
      //       )
      //     else
      //       Stack(),
      //   ],
      // ),
    );
  }
}
