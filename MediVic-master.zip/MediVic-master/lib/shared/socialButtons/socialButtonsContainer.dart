// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:medivic/shared/socialButtons/socialButtonLong.dart';
import 'package:flutter/material.dart';

class SocialButtonsContainer extends StatelessWidget {
  const SocialButtonsContainer({
    Key key,
    this.googleOnPress,
    this.facebookOnPress,
    this.otpOnPress,
    this.googleLable = '',
    this.facebookLable = '',
    this.otpLable = '',
    this.isGoogleVisiable,
    this.isFbVisiable,
    this.isOtpVisiable,
  }) : super(key: key);

  final Function googleOnPress, facebookOnPress, otpOnPress;
  final String googleLable, facebookLable, otpLable;
  final isGoogleVisiable, isFbVisiable, isOtpVisiable;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Column(
        children: <Widget>[
          Visibility(
            visible: isGoogleVisiable,
            child: GestureDetector(
              onTap: () => googleOnPress(),
              child: SocialButtonLong.google(
                lable: googleLable,
              ),
            ),
          ),
          Visibility(
            visible: isFbVisiable,
            child: GestureDetector(
              onTap: () => facebookOnPress(),
              child: SocialButtonLong.facebook(
                lable: facebookLable,
              ),
            ),
          ),
          Visibility(
            visible: isOtpVisiable,
            child: GestureDetector(
              onTap: () => otpOnPress(),
              child: SocialButtonLong.otp(
                lable: otpLable,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
