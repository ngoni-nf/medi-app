// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:medivic/themes/themeGuide.dart';
import 'package:flutter/material.dart';

class CustomButtonStyle extends StatelessWidget {
  const CustomButtonStyle({
    Key key,
    this.child,
    this.color,
  }) : super(key: key);

  final Widget child;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: color ?? Theme.of(context).primaryColorLight,
        // borderRadius: ThemeGuide.borderRadius,
        borderRadius: BorderRadius.circular(30.0),
      ),
      child: child,
    );
  }
}
