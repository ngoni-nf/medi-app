// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:async';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

///
/// ## Description
///
/// Stores the information about `User`, `User settings` and likely
/// values used for the application in the future.
///
/// Use this class to store data for the application in the local
/// device. (Use only to store small amounts of data)
///
abstract class LocalStorage {
  static Future<void> setString(String key, Object value) async {
    const storage = FlutterSecureStorage();
    await storage.write(key: key, value: value);
  }

  static Future<String> getString(String key) async {
    const storage = FlutterSecureStorage();
    return await storage.read(key: key);
  }

  static Future<Map<String, String>> getAll() async {
    const storage = FlutterSecureStorage();
    return await storage.readAll();
  }

  static Future<void> clear() async {
    const storage = FlutterSecureStorage();
    await storage.deleteAll();
  }

}
