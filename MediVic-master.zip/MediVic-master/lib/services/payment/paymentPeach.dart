import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:medivic/const.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'dart:developer';

import 'package:medivic/locator.dart';

class PaymentPeach extends StatefulWidget {
  @override
  _PaymentPeachState createState() => _PaymentPeachState();
}

class _PaymentPeachState extends State<PaymentPeach> {
  bool isLoading = true;
  String checkoutId;

  FlutterWebviewPlugin flutterWebViewPlugin;
  StreamSubscription<String> _onUrlChanged;
//LIVE params
  String baseUrl = 'https://oppwa.com';
  String bearerToken =
      'Bearer OGFjZGE0Yzk3NTRiMTQzNzAxNzU0YjI2NzY2MzAwZTd8RGo1SDVwYnhYeQ==';
  String entityId = '8acda4c9754b143701754b28246c0120';

//TEST params
  // String baseUrl = 'https://test.oppwa.com';
  // String bearerToken =
  //     'Bearer OGE4Mjk0MTc0ZTczNWQwYzAxNGU3OGNmMjY2YjE3OTR8cXl5ZkhDTjgzZQ==';
  // String entityId = '8a8294174e735d0c014e78cf26461790';
  final String userId = LocatorService.userProvider().user.uid;
  final String userName = LocatorService.userProvider().user.name;
  final String userEmail = LocatorService.userProvider().user.email;
  final String doctorId = LocatorService.consultationProvider().doctor.uid;
  final String amount = LocatorService.consultationProvider().amount.toString();
  final String title = LocatorService.consultationProvider().title;

  @override
  void initState() {
    LocatorService.inActivityTimer().setActivity(false);
    fetchCheckout();
    flutterWebViewPlugin = FlutterWebviewPlugin();

    // Add a listener to on url changed
    _onUrlChanged = flutterWebViewPlugin.onUrlChanged.listen(handleUrlChange);
    super.initState();
  }

  @override
  void dispose() {
    LocatorService.inActivityTimer().setActivity(true);
    _onUrlChanged?.cancel();
    flutterWebViewPlugin.cleanCookies();
    flutterWebViewPlugin?.close();
    flutterWebViewPlugin?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        title: const Text(
          'Payment',
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
      ),
      body: _buildBody(),
    );
  }

  final Set<JavascriptChannel> jsChannels = [
    JavascriptChannel(
        name: 'Print',
        onMessageReceived: (JavascriptMessage message) {
          print(message.message);
        }),
  ].toSet();

  Widget _buildBody() {
    return isLoading
        ? Center(
            child: CircularProgressIndicator(
              backgroundColor: appBarColor,
            ),
          )
        : WebviewScaffold(
            url: Uri.dataFromString(loadHtml(), mimeType: 'text/html')
                .toString(),
          );
  }

  Future<void> handleUrlChange(String url) async {
    if (mounted) {
      log(url, name: 'URL');
      if (url.contains('resourcePath')) {
        paymentStatus();
      }
    }
  }

  Future fetchCheckout() async {
    final response = await http.post('$baseUrl/v1/checkouts', headers: {
      'Authorization': bearerToken
    }, body: {
      'entityId': entityId,
      'amount': amount,
      'currency': 'ZAR',
      'paymentType': 'DB',
    });
    final json = jsonDecode(response.body);

    print(json);
    checkoutId = json['id'];
    print(checkoutId);
    log(checkoutId, name: 'CHECKID');
    setState(() {
      isLoading = false;
    });
  }

  Future paymentStatus() async {
    log(checkoutId, name: 'CHECKID 2nd');
    final response = await http.get(
      '$baseUrl/v1/checkouts/$checkoutId/payment?entityId=$entityId',
      headers: {'Authorization': bearerToken},
    );
    final json = jsonDecode(response.body);

    print(response.body);
    String code = json['result']['code'];
    String description = json['result']['description'];
    String successAmount = json['amount'] ?? '';

    if (description == 'Transaction succeeded') {
      log('PAYMENT DONE $successAmount', name: 'PAYMENT');
      // Fluttertoast.showToast(
      //     msg: 'Payment done', toastLength: Toast.LENGTH_LONG);
      NavigationController.navigator
          .pushReplacementNamed(Routes.appointmentSetupController);
    } else {
      Fluttertoast.showToast(msg: description, toastLength: Toast.LENGTH_LONG);
    }
    log(code, name: 'CODE');
    log(description, name: 'DES');

    // checkoutId = json['id'];
    // print(checkoutId);
    setState(() {
      isLoading = false;
    });
  }

  String loadHtml() {
    return '''
    <html>
    <body >
    <form action="https://oppwa.com" class="paymentWidgets" data-brands="VISA MASTER AMEX"></form>
    <script src="$baseUrl/v1/paymentWidgets.js?checkoutId=$checkoutId"></script>
    
    </body>
    </html>
    ''';
  }
}
