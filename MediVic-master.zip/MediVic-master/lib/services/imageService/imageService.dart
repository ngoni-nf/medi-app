// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:io';
import 'package:image_picker/image_picker.dart';

abstract class ImageService {
  static Future<File> getImage() async {
    final pickedFile = await ImagePicker().getImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      return File(pickedFile.path);
    } else {
      return null;
    }
  }
}
