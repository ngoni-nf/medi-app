// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:async';
import 'dart:developer';
// import 'package:apple_sign_in/apple_sign_in.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/models/userModel.dart';
import 'package:medivic/services/authentication/authentication.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_facebook_login/flutter_facebook_login.dart';
import 'package:google_sign_in/google_sign_in.dart';

class FirebaseAuthService implements AuthService {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  FAuthUser _userFromFirebase(FirebaseUser user) {
    if (user == null) {
      return null;
    }

    return FAuthUser(
      uid: user.uid,
      email: user.email,
    );
  }

  @override
  Stream<FAuthUser> get onAuthStateChanged {
    return _firebaseAuth.onAuthStateChanged.map(_userFromFirebase);
  }

  @override
  Future<FAuthUser> signInAnonymously() async {
    final AuthResult authResult = await _firebaseAuth.signInAnonymously();
    return _userFromFirebase(authResult.user);
  }

  @override
  Future<FAuthUser> signInWithEmailAndPassword(
      String email, String password) async {
    final AuthResult authResult = await _firebaseAuth
        .signInWithCredential(EmailAuthProvider.getCredential(
      email: email,
      password: password,
    ));
    if (authResult.user.isEmailVerified)
      return _userFromFirebase(authResult.user);
    else {
      authResult.user.sendEmailVerification();
      Fluttertoast.showToast(msg: AppStrings.emailVerificationMsg);
      return null;
    }
  }

  @override
  Future<FAuthUser> createUserWithEmailAndPassword(
      String email, String password) async {
    AuthResult authResult;
    await _firebaseAuth
        .createUserWithEmailAndPassword(email: email, password: password)
        .then((value) => authResult = value)
        .catchError((e) {
      if (e.toString().contains('ERROR_EMAIL_ALREADY_IN_USE')) {
        Fluttertoast.showToast(
            msg: AppStrings.emailAlreadyUsed, toastLength: Toast.LENGTH_LONG);
      }
      log(e.toString(), name: 'AUTH CREATE');
    });
    if (authResult != null) {
      authResult.user.sendEmailVerification().then((value) =>
          Fluttertoast.showToast(
                  msg: AppStrings.emailVerificationMsg,
                  toastLength: Toast.LENGTH_LONG)
              .catchError((e) {}));

      return _userFromFirebase(authResult.user);
    }

    return null;
  }

  @override
  Future<void> sendPasswordResetEmail(String email) async {
    await _firebaseAuth.sendPasswordResetEmail(email: email);
  }

  @override
  Future<FAuthUser> signInWithGoogle() async {
    try {
      final GoogleSignIn googleSignIn = GoogleSignIn();
      final GoogleSignInAccount googleUser =
          await googleSignIn.signIn().catchError((e) => null);

      if (googleUser != null) {
        final GoogleSignInAuthentication googleAuth =
            await googleUser.authentication;
        if (googleAuth.accessToken != null && googleAuth.idToken != null) {
          final AuthResult authResult = await _firebaseAuth
              .signInWithCredential(GoogleAuthProvider.getCredential(
            idToken: googleAuth.idToken,
            accessToken: googleAuth.accessToken,
          ));

          return _userFromFirebase(authResult.user);
        } else {
          return null;
          // throw PlatformException(
          //     code: 'ERROR_MISSING_GOOGLE_AUTH_TOKEN',
          //     message: 'Missing Google Auth Token');
        }
      } else {
        return null;
        // throw PlatformException(
        //     code: 'ERROR_ABORTED_BY_USER', message: 'Sign in aborted by user');
      }
    } catch (e) {
      log(e.toString(), name: 'GSI: AuthService');
      return null;
    }
  }

  @override
  Future<FAuthUser> signInWithFacebook() async {
    final FacebookLogin facebookLogin = FacebookLogin();
    // https://github.com/roughike/flutter_facebook_login/issues/210
    facebookLogin.loginBehavior = FacebookLoginBehavior.webViewOnly;
    final FacebookLoginResult result =
        await facebookLogin.logIn(<String>['public_profile']);
    if (result.accessToken != null) {
      final AuthResult authResult = await _firebaseAuth.signInWithCredential(
        FacebookAuthProvider.getCredential(
            accessToken: result.accessToken.token),
      );

      return _userFromFirebase(authResult.user);
    } else {
      return null;
      // throw PlatformException(
      //     code: 'ERROR_ABORTED_BY_USER', message: 'Sign in aborted by user');
    }
  }

  // @override
  // Future<FAuthUser> signInWithApple({List<Scope> scopes = const []}) async {
  //   final AuthorizationResult result = await AppleSignIn.performRequests(
  //       [AppleIdRequest(requestedScopes: scopes)]);
  //   switch (result.status) {
  //     case AuthorizationStatus.authorized:
  //       final appleIdCredential = result.credential;
  //       final oAuthProvider = OAuthProvider(providerId: 'apple.com');
  //       final credential = oAuthProvider.getCredential(
  //         idToken: String.fromCharCodes(appleIdCredential.identityToken),
  //         accessToken:
  //             String.fromCharCodes(appleIdCredential.authorizationCode),
  //       );

  //       final authResult = await _firebaseAuth.signInWithCredential(credential);
  //       final firebaseUser = authResult.user;
  //       if (scopes.contains(Scope.fullName)) {
  //         final updateUser = UserUpdateInfo();
  //         updateUser.displayName =
  //             '${appleIdCredential.fullName.givenName} ${appleIdCredential.fullName.familyName}';
  //         await firebaseUser.updateProfile(updateUser);
  //       }
  //       return _userFromFirebase(firebaseUser);
  //     case AuthorizationStatus.error:
  //       throw PlatformException(
  //         code: 'ERROR_AUTHORIZATION_DENIED',
  //         message: result.error.toString(),
  //       );
  //     case AuthorizationStatus.cancelled:
  //       throw PlatformException(
  //         code: 'ERROR_ABORTED_BY_USER',
  //         message: 'Sign in aborted by user',
  //       );
  //   }
  //   return null;
  // }

  @override
  Future<FAuthUser> currentUser() async {
    final FirebaseUser user = await _firebaseAuth.currentUser();
    return _userFromFirebase(user);
  }

  @override
  Future<void> signOut() async {
    final GoogleSignIn googleSignIn = GoogleSignIn();
    await googleSignIn.signOut();
    final FacebookLogin facebookLogin = FacebookLogin();
    await facebookLogin.logOut();
    return _firebaseAuth.signOut();
  }

  @override
  void dispose() {}
}
