import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:http/http.dart';


class Resource<T> {
  final String url;
  T Function(Response response) parse;

  Resource({this.url, this.parse});
}

class Webservice {
  var tag = "Webservice----";

  Future<T> loadPostWithoutParam<T>(Resource<T> resource) async {
    final response = await http.post(resource.url);
    print("response........................." + response.toString());
    if (response.statusCode == 200) {
      return resource.parse(response);
    } else {
      throw Exception('Failed to load data!');
    }

  }

  Future<T> loadPost<T>(Resource<T> resource, Map body) async {
    final response = await http.post(resource.url, body: body);
    print("response........................." + response.toString());
    if (response.statusCode == 200) {
      return resource.parse(response);
    } else {
      throw Exception('Failed to load data!');
    }
  }

  Future<T> loadGET<T>(Resource<T> resource) async {
    final response = await http.get(resource.url);
    print("response........................." + response.toString());
    if (response.statusCode == 200) {
      return resource.parse(response);
    } else {
      throw Exception('Failed to load data!');
    }
  }

  Future<T> loadLocationGET<T>(Resource<T> resource) async {
    final response = await http.get(resource.url);
    print("response........................." + response.toString());
    if (response.statusCode == 200) {
      return resource.parse(response);
    } else {
      throw Exception('Failed to load data!');
    }
  }
  /*Future<T> loadPostwithHeader<T>(
      Resource<T> resource, Map body, String token) async {
    String username = 'test';
    String password = '123£';
    String basicAuth =
        'Basic ' + base64Encode(utf8.encode('$username:$password'));
    final response = await http.post(resource.url, body: body);
    print("response........................." + response.toString());
    if (response.statusCode == 200) {
      return resource.parse(response);
    } else {
      throw Exception('Failed to load data!');
    }

    };
*/
  Future<T> loadGetwithHeader<T>(Resource<T> resource) async {
    String username = '5e5e8f95-16b1-461a-99a2-341068ae348a';
    String password = 'XvW8TFxMEwNnzAbDqj83nCbghGdL0/Nh';
    String basicAuth =
        'Basic ' + base64Encode(utf8.encode('$username:$password'));
    final response = await http.get(resource.url,headers: <String, String>{'authorization': basicAuth,'Content-Type': 'application/json'});
    print("response........................." + response.toString());
    if (response.statusCode == 200) {
      return resource.parse(response);
    } else {
      throw Exception('Failed to load data!');
    }
  }

  Future<T> loadPostwithHeader<T>(Resource<T> resource, Map body,String token) async {
    String jsonBody = json.encode(body);
    final encoding = Encoding.getByName('utf-8');
    final response = await http.post(resource.url,headers: <String, String>{'authorization': "Bearer $token",'Content-Type': 'text/json'},body: jsonBody,encoding: encoding);
    print("response........................." + response.toString());
    if (response.statusCode == 200) {
      return resource.parse(response);
    } else {
      throw Exception('Failed to load data!');
    }
  }

    /*Map<String,String> headers = {
      'Content-type' : 'application/json',
      'Accept': 'application/json',
    };*/
   /* final response =
        await http.post(resource.url, headers: headers, body: body);
    print("response........................." + response.toString());
    if (response.statusCode == 200) {
      return resource.parse(response);
    } else {
      throw Exception('Failed to load data!');
    }*/


}
