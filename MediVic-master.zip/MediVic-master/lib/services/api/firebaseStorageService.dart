// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:io';
import 'dart:typed_data';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

abstract class FirebaseStorageService {
  static Future<String> uploadFile(File imageFile, {String fileName}) async {
    // The ref. to the new url
    String downloadedUrl;

    final String name = fileName ?? DateTime.now().millisecondsSinceEpoch.toString();
    final StorageReference reference = FirebaseStorage.instance.ref().child(name);
    final StorageUploadTask uploadTask = reference.putFile(imageFile);
    final StorageTaskSnapshot storageTaskSnapshot = await uploadTask.onComplete;
    await storageTaskSnapshot.ref.getDownloadURL().then(
      (downloadUrl) {
        downloadedUrl = downloadUrl;
      },
      onError: (err) {
        Fluttertoast.showToast(msg: 'This file is not an image');
      },
    );
    return downloadedUrl;
  }

  static Future<Uint8List> imageDownload(String url) async {
    Fluttertoast.showToast(msg: 'Image downloading...');
    final StorageReference ref = await FirebaseStorage.instance.getReferenceFromUrl(url);
    final http.Response downloadData = await http.get(url);
    final Directory systemTmpDir = Directory.systemTemp;
    final File tmpFile = File('${systemTmpDir.path}/tmp.png');
    if (tmpFile.existsSync()) {
      tmpFile.delete();
    }
    await tmpFile.create();

    final StorageFileDownloadTask task = ref.writeToFile(tmpFile);
    final int byteCount = (await task.future).totalByteCount;
    final bodyBytes = downloadData.bodyBytes;
    Fluttertoast.showToast(msg: 'Image is downloaded successfully');
    return bodyBytes;
    // _scaffoldKey.currentState.showSnackBar(SnackBar(
    //   backgroundColor: Colors.white,
    //   content: Image.memory(
    //     bodyBytes,
    //     fit: BoxFit.fill,
    //   ),
    // ));
  }

  static void deleteFile(String url) async {
    final ref = await FirebaseStorage.instance.getReferenceFromUrl(url);
    await ref.delete().catchError((err) {});
  }
}
