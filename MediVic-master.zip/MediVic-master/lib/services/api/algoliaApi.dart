// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:developer';

import 'package:algolia/algolia.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/addressModel.dart';

///
/// ## `Description`
///
/// Class to search for doctors and hospitals with full text
/// search option available
///
class AlgoliaApi {
  static Algolia algolia = const Algolia.init(
    applicationId: Config.ALGOLIA_APP_ID,
    apiKey: Config.ALGOLIA_SEARCH_API_KEY,
  );

  Future<List<AlgoliaObjectSnapshot>> search(
      String searchTerm, String indexName,
      {int page = 0, int radius = 0}) async {
    try {
      final Location location =
          LocatorService.userProvider()?.user?.address?.location;
      AlgoliaQuery query = algolia.instance.index(indexName).search(searchTerm);
      if (radius > 0 && location != null) {
        query = query
            .setAroundLatLng(location.toString())
            .setAroundRadius(radius * 1000);
      }
      final AlgoliaQuerySnapshot snapshot =
          await query.setPage(page).getObjects();
      return snapshot.hits;
    } catch (e) {
      log(e.toString(), name: 'Algolia Api');
      return [];
    }
  }
}
