// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:async';
import 'dart:developer';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/extensions/string_extensions.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/appointment.dart';
import 'package:medivic/models/blogModel.dart';
import 'package:medivic/models/chatMessageModel.dart';
import 'package:medivic/models/documentModel.dart';
import 'package:medivic/models/note.dart';
import 'package:medivic/models/prescriptionModel.dart';
import 'package:medivic/models/prescriptionNew.dart';
import 'package:medivic/models/userModel.dart';
import 'package:medivic/providers/doctorProvider.dart';
import 'package:medivic/services/api/firebaseStorageService.dart';

///
/// ## Description
///
/// Class that handles all the `Firestore CRUD` operations.
///
abstract class FirestoreService {
  /// Important - Run the funtion when user sign up
  /// Create a users in specified collection
  ///

  static const String USERS = 'users';
  static const String DOCTORS = 'doctors';
  static const String DOCUMENTS = 'documents';
  static const String PRESCRIPTION = 'prescriptions';
  static const String CONTACT_US = 'contactUs';

  static Future<void> createUser(User user) async {
    // final userId = uid;

    // log('Creating user with User id - $userId', name: 'Firestore service');

    if (user == null || user.uid == null) {
      // throw Exception('No user id found in UserProvider');
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }
    final Firestore _firestore = Firestore.instance;
    await _firestore
        .collection('users')
        .document(user.uid)
        .setData(user.toJson());
  }

  // Returns a map of user data
  static Future<Map<String, dynamic>> getUserInfo(String userId) async {
    if (userId == null) {
      // throw Exception('No user id found in UserProvider');
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return null;
    }

    // UserId is present then get the information.
    final Firestore _firestore = Firestore.instance;
    final userDoc = await _firestore.collection('users').document(userId).get();
    if (userDoc != null) {
      return userDoc.data;
    } else {
      Fluttertoast.showToast(msg: 'Internet may not be available');
      return null;
    }
  }

  static Future<void> updateImageUrl(String url, {String uid}) async {
    final userId = uid ?? LocatorService.userProvider().user?.uid;

    log('user id - $userId', name: 'Firestore service');

    if (userId == null) {
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }

    final Firestore _firestore = Firestore.instance;
    await _firestore.collection('users').document(userId).updateData({
      'imageUrl': url,
    });
  }

  static Future<void> updateSignupImageUrl(String url, String UId,
      {String uid}) async {
    //final userId = uid ?? LocatorService.userProvider().user?.uid;

    log('user id - $UId', name: 'Firestore service');

    if (UId == null) {
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }

    final Firestore _firestore = Firestore.instance;
    await _firestore.collection('doctors').document(UId).updateData({
      'imageUrl': url,
    });
  }

  static Future<void> updateDocumentUrl(List<String> url, String Uid,
      {String uid}) async {
    //final userId = uid ?? LocatorService.userProvider().user?.uid;

    //log('user id - $userId', name: 'Firestore service');

    if (Uid == null) {
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }

    final Firestore _firestore = Firestore.instance;
    await _firestore.collection('doctors').document(Uid).updateData({
      'documentUrl': url,
    });
  }

  static Future<void> updateOtpStatusDoctor(String isOtp, String Uid,
      {String uid}) async {
    final doctorId = LocatorService.doctorProvider().doctor.uid;

    log('doctor id - $doctorId', name: 'Firestore service');

    if (Uid == null) {
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }

    final Firestore _firestore = Firestore.instance;
    await _firestore.collection('doctors').document(doctorId).updateData({
      'isOTP': isOtp,
    });
  }

  static Future<void> updateOtpStatusUser(String isOtp, String Uid,
      {String uid}) async {
    final userId = uid ?? LocatorService.userProvider().user?.uid;

    //log('user id - $userId', name: 'Firestore service');

    if (userId == null) {
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }

    final Firestore _firestore = Firestore.instance;
    await _firestore.collection('users').document(userId).updateData({
      'isOTP': isOtp,
    });
  }

  static Future<void> updateUserData(Map<String, dynamic> data,
      {String uid}) async {
    final userId = uid ?? LocatorService.userProvider().user.uid;

    log('Performing update for User id - $userId', name: 'Firestore service');

    if (userId == null) {
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }

    final Firestore _firestore = Firestore.instance;
    await _firestore.collection('users').document(userId).updateData(data);
  }

  static Future<void> setUserPushToken(String userId, String pushToken) async {
    log('Setting user push token', name: 'FS');
    if (userId.isNotEmpty && pushToken.isNotEmpty) {
      final data = {
        'createdAt': DateTime.now().millisecondsSinceEpoch.toString(),
        'pushToken': pushToken,
        'platform': Platform.isAndroid ? 'android' : 'ios',
      };
      await Firestore.instance
          .collection('users')
          .document(userId)
          .collection('tokens')
          .document(pushToken)
          .setData(data);
    } else {
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }
  }

  // *********************************************************************
  // Doctor Specific functions
  // *********************************************************************

  /// Important - Run the funtion when a doctor sign up. Create a doctor in specified collection
  static Future<void> createDoctor(
    String uid,
    String email,
    Map<String, dynamic> newData,
  ) async {
    final userId = uid;

    log('Creating doctor with User id - $userId', name: 'Firestore service');

    if (userId == null) {
      // throw Exception('No user id found in UserProvider');
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }
    print('email: $email');
    final data = {
      'uid': userId,
      'email': email,
      'phoneNumber': '',
      'experience': '',
      'name': email != null ? email.split('@')[0] : userId.substring(0, 7),
      'imageUrl': Config.placeholedImageUrl,
      'address': {
        'street': '',
        'city': '',
        'state': '',
        'pin': '',
        'country': '',
      },
      ...newData,
      'timestamp': DateTime.now().millisecondsSinceEpoch.toString(),
    };
    print('email: $email');
    final Firestore _firestore = Firestore.instance;
    await _firestore.collection('doctors').document(userId).setData(data);
  }

  /// `Update doctor data`
  static Future<void> updateDoctorData(Map<String, dynamic> data,
      {String uid}) async {
    final userId = uid ?? locator<DoctorProvider>().doctor.uid;

    log('Performing update for Doctor id - $userId',
        name: 'Firestore service - update doctor data');

    if (userId == null) {
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }

    final Firestore _firestore = Firestore.instance;
    await _firestore.collection('doctors').document(userId).updateData(data);
  }

  /// `Update doctor address`
  static Future<void> updateDoctorAddress(
      Map<String, dynamic> address, Map<String, dynamic> geoLocation,
      {String uid}) async {
    final userId = uid ?? locator<DoctorProvider>().doctor.uid;

    log('Doctor id - $userId', name: 'Firestore service address update');

    if (userId == null) {
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }

    final Firestore _firestore = Firestore.instance;
    await _firestore
        .collection('doctors')
        .document(userId)
        .updateData({'address': address, '_geoloc': geoLocation});
  }

  /// `Update doctor image url`
  static Future<void> updateDoctorImageUrl(String url, {String uid}) async {
    final userId = uid ?? locator<DoctorProvider>().doctor.uid;

    log('Doctor id - $userId', name: 'Firestore service image upload');

    if (userId == null) {
      // throw Exception('No user id found in UserProvider');
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }

    final Firestore _firestore = Firestore.instance;
    await _firestore.collection('doctors').document(userId).updateData({
      'imageUrl': url,
    });
  }

  /// `Get doctor data` Returns a map of user data
  static Future<Map<String, dynamic>> getDoctorInfo(String doctorId) async {
    if (doctorId == null) {
      // throw Exception('No user id found in UserProvider');
      Fluttertoast.showToast(msg: 'No doctorId found, please login again');
      return null;
    }

    // doctorId is present then get the information.
    final Firestore _firestore = Firestore.instance;
    final userDoc =
        await _firestore.collection('doctors').document(doctorId).get();
    if (userDoc != null) {
      return userDoc.data;
    } else {
      Fluttertoast.showToast(msg: 'Internet may not be available');
      return null;
    }
  }

  static Future<List<DocumentSnapshot>> searchDoctors(String searchTerm) async {
    final Firestore _firestore = Firestore.instance;
    final Query query = _firestore.collection('doctors').orderBy('name');
    final QuerySnapshot snapshots = await query.getDocuments();
    log('${snapshots.documents.length}',
        name: 'Firestore Service search doctors');
    return snapshots.documents;
  }

  static Future<List<DocumentSnapshot>> searchDoctorsWithSpeciality(
      List<String> searchTerms) async {
    final Firestore _firestore = Firestore.instance;
    final Query query = _firestore
        .collection('doctors')
        .where('specialities', arrayContainsAny: searchTerms)
        .limit(15);
    final QuerySnapshot snapshots = await query.getDocuments();
    log('${snapshots.documents.length}',
        name: 'Firestore Service search doctors with speciality');
    return snapshots.documents;
  }

  static Future<List<DocumentSnapshot>> searchMoreDoctorsWithSpeciality(
      DocumentSnapshot lastDocumentSnapshot, List<String> searchTerms) async {
    final Firestore _firestore = Firestore.instance;
    final Query query = _firestore
        .collection('doctors')
        .where('specialities', arrayContainsAny: searchTerms)
        .startAfterDocument(lastDocumentSnapshot)
        .limit(15);
    final QuerySnapshot snapshots = await query.getDocuments();
    log('${snapshots.documents.length}',
        name: 'Firestore Service search more doctors with speciality');
    return snapshots.documents;
  }

  static Future<void> setDoctorPushToken(
      String doctorId, String pushToken) async {
    if (doctorId.isNotEmpty && pushToken.isNotEmpty) {
      log('Setting doctor push token', name: 'FS');
      final data = {
        'createdAt': DateTime.now().millisecondsSinceEpoch.toString(),
        'pushToken': pushToken,
        'platform': Platform.isAndroid ? 'android' : 'ios',
      };
      await Firestore.instance
          .collection('doctors')
          .document(doctorId)
          .collection('tokens')
          .document(pushToken)
          .setData(data);
    } else {
      Fluttertoast.showToast(msg: 'No id found, please login again');
      return;
    }
  }

  // *********************************************************************
  // `Hospitals functions`:
  // *********************************************************************

  /// Gets the list of hospitals without any search
  static Future<List<DocumentSnapshot>> getHospitals() async {
    final Firestore _firestore = Firestore.instance;
    final Query query =
        _firestore.collection('hospitals').orderBy('name').limit(15);
    final QuerySnapshot snapshots = await query.getDocuments();
    log('Get hospitals ${snapshots.documents.length}', name: 'FS');
    return snapshots.documents;
  }

  /// Gets more hospitals without any search
  static Future<List<DocumentSnapshot>> getMoreHospitals(
      DocumentSnapshot lastDocument) async {
    final Firestore _firestore = Firestore.instance;
    final Query query = _firestore
        .collection('hospitals')
        .startAfterDocument(lastDocument)
        .orderBy('name')
        .limit(15);
    final QuerySnapshot snapshots = await query.getDocuments();
    log('Get more hospitals ${snapshots.documents.length}', name: 'FS');
    return snapshots.documents;
  }

  static Future<List<DocumentSnapshot>> searchHospitals(
      String searchTerm) async {
    final Firestore _firestore = Firestore.instance;
    final Query query = _firestore
        .collection('hospitals')
        // .orderBy('name')
        // .where('name', isEqualTo: searchTerm)
        .where('name', isGreaterThanOrEqualTo: searchTerm)
        .where('name', isLessThanOrEqualTo: searchTerm + '\uf8ff')
        .limit(100);
    final QuerySnapshot snapshots = await query.getDocuments();
    log('${snapshots.documents.length}',
        name: 'Firestore Service search hospitals');
    return snapshots.documents;
  }

  static Future<List<DocumentSnapshot>> searchMoreHospitals(
      DocumentSnapshot lastDocumentSnapshot, String searchTerm) async {
    final Firestore _firestore = Firestore.instance;
    final Query query = _firestore
        .collection('hospitals')
        .orderBy('name')
        // .where('name', isGreaterThanOrEqualTo: searchTerm)
        .startAfterDocument(lastDocumentSnapshot)
        .limit(15);
    final QuerySnapshot snapshots = await query.getDocuments();
    log('${snapshots.documents.length}',
        name: 'Firestore Service search more hospitals');
    return snapshots.documents;
  }

  /// Create a prescription document in the users' prescription subcollection
  static Future<bool> createPrescription(Map<String, dynamic> data) async {
    final String userId = data['userId'];
    final String doctorId = data['doctorId'];
    final String appointmentId = data['appointmentId'];

    if (userId.isNotEmpty && doctorId.isNotEmpty && appointmentId.isNotEmpty) {
      // Add a timstamp to the map
      data['timestamp'] = DateTime.now().millisecondsSinceEpoch.toString();

      // Write to firestore
      final Firestore _firestore = Firestore.instance;
      final DocumentReference _ref = _firestore
          .collection('users')
          .document(userId)
          .collection('prescriptions')
          .document();

      final bool result = await _ref.setData(data).then((_) {
        Fluttertoast.showToast(msg: AppStrings.success);
        return true;
      }, onError: (e) {
        Fluttertoast.showToast(msg: 'Error $e');
        return false;
      });

      return result;
    } else {
      Fluttertoast.showToast(msg: 'No id found');
      return null;
    }
  }

  /// Get the prescription for a user.
  static Future<List<DocumentSnapshot>> getUserPrescriptions(String uid) async {
    if (uid.isNotEmpty) {
      final Firestore _firestore = Firestore.instance;
      final Query query = _firestore
          .collection('users')
          .document(uid)
          .collection('prescriptions')
          .orderBy('timestamp', descending: true);
      // .limit(15);
      final QuerySnapshot snapshots = await query.getDocuments();
      log('Get Prescriptions - ${snapshots.documents.length}', name: 'FS');
      return snapshots.documents;
    } else {
      Fluttertoast.showToast(msg: 'No user id found. Please login again');
      return null;
    }
  }

  /// Gets the blogs data
  static Future<List<DocumentSnapshot>> getBlogs() async {
    final Firestore firestore = Firestore.instance;

    final Query query = firestore
        .collection('blogs')
        .orderBy('timestamp', descending: true)
        .limit(15);

    final QuerySnapshot snapshot = await query.getDocuments();
    log('Get Blogs ${snapshot.documents.length}', name: 'FS');
    return snapshot.documents;
  }

  /// Gets more blogs data
  static Future<List<DocumentSnapshot>> getMoreBlogs(
      DocumentSnapshot lastDocument) async {
    final Firestore firestore = Firestore.instance;

    final Query query = firestore
        .collection('blogs')
        .startAfterDocument(lastDocument)
        .orderBy('timestamp', descending: true)
        .limit(15);

    final QuerySnapshot snapshot = await query.getDocuments();
    log('Get More Blogs ${snapshot.documents.length}', name: 'FS');
    return snapshot.documents;
  }

  /// Gets the blogs data
  static Future<bool> saveBlog(Blog blog, String userId) async {
    if (userId.isNotEmpty) {
      final Firestore firestore = Firestore.instance;

      final DocumentReference _ref = firestore
          .collection('users')
          .document(userId)
          .collection('savedBlogs')
          .document(blog.uid);

      final result = await _ref.setData(blog.toJson()).then((_) {
        return true;
      }, onError: (e) {
        return false;
      });

      return result;
    } else {
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
      return null;
    }
  }

  /// Delete blogs data from a user saved blogs
  static Future<bool> deleteBlog(String blogId, String userId) async {
    if (userId.isNotEmpty) {
      final Firestore firestore = Firestore.instance;

      final DocumentReference _ref = firestore
          .collection('users')
          .document(userId)
          .collection('savedBlogs')
          .document(blogId);

      final result = await _ref.delete().then((_) {
        return true;
      }, onError: (e) {
        return false;
      });

      return result;
    } else {
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
      return null;
    }
  }

  /// Gets the users saved blogs data
  static Future<List<DocumentSnapshot>> getUsersSavedBlogs(
      String userId) async {
    if (userId.isNotEmpty) {
      final Firestore firestore = Firestore.instance;

      final Query query = firestore
          .collection('users')
          .document(userId)
          .collection('savedBlogs')
          .orderBy('timestamp', descending: true)
          .limit(15);

      final QuerySnapshot snapshot = await query.getDocuments();
      log('Get Users Saved Blogs ${snapshot.documents.length}', name: 'FS');
      return snapshot.documents;
    } else {
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
      return null;
    }
  }

  /// Gets more users saved blogs data
  static Future<List<DocumentSnapshot>> getMoreUsersSavedBlogs(
      DocumentSnapshot lastDocument, String userId) async {
    if (userId.isNotEmpty) {
      final Firestore firestore = Firestore.instance;

      final Query query = firestore
          .collection('users')
          .document(userId)
          .collection('savedBlogs')
          .startAfterDocument(lastDocument)
          .orderBy('timestamp', descending: true)
          .limit(15);

      final QuerySnapshot snapshot = await query.getDocuments();
      log('Get More Users Saved Blogs ${snapshot.documents.length}',
          name: 'FS');
      return snapshot.documents;
    } else {
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
      return null;
    }
  }

  // *********************************************************************
  // Chat Messages functions
  // *********************************************************************

  /// Gets the list of messages in a chat
  static Future<List<DocumentSnapshot>> getChatMessages(
      String chatRoomId) async {
    if (chatRoomId.isNotEmpty) {
      final Firestore firestore = Firestore.instance;

      final Query query = firestore
          .collection('messages')
          .document(chatRoomId)
          .collection(chatRoomId)
          .orderBy('timestamp', descending: true)
          .limit(200);

      final QuerySnapshot snapshot = await query.getDocuments();
      log('Chat Messages: Length ${snapshot.documents.length}', name: 'FS');
      return snapshot.documents.isNotEmpty ? snapshot.documents : [];
    } else {
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
      return null;
    }
  }

  /// Gets more chat messages
  static Future<List<DocumentSnapshot>> getMoreChatMessages(
      String chatRoomId, DocumentSnapshot lastDocument) async {
    if (chatRoomId.isNotEmpty && lastDocument.documentID != null) {
      final Firestore firestore = Firestore.instance;

      final Query query = firestore
          .collection('messages')
          .document(chatRoomId)
          .collection(chatRoomId)
          .startAfterDocument(lastDocument)
          .orderBy('timestamp', descending: true)
          .limit(50);

      final QuerySnapshot snapshot = await query.getDocuments();
      log('More Chat Messages: Length ${snapshot.documents.length}',
          name: 'FS');
      return snapshot.documents.isNotEmpty ? snapshot.documents : [];
    } else {
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
      return null;
    }
  }

  /// Get chat room stream for real time updates
  static Stream<QuerySnapshot> getMessagesStream(String chatRoomId) {
    if (chatRoomId.isNotEmpty) {
      final Firestore firestore = Firestore.instance;
      return firestore
          .collection('messages')
          .document(chatRoomId)
          .collection(chatRoomId)
          .orderBy('timestamp', descending: true)
          .limit(1)
          .snapshots();
    } else {
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
      return null;
    }
  }

  /// Send the message to the chat room.
  static Future<void> sendMessage(
      String chatRoomId, ChatMessage message) async {
    if (chatRoomId?.isNotEmpty ?? false) {
      log('Sending chat message...', name: 'FS');
      return await Firestore.instance
          .collection('messages')
          .document(chatRoomId)
          .collection(chatRoomId)
          .document(DateTime.now().millisecondsSinceEpoch.toString())
          .setData(message.toMap());
    } else {
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
      return;
    }
  }

  // *********************************************************************
  // Illness related functions
  // *********************************************************************

  /// Gets the full list of illness from the server
  static Future<List<String>> getIllnessList() async {
    log('Fetching illness list...', name: 'Firestore Service');
    final result = await Firestore.instance
        .collection('admin')
        .document('illnessList')
        .get();
    if (result.data != null) {
      return result.data['illnessList'].cast<String>();
    } else {
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
      return [];
    }
  }

  static Future<List<String>> getSpecialities() async {
    final List<String> specialities = [];
    final querySnapshot =
        await Firestore.instance.collection('doctors').getDocuments();
    for (final element in querySnapshot.documents) {
      if (element.data['specialities'] != null) {
        specialities.addAll(element.data['specialities'].cast<String>());
      }
    }
    return [
      ...{...specialities.map((e) => e.capitalize()).toList()}
    ];
  }

  /// Gets the full list of OnlineAppointments from the server
  static Future<List<String>> getOnlineAppointments() async {
    log('Fetching illness list...', name: 'Firestore Service');
    final result = await Firestore.instance
        .collection(Appointment.COLLECTION_NAME)
        .document('illnessList')
        .get();
    if (result.data != null) {
      return result.data['illnessList'].cast<String>();
    } else {
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
      return [];
    }
  }

  static Future<void> cancelAppointment(String docId) async {
    await Firestore.instance
        .collection(Appointment.COLLECTION_NAME)
        .document(docId)
        .delete();
  }

  static Future<void> addPrescription(PrescriptionNew prescription) async {
    if (prescription.docId != null && prescription.docId.isNotEmpty) {
      return await Firestore.instance
          .collection('prescriptions')
          .document(prescription.docId)
          .setData(prescription.toMap(), merge: true);
    } else
      return await Firestore.instance
          .collection('prescriptions')
          .add(prescription.toMap());
  }

  static Future<bool> addNote(String userId, Note prescription) async {
    bool result = false;
    if (prescription.docId != null && prescription.docId.isNotEmpty) {
      await Firestore.instance
          .collection('notes')
          .document(prescription.docId)
          .setData(prescription.toMap(), merge: true)
          .then((value) => result = true)
          .catchError((e) {});
    } else
      await Firestore.instance
          .collection('notes')
          .add(prescription.toMap())
          .then((value) => result = true)
          .catchError((e) {});
    return result;
  }

  static Future<bool> deleteNote(String docId, Function callback) async {
    bool result = false;
    await Firestore.instance
        .document('notes/$docId')
        .delete()
        .then((value) => result = true)
        .catchError((e) {
      print(e.toString());
    });

    if (result) {
      callback.call();
    }
    return result;
  }

  static Future<List<PrescriptionNew>> getPrescriptions(
      String doctorId, bool isFrom) async {
    List<PrescriptionNew> prescriptions = [];
    await Firestore.instance
        .collection('prescriptions')
        .where(isFrom ? 'fromId' : 'toId', isEqualTo: doctorId)
        .orderBy('updatedAt', descending: true)
        .getDocuments()
        .then((value) {
      if (value != null && value.documents.isNotEmpty) {
        prescriptions = value.documents
            .map((e) => convertDocumentToMap(e))
            .map((e) => PrescriptionNew.fromMap(e))
            .toList();
      }
    }).catchError((e) {});

    return prescriptions;
  }

  static Future<List<Note>> getNotes(String doctorId) async {
    List<Note> prescriptions = [];
    await Firestore.instance
        .collection('notes')
        .where('doctorId', isEqualTo: doctorId)
        .orderBy('updatedAt', descending: true)
        .getDocuments()
        .then((value) {
      if (value != null && value.documents.isNotEmpty) {
        prescriptions = value.documents
            .map((e) => convertDocumentToMap(e))
            .map((e) => Note.fromMap(e))
            .toList();
      }
    }).catchError((e) {});

    return prescriptions;
  }

  static Future<List<Prescription>> getPrescriptionsUser(String userId) async {
    print('userId: $userId');
    final List<Map<String, dynamic>> data = (await Firestore.instance
            .collection(USERS)
            .document(userId)
            .collection(PRESCRIPTION)
            // .where('doctorId', isEqualTo: doctorId)
            .getDocuments())
        .documents
        .map((e) => e.data)
        .toList();
    final List<Prescription> prescriptions =
        data.map((e) => Prescription.fromMap(e)).toList();

    return prescriptions;
  }

  //give ratings
  static Future<void> giveRatings(Map<String, dynamic> data,
      {String uid, doctorId}) async {
    final userId = uid ?? LocatorService.userProvider().user?.uid;

    log('Performing update for Doctor id - $userId',
        name: 'Firestore service - update doctor data');

    if (userId == null) {
      Fluttertoast.showToast(msg: 'No userId found, please login again');
      return;
    }

    final Firestore _firestore = Firestore.instance;
    await _firestore
        .collection('doctors')
        .document(doctorId)
        .collection('ratings')
        .document(userId)
        .setData(data);
    final List<Map<String, dynamic>> ratings = (await _firestore
            .collection('doctors')
            .document(doctorId)
            .collection('ratings')
            .getDocuments())
        .documents
        .map((e) => e.data)
        .toList();
    final double totalRating =
        ratings.map((e) => e['rating']).fold(0, (p, r) => p + r);
    Map<String, dynamic> ratingMap = {'rating': totalRating / ratings.length};
    await _firestore
        .collection('doctors')
        .document(doctorId)
        .updateData(ratingMap);
  }

  static Future<Map<String, dynamic>> getRating(
      String userId, String doctorId) async {
    final Firestore _firestore = Firestore.instance;
    final rating = await _firestore
        .collection('doctors')
        .document(doctorId)
        .collection('ratings')
        .document(userId)
        .get();
    if (rating.data != null) {
      return rating.data;
    }
    return null;
  }

  static Future<List<Document>> getDocuments(String userId) async {
    final firestore = Firestore.instance;
    final List<DocumentSnapshot> snapshots = (await firestore
            .collection(USERS)
            .document(userId)
            .collection(DOCUMENTS)
            .getDocuments())
        .documents;
    if (snapshots != null) {
      return Document.parseList(snapshots);
    }
    return null;
  }

  static Future<bool> uploadDocument(
      String userId, File file, String fileName) async {
    String downloadUrl =
        await FirebaseStorageService.uploadFile(file, fileName: fileName);
    if (downloadUrl != null) {
      Document document = Document(
          fileName: fileName, fileUrl: downloadUrl, createdAt: DateTime.now());
      await Firestore.instance
          .collection(USERS)
          .document(userId)
          .collection(DOCUMENTS)
          .add(document.toMap());
      return true;
    }
    return false;
  }

  static Future<bool> deleteDocument(String userId, Document document) async {
    bool result = false;
    await Firestore.instance
        .collection(USERS)
        .document(userId)
        .collection(DOCUMENTS)
        .document(document.docId)
        .delete()
        .then((value) => result = true)
        .catchError((err) {
      print(err);
    });
    await FirebaseStorageService.deleteFile(document.fileUrl);
    return result;
  }

  static Future<List<Appointment>> getAppointmentsForDoctor(
      String doctorId) async {
    final QuerySnapshot querySnapshot = await Firestore.instance
        .collection(Appointment.COLLECTION_NAME)
        .where('doctorId', isEqualTo: doctorId)
        .getDocuments();
    return Appointment.parseList(querySnapshot.documents);
  }

  static Map<String, dynamic> convertDocumentToMap(DocumentSnapshot doc) {
    final Map<String, dynamic> data = doc.data;
    if (!data.containsKey('docId') || data['docId'] == null) {
      data['docId'] = doc.documentID;
    }
    return data;
  }

  static Future documentsVisibility(String userId, bool isVisible) async {
    await Firestore.instance
        .collection(USERS)
        .document(userId)
        .updateData({'docsVisibility': isVisible});
    LocatorService.userProvider().user.docsVisibility = isVisible;
    String msg = 'Documents visibility is ' + (isVisible ? 'ON' : 'OFF');
    Fluttertoast.showToast(msg: msg);
  }

  static Future<bool> saveToContactUs(String userId, String msg) async {
    bool result = false;
    Map<String, dynamic> data = {
      'userId': userId,
      'message': msg,
      'createdAt': DateTime.now(),
    };
    await Firestore.instance
        .collection(CONTACT_US)
        .add(data)
        .then((value) => result = true);

    return result;
  }

  static Future<String> getHTMLData(String field) async {
    String content = '';
    await Firestore.instance
        .collection('htmlcontent')
        .orderBy('timestamp', descending: true)
        .limit(1)
        .getDocuments()
        .then((value) {
      if (value != null && value.documents.isNotEmpty)
        content = value.documents[0].data[field];
    });
    return content;
  }

  static Future<bool> isEmailExist(String email, bool isDoctor) async {
    bool isExist = false;
    await Firestore.instance
        .collection(isDoctor ? DOCTORS : USERS)
        .where('email', isEqualTo: email)
        .getDocuments()
        .then((value) {
      if (value != null && value.documents.isNotEmpty) {
        isExist = true;
      }
    }).catchError((e) {});
    return isExist;
  }

  static Future<bool> isPhoneExist(String phone, bool isDoctor) async {
    bool isExist = false;
    await Firestore.instance
        .collection(isDoctor ? DOCTORS : USERS)
        .where('phoneNumber', isEqualTo: phone)
        .getDocuments()
        .then((value) {
      if (value != null && value.documents.isNotEmpty) {
        isExist = true;
      }
    }).catchError((e) {});
    return isExist;
  }
}
