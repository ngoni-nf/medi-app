// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/screens/appointment/patient_appointments.dart';
import 'package:medivic/screens/doctorsAccountScreens/appointments/doctor_appointments.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/services/storage/localStorage.dart';
import 'package:medivic/services/storage/storageConstants.dart';
import 'package:medivic/utils/common_utils.dart';

class PushNotificationService {
  static final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
  static final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  Future<void> registerNotification() async {
    _firebaseMessaging.requestNotificationPermissions();

    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) {
        log('onMessage: $message');
        print(message);
        Platform.isAndroid ? showNotification(message) : showNotification(message['aps']['alert']);
        return;
      },
      onResume: (Map<String, dynamic> message) {
        log('onResume:');

        _navigateToAppointmentListScreen();

        // // For Android
        // if (message.containsKey('data')) {
        //   if (message['data'].containsKey('appointmentDocument')) {
        //     if (LocatorService.doctorProvider().doctor != null) {
        //       // Navigate to doctor's appointments screen.
        //       NavigationController.navigator
        //           .pushNamed(Routes.appointmentsDoctor);
        //     } else {
        //       // Navigate to appointments screen.
        //       NavigationController.navigator.pushNamed(Routes.appointments);
        //     }
        //   }
        // }
        //
        // // For IOS
        // if (message.containsKey('appointmentDocument')) {
        //   if (LocatorService.doctorProvider().doctor != null) {
        //     // Navigate to doctor's appointments screen.
        //     NavigationController.navigator.pushNamed(Routes.appointmentsDoctor);
        //   } else {
        //     // Navigate to appointments screen.
        //     NavigationController.navigator.pushNamed(Routes.appointments);
        //   }
        // }

        return;
      },
      onLaunch: (Map<String, dynamic> message) {
        log('onLaunch:');
        print(message);

        LocatorService.notificationController().setNotificationClicked(true);
        LocatorService.notificationController().setNotificationObject(message);

        // // For Android
        // if (message.containsKey('data')) {
        //   if (message['data'].containsKey('appointmentDocument')) {
        //     LocatorService.notificationController()
        //         .setNotificationClicked(true);
        //     LocatorService.notificationController()
        //         .setNotificationObject(message);
        //   }
        // }
        //
        // // For IOS
        // if (message.containsKey('appointmentDocument')) {
        //   LocatorService.notificationController().setNotificationClicked(true);
        //   LocatorService.notificationController()
        //       .setNotificationObject(message);
        // }
        return;
      },
    );
  }

  void setUserToken(String userId) {
    _firebaseMessaging.getToken().then((token) async {
      log('User token: $token', name: 'PNS');

      // Compare token saved in the device before updating
      final String savedToken = await LocalStorage.getString(LocalStorageConstants.USER_PUSH_TOKEN);

      if (savedToken != null) {
        if (savedToken == token) {
          log('Token already up to date', name: 'PNS - setUserToken');
          return;
        }
      } else {
        await FirestoreService.setUserPushToken(userId, token);
        await LocalStorage.setString(LocalStorageConstants.USER_PUSH_TOKEN, token);
      }
    }).catchError((err) {
      Fluttertoast.showToast(msg: err.message.toString());
    });
  }

  void setDoctorToken(String doctorId) {
    _firebaseMessaging.getToken().then((token) async {
      log('Doctor token: $token', name: 'PNS');

      // Compare token saved in the device before updating
      final String savedToken = await LocalStorage.getString(LocalStorageConstants.DOCTOR_PUSH_TOKEN);

      if (savedToken != null) {
        if (savedToken == token) {
          log('Doctor Token already up to date', name: 'PNS - setDoctorToken');
          return;
        }
      } else {
        await FirestoreService.setDoctorPushToken(doctorId, token);
        await LocalStorage.setString(LocalStorageConstants.DOCTOR_PUSH_TOKEN, token);
      }
    }).catchError((err) {
      Fluttertoast.showToast(msg: err.message.toString());
    });
  }

  /// Updates users or doctors refresh token.
  ///
  /// ## `IMPORTANT`
  /// Run on app initialization after the user data is downloaded.
  /// Good place to run this is when user data or doctor data is fetched.
  void setRefreshedTokenFor({String userId, String doctorId}) {
    log('Listening for token change', name: 'PNS');
    _firebaseMessaging.onTokenRefresh.listen((String token) async {
      log('Token changed for userId $userId or doctorId $doctorId', name: 'PNS');
      // if there is a new token set to user or doctor
      if (userId != null) {
        try {
          await FirestoreService.setUserPushToken(userId, token);
        } catch (e) {
          log('$e', name: 'PNS');
          return;
        }
        return;
      }

      if (doctorId != null) {
        try {
          await FirestoreService.setDoctorPushToken(doctorId, token);
        } catch (e) {
          log('$e', name: 'PNS');
          return;
        }
        return;
      }
    });
  }

  /// Used to subscribe to specific topics
  Future<void> subscribeToTopic({String topic = Config.NOTIFICATION_SUBSCRIPTION_TOPIC}) async {
    await _firebaseMessaging.subscribeToTopic(topic);
  }

  Future<void> configLocalNotification() async {
    log('Calling from configure local notifications');
    const initializationSettingsAndroid = AndroidInitializationSettings('ic_notification');
    const initializationSettingsIOS = IOSInitializationSettings();
    const initializationSettings = InitializationSettings(android: initializationSettingsAndroid, iOS: initializationSettingsIOS);
    _flutterLocalNotificationsPlugin.initialize(initializationSettings, onSelectNotification: (payload) {
      log('Payload clicked', name: 'PNS');
      print(payload);

      final message = json.decode(payload);

      // For Android
      if (message.containsKey('data')) {
        if (message['data'].containsKey('appointmentDocument')) {
          _navigateToAppointmentListScreen();
        }
      }

      // For IOS
      if (message.containsKey('appointmentDocument')) {
        _navigateToAppointmentListScreen();
      }
      return;
    });
  }

  Future<void> showNotification(message, {int notificationId}) async {
    log('Showing notification');
    print('$message');
    final String title = message['notification']['title'].toString();
    final String body = message['notification']['body'].toString();
    final androidPlatformChannelSpecifics = AndroidNotificationDetails(
      'appointment_channel_101',
      'MediVic Appointment Notification',
      'MediVic Appointment Notification',
      playSound: true,
      enableVibration: true,
      importance: Importance.max,
      priority: Priority.max,
      visibility: NotificationVisibility.public,
      ticker: title,
      color: appBarColor,
      styleInformation: const BigTextStyleInformation(''),
    );
    const iOSPlatformChannelSpecifics = IOSNotificationDetails(
      presentAlert: true,
      presentSound: true,
    );
    final platformChannelSpecifics = NotificationDetails(android: androidPlatformChannelSpecifics, iOS: iOSPlatformChannelSpecifics);
    await _flutterLocalNotificationsPlugin.show(
      notificationId ?? CommonUtils.generateNotificationId(),
      title,
      body,
      platformChannelSpecifics,
      payload: json.encode(message),
    );
  }

  void _navigateToAppointmentListScreen() {
    NavigationController.navigator.push(MaterialPageRoute(
        builder: (context) =>
            LocatorService.userProvider().user == null ? const PatientAppointmentListScreen() : const DoctorAppointmentListScreen()));
  }

  /// Functions to manage the initialization, configuration and all other notifications
  /// related things at Login or SignUp
  void manageNotificationsAtAuth({String userId, String doctorId}) {
    // call other functions
    subscribeToTopic();

    if (userId != null) {
      setUserToken(userId);
    }

    if (doctorId != null) {
      setDoctorToken(doctorId);
    }
  }
}
