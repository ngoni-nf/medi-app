// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:developer';
import 'dart:io';

import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/routes/router.gr.dart';
import 'package:medivic/services/payment/paymentPeach.dart';
import 'package:medivic/services/pushNotification/pushNotificationService.dart';
import 'package:medivic/themes/theme.dart';
import 'package:provider/provider.dart';

//added comment
class MyApp extends StatefulWidget {
  const MyApp({Key key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onPanDown: (details) {
        LocatorService.inActivityTimer().resetTimer();
      },
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (context) => LocatorService.userProvider(),
          ),
          ChangeNotifierProvider(
            create: (context) => LocatorService.doctorProvider(),
          ),
        ],
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Doctor Consultation',
          theme: CustomeTheme.lightTheme,
          // home: PaymentPeach(),
          builder: ExtendedNavigator<AppRouter>(router: AppRouter()),
        ),
      ),
    );
  }
}

void main() {
  log('Main Called',name: 'Main');
  WidgetsFlutterBinding.ensureInitialized();
  setupLocator();

  if (Platform.isAndroid) {
    // Overrides the status bar and navigation style.
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarIconBrightness: Brightness.light,
      statusBarColor: Colors.black,
      systemNavigationBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Colors.black,
    ));
  }

  // Register for local and remote notifications
  LocatorService.pushNotificationService().registerNotification();
  LocatorService.pushNotificationService().configLocalNotification();

  runApp(const MyApp());
}
