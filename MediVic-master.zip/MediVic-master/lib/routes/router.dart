// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:auto_route/auto_route_annotations.dart';
import 'package:medivic/controllers/appointmentSetupController.dart';
import 'package:medivic/screens/accountInfo/accountInfo.dart';
import 'package:medivic/screens/accountInfo/contactScreen.dart';
import 'package:medivic/screens/accountInfo/editProfileInfo.dart';
import 'package:medivic/screens/accountInfo/help/help.dart';
import 'package:medivic/screens/accountInfo/medicineCourse.dart';
import 'package:medivic/screens/accountInfo/savedBlogs.dart';
import 'package:medivic/screens/blogs/blogPost.dart';
import 'package:medivic/screens/blogs/blogScreen.dart';
import 'package:medivic/screens/doctorInfo/doctorInfo.dart';
import 'package:medivic/screens/doctorList/doctorList.dart';
import 'package:medivic/screens/doctorsAccountScreens/appointments/doctor_appointments.dart';
import 'package:medivic/screens/doctorsAccountScreens/editProfileDoctor/editProfileDoctor.dart';
import 'package:medivic/screens/doctorsAccountScreens/homeDoctor/homeDoctor.dart';
import 'package:medivic/screens/doctorsAccountScreens/loginDoctor/loginDoctor.dart';
import 'package:medivic/screens/doctorsAccountScreens/signupDoctor/signupDoctor.dart';
import 'package:medivic/screens/home/home.dart';
import 'package:medivic/screens/hospitalInfo/hospitalInfo.dart';
import 'package:medivic/screens/hospitalList/hospitalList.dart';
import 'package:medivic/screens/login/login.dart';
import 'package:medivic/screens/onBoarding/onBoarding.dart';
import 'package:medivic/screens/review/review.dart';
import 'package:medivic/screens/search/searchScreen.dart';
import 'package:medivic/screens/signup/signup.dart';
import 'package:medivic/screens/splash/splash.dart';
import 'package:medivic/screens/support/support.dart';
import 'package:medivic/services/payment/paymentWebview.dart';
import 'package:medivic/screens/call/agora/video_call.dart';

@CupertinoAutoRouter()
class $Router {
  @initial
  SplashScreen splashScreen;

  Login login;
  Signup signup;
  Home home;
  OnBoarding onBoarding;

  VideoCallScreen call;

  // Payment
  Review review;
  PaymentWebview paymentWebview;

  AppointmentSetupController appointmentSetupController;

  BlogsScreen blogsScreen;
  DoctorInfo doctorInfo;
  DoctorsList doctorsList;
  HospitalInfo hospitalInfo;
  HospitalList hospitalList;

  SearchScreen searchScreen;

  Support support;
  BlogPost blogPost;

  AccountInfo accountInfo;
  SavedBlogs savedBlogs;
  Help help;
  ContactScreen contactScreen;
  EditProfile editProfile;
  MedicineCourse medicineCourse;

  // Doctors Screens
  LoginDoctor loginDoctor;
  SignupDoctor signupDoctor;
  HomeDoctor homeDoctor;
  EditProfileDoctor editProfileDoctor;
  DoctorAppointmentListScreen appointmentsDoctor;
}
