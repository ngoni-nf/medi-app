// GENERATED CODE - DO NOT MODIFY BY HAND

import 'package:auto_route/auto_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:medivic/controllers/appointmentSetupController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/blogModel.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/models/hospitalModel.dart';
import 'package:medivic/screens/accountInfo/accountInfo.dart';
import 'package:medivic/screens/accountInfo/contactScreen.dart';
import 'package:medivic/screens/accountInfo/editProfileInfo.dart';
import 'package:medivic/screens/accountInfo/help/help.dart';
import 'package:medivic/screens/accountInfo/medicineCourse.dart';
import 'package:medivic/screens/accountInfo/savedBlogs.dart';
import 'package:medivic/screens/appointment/patient_appointments.dart';
import 'package:medivic/screens/blogs/blogPost.dart';
import 'package:medivic/screens/blogs/blogScreen.dart';
import 'package:medivic/screens/call/agora/video_call.dart';
import 'package:medivic/screens/doctorInfo/doctorInfo.dart';
import 'package:medivic/screens/doctorList/doctorList.dart';
import 'package:medivic/screens/doctorsAccountScreens/appointments/doctor_appointments.dart';
import 'package:medivic/screens/doctorsAccountScreens/editProfileDoctor/editProfileDoctor.dart';
import 'package:medivic/screens/doctorsAccountScreens/loginDoctor/loginDoctor.dart';
import 'package:medivic/screens/doctorsAccountScreens/signupDoctor/form/DoctorPinCodeVerificationScreen.dart';
import 'package:medivic/screens/doctorsAccountScreens/signupDoctor/signupDoctor.dart';
import 'package:medivic/screens/home/main_screen.dart';
import 'package:medivic/screens/home/main_screen_doctor.dart';
import 'package:medivic/screens/hospitalInfo/hospitalInfo.dart';
import 'package:medivic/screens/hospitalList/hospitalList.dart';
import 'package:medivic/screens/login/login.dart';
import 'package:medivic/screens/onBoarding/onBoarding.dart';
import 'package:medivic/screens/review/review.dart';
import 'package:medivic/screens/search/searchScreen.dart';
import 'package:medivic/screens/signup/form/PinCodeVerificationScreen.dart';
import 'package:medivic/screens/signup/signup.dart';
import 'package:medivic/screens/splash/choose_screen.dart';
import 'package:medivic/screens/splash/splash.dart';
import 'package:medivic/screens/support/support.dart';
import 'package:medivic/services/payment/paymentPeach.dart';

abstract class Routes {
  static const splashScreen = '/';
  static const login = '/login';
  static const choose = '/choose';
  static const signup = '/signup';
  static const otpScreen = '/PinCodeVerificationScreen';
  static const doctorOtpScreen = '/DoctorPinCodeVerificationScreen';
  static const home = '/home';
  static const onBoarding = '/on-boarding';
  static const chat = '/chat';
  static const call = '/call';
  static const review = '/review';
  static const paymentWebview = '/payment-webview';
  static const communicationController = '/communication-controller';
  static const appointmentSetupController = '/appointment-setup-controller';
  static const blogsScreen = '/blogs-screen';
  static const doctorInfo = '/doctor-info';
  static const doctorsList = '/doctors-list';
  static const hospitalInfo = '/hospital-info';
  static const hospitalList = '/hospital-list';
  static const searchScreen = '/search-screen';
  static const support = '/support';
  static const blogPost = '/blog-post';
  static const accountInfo = '/account-info';
  static const savedBlogs = '/saved-blogs';
  static const appointments = '/appointments';
  static const help = '/help';
  static const contactScreen = '/contact-screen';
  static const editProfile = '/edit-profile';
  static const medicineCourse = '/medicine-course';
  static const loginDoctor = '/login-doctor';
  static const signupDoctor = '/signup-doctor';
  static const homeDoctor = '/home-doctor';
  static const editProfileDoctor = '/edit-profile-doctor';
  static const updateAddress = '/update-address';
  static const appointmentsDoctor = '/appointments-doctor';
  static const prescription = '/prescription';
  static const all = {
    splashScreen,
    login,
    signup,
    home,
    onBoarding,
    chat,
    call,
    review,
    paymentWebview,
    communicationController,
    appointmentSetupController,
    blogsScreen,
    doctorInfo,
    doctorsList,
    hospitalInfo,
    hospitalList,
    searchScreen,
    support,
    blogPost,
    accountInfo,
    savedBlogs,
    appointments,
    help,
    contactScreen,
    editProfile,
    medicineCourse,
    loginDoctor,
    signupDoctor,
    homeDoctor,
    editProfileDoctor,
    updateAddress,
    appointmentsDoctor,
    prescription,
  };
}

class AppRouter extends RouterBase {
  @override
  Set<String> get allRoutes => Routes.all;

  @Deprecated('call ExtendedNavigator.ofRouter<Router>() directly')
  static ExtendedNavigatorState get navigator => ExtendedNavigator.ofRouter<AppRouter>();

  @override
  Route<dynamic> onGenerateRoute(RouteSettings settings) {
    final args = settings.arguments;
    switch (settings.name) {
      case Routes.splashScreen:
        if (hasInvalidArgs<SplashScreenArguments>(args)) {
          return misTypedArgsRoute<SplashScreenArguments>(args);
        }
        final typedArgs = args as SplashScreenArguments ?? SplashScreenArguments();
        return CupertinoPageRoute<dynamic>(
          builder: (context) => SplashScreen(key: typedArgs.key),
          settings: settings,
        );
      case Routes.login:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const Login(),
          settings: settings,
        );
      case Routes.choose:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const Choose(),
          settings: settings,
        );
      case Routes.signup:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const Signup(),
          settings: settings,
        );
      case Routes.otpScreen:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => PinCodeVerificationScreen("1", "1", "1"),
          settings: settings,
        );
      case Routes.doctorOtpScreen:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => DoctorPinCodeVerificationScreen("1", "1", "1"),
          settings: settings,
        );
      case Routes.home:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => MainScreen(),
          settings: settings,
        );
      case Routes.onBoarding:
        if (hasInvalidArgs<OnBoardingArguments>(args)) {
          return misTypedArgsRoute<OnBoardingArguments>(args);
        }
        final typedArgs = args as OnBoardingArguments ?? OnBoardingArguments();
        return CupertinoPageRoute<dynamic>(
          builder: (context) => OnBoarding(key: typedArgs.key),
          settings: settings,
        );
      case Routes.call:
        if (hasInvalidArgs<CallArguments>(args)) {
          return misTypedArgsRoute<CallArguments>(args);
        }
        final typedArgs = args as CallArguments ?? CallArguments();
        return CupertinoPageRoute<dynamic>(
          builder: (context) => VideoCallScreen(
            key: typedArgs.key,
            channelName: typedArgs.channelName,
          ),
          settings: settings,
        );
      case Routes.review:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const Review(),
          settings: settings,
        );
      case Routes.paymentWebview:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => PaymentPeach(),
          settings: settings,
        );
      case Routes.appointmentSetupController:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => AppointmentSetupController(),
          settings: settings,
        );
      case Routes.blogsScreen:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const BlogsScreen(),
          settings: settings,
        );
      case Routes.doctorInfo:
        if (hasInvalidArgs<DoctorInfoArguments>(args)) {
          return misTypedArgsRoute<DoctorInfoArguments>(args);
        }
        final typedArgs = args as DoctorInfoArguments ?? DoctorInfoArguments();
        return CupertinoPageRoute<dynamic>(
          builder: (context) => DoctorInfo(key: typedArgs.key, doctor: typedArgs.doctor),
          settings: settings,
        );
      case Routes.doctorsList:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const DoctorsList(),
          settings: settings,
        );
      case Routes.hospitalInfo:
        if (hasInvalidArgs<HospitalInfoArguments>(args)) {
          return misTypedArgsRoute<HospitalInfoArguments>(args);
        }
        final typedArgs = args as HospitalInfoArguments ?? HospitalInfoArguments();
        return CupertinoPageRoute<dynamic>(
          builder: (context) => HospitalInfo(key: typedArgs.key, hospital: typedArgs.hospital),
          settings: settings,
        );
      case Routes.hospitalList:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const HospitalList(),
          settings: settings,
        );
      case Routes.searchScreen:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const SearchScreen(),
          settings: settings,
        );
      case Routes.support:
        if (hasInvalidArgs<SupportArguments>(args)) {
          return misTypedArgsRoute<SupportArguments>(args);
        }
        final typedArgs = args as SupportArguments ?? SupportArguments();
        return CupertinoPageRoute<dynamic>(
          builder: (context) => Support(category: typedArgs.category, assetUrl: typedArgs.assetUrl),
          settings: settings,
        );
      case Routes.blogPost:
        if (hasInvalidArgs<BlogPostArguments>(args)) {
          return misTypedArgsRoute<BlogPostArguments>(args);
        }
        final typedArgs = args as BlogPostArguments ?? BlogPostArguments();
        return CupertinoPageRoute<dynamic>(
          builder: (context) => BlogPost(key: typedArgs.key, blog: typedArgs.blog),
          settings: settings,
        );
      case Routes.accountInfo:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const AccountInfo(),
          settings: settings,
        );
      case Routes.savedBlogs:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const SavedBlogs(),
          settings: settings,
        );
      case Routes.appointments:
        return CupertinoPageRoute<dynamic>(
          builder: (context) =>
              LocatorService.userProvider().user == null ? const DoctorAppointmentListScreen() : const PatientAppointmentListScreen(),
          settings: settings,
        );
      case Routes.help:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const Help(),
          settings: settings,
        );
      case Routes.contactScreen:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const ContactScreen(),
          settings: settings,
        );
      case Routes.editProfile:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const EditProfile(),
          settings: settings,
        );
      case Routes.medicineCourse:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const MedicineCourse(),
          settings: settings,
        );
      case Routes.loginDoctor:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const LoginDoctor(),
          settings: settings,
        );
      case Routes.signupDoctor:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const SignupDoctor(),
          settings: settings,
        );
      case Routes.homeDoctor:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const MainScreenDoctor(),
          settings: settings,
        );
      case Routes.editProfileDoctor:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const EditProfileDoctor(),
          settings: settings,
        );
      case Routes.appointmentsDoctor:
        return CupertinoPageRoute<dynamic>(
          builder: (context) => const DoctorAppointmentListScreen(),
          settings: settings,
        );
      default:
        return unknownRoutePage(settings.name);
    }
  }
}

// *************************************************************************
// Arguments holder classes
// **************************************************************************

//SplashScreen arguments holder class
class SplashScreenArguments {
  SplashScreenArguments({this.key});

  final Key key;
}

//OnBoarding arguments holder class
class OnBoardingArguments {
  OnBoardingArguments({this.key});

  final Key key;
}

//Call arguments holder class
class CallArguments {
  CallArguments({this.key, this.channelName, this.isAudio});

  final Key key;
  final String channelName;
  final bool isAudio;
}

//DoctorInfo arguments holder class
class DoctorInfoArguments {
  DoctorInfoArguments({this.key, this.doctor});

  final Key key;
  final Doctor doctor;
}

//HospitalInfo arguments holder class
class HospitalInfoArguments {
  HospitalInfoArguments({this.key, this.hospital});

  final Key key;
  final Hospital hospital;
}

//Support arguments holder class
class SupportArguments {
  SupportArguments({this.category, this.assetUrl});

  final String category;
  final String assetUrl;
}

//BlogPost arguments holder class
class BlogPostArguments {
  BlogPostArguments({this.key, this.blog});

  final Key key;
  final Blog blog;
}
