// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:permission_handler/permission_handler.dart';

Future<bool> handleCameraAndMic() async {
  final PermissionStatus cameraPermission =
      await PermissionHandler().checkPermissionStatus(PermissionGroup.camera);
  final PermissionStatus micPermission = await PermissionHandler()
      .checkPermissionStatus(PermissionGroup.microphone);

  if (cameraPermission == PermissionStatus.granted &&
      micPermission == PermissionStatus.granted) {
    return true;
  } else {
    await PermissionHandler().requestPermissions(
      [PermissionGroup.camera, PermissionGroup.microphone],
    );
    final PermissionStatus cameraPermission =
        await PermissionHandler().checkPermissionStatus(PermissionGroup.camera);
    final PermissionStatus micPermission = await PermissionHandler()
        .checkPermissionStatus(PermissionGroup.microphone);
    if (cameraPermission == PermissionStatus.granted &&
        micPermission == PermissionStatus.granted) {
      return true;
    } else {
      return false;
    }
  }
}

Future<bool> requestPermissions() async {
  await PermissionHandler().requestPermissions(
    [PermissionGroup.camera, PermissionGroup.microphone],
  );
  return await handleCameraAndMic();
}

Future<void> openSettings() async {
  await PermissionHandler().openAppSettings();
}
