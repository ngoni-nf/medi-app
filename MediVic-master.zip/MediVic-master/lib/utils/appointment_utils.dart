import 'package:medivic/extensions/date_extensions.dart';
import 'package:medivic/models/slot.dart';

abstract class AppointmentUtils {
  static const Duration _perPatientDuration = Duration(minutes: 20);
  static const _officeStartEnd = [8, 18];

  static List<DateTime> getMonthDays(int year, int month) {
    final List<DateTime> days = [];
    DateTime dayOfMonth = DateTime(year, month, 1);
    while (dayOfMonth.month == month) {
      if (!dayOfMonth.isBeforeToday()) {
        days.add(dayOfMonth);
      }
      dayOfMonth = dayOfMonth.add(const Duration(days: 1));
    }
    return days;
  }

  static List<DateTime> getWeekDays(DateTime dateTime) {
    final List<DateTime> days = [];
    DateTime dayOfWeek =
        dateTime.subtract(Duration(days: dateTime.weekday - 1));
    for (int i = 0; i < 7; i++) {
      if (!dayOfWeek.isBeforeToday()) {
        days.add(dayOfWeek);
      }
      dayOfWeek = dayOfWeek.add(const Duration(days: 1));
    }
    return days;
  }

  static List<Slot> generateSlots(DateTime date) {
    final DateTime officeStart =
        DateTime(date.year, date.month, date.day, _officeStartEnd[0]);
    final DateTime officeEnd =
        DateTime(date.year, date.month, date.day, _officeStartEnd[1]);
    DateTime start = DateTime(date.year, date.month, date.day);

    final List<Slot> slots = [];
    while (start.day == date.day) {
      final DateTime end = start.add(_perPatientDuration);
      final bool insideOfficeHours =
          start.isSameOfAfter(officeStart) && end.isSameOfBefore(officeEnd);
      final Slot slot = Slot(
        date,
        start.formatFullTime(),
        end.formatFullTime(),
        insideOfficeHour: insideOfficeHours,
      );
      slots.add(slot);
      start = end;
    }
    return slots;
  }
}
