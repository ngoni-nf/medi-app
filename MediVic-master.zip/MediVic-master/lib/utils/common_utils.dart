import 'dart:math';

import 'package:flutter/material.dart';
import 'package:google_map_location_picker/google_map_location_picker.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/addressModel.dart';

class CommonUtils {
  static Future<LocationResult> openLocationPicker(BuildContext context) async {
    Location location = Location.empty();
    final user = LocatorService.userProvider().user;
    if (user != null) {
      location = user.address?.location ?? location;
    } else {
      final doctor = LocatorService.doctorProvider().doctor;
      if (doctor != null) {
        location = doctor.location ?? location;
      }
    }
    return await showLocationPicker(
      context,
      Config.GOOGLE_MAP_API_KEY,
      initialCenter: LatLng(location.lat, location.lng),
      automaticallyAnimateToCurrentLocation: true,
      myLocationButtonEnabled: true,
      layersButtonEnabled: true,
    );
  }

  static int generateNotificationId() {
    return Random().nextInt(99999);
  }

  static double parseDouble(dynamic value) {
    if (value == null) {
      return 0;
    } else if (value is double) {
      return value;
    } else if (value is int) {
      return value.toDouble();
    } else {
      return double.tryParse(value);
    }
  }

}
