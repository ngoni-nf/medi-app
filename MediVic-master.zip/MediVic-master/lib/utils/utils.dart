import 'dart:io';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class Utils {
  static String getTimeStr(DateTime dateTime) {
    return DateFormat('HH:mm a').format(dateTime);
  }

  static String getDateStr(DateTime dateTime) {
    return DateFormat('dd, MMMM yyyy').format(dateTime);
  }

  static DateTime getDateTime(dynamic dateTime) {
    try {
      if (dateTime is Timestamp) {
        return DateTime.fromMicrosecondsSinceEpoch(
            dateTime.microsecondsSinceEpoch);
      } else if (dateTime is Map && dateTime.containsKey('_seconds')) {
        return DateTime.fromMillisecondsSinceEpoch(dateTime['_seconds'] * 1000);
      }
    } catch (e) {
      print(e);
    }
    return DateTime.now();
  }

  static Future<Uint8List> imageDownload(String url) async {
    Fluttertoast.showToast(msg: 'File downloading...');
    final StorageReference ref = await FirebaseStorage.instance.getReferenceFromUrl(url);
    final http.Response downloadData = await http.get(url);
    final Directory systemTmpDir = Directory.systemTemp;
    final File tmpFile = File('${systemTmpDir.path}/tmp.jpg');
    if (tmpFile.existsSync()) {
      tmpFile.delete();
    }
    await tmpFile.create();

    final StorageFileDownloadTask task = ref.writeToFile(tmpFile);
    final int byteCount = (await task.future).totalByteCount;
    return downloadData.bodyBytes;
  }

  static dynamic getJSONData(Map<String, dynamic> json, String key) {
    if (json.containsKey(key)) return json[key];
    return null;
  }
}
