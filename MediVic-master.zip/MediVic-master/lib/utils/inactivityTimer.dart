import 'dart:async';
import 'dart:developer';

import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/authController.dart';

import '../locator.dart';

class InactivityTimer {
  Timer _keepAliveTimer;
  bool _isEnable = true;

  void _initializeTimer() {
    if (_keepAliveTimer != null) {
      _keepAliveTimer.cancel();
    }
    _keepAliveTimer = Timer(const Duration(minutes: 4), () => _logout());
  }

  void setActivity(bool isEnable) {
    _isEnable = isEnable;
    log('Inactivity $_isEnable', name: 'Inactivity');
  }

  void resetTimer() async {
    final user = await LocatorService.authService().currentUser();
    if (user != null) {
      _keepAliveTimer?.cancel();
      _keepAliveTimer = null;
      _initializeTimer();
      log('RESET TIMER', name: 'Inactivity');
    }
  }

  void _logout() async {
    if (!_isEnable) {
      return;
    }

    LocatorService.pushNotificationService().showNotification({
      'notification': {
        'title': 'Logout',
        'body': AppStrings.msgInactivity,
      }
    }, notificationId: 1);
    await AuthController.logout();
    // SystemNavigator.pop();
  }
}
