import 'dart:developer';

import 'package:email_validator/email_validator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/userModel.dart';
import 'package:medivic/screens/splash/choose_screen.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/services/authentication/firebaseAuthService.dart';
import 'package:medivic/services/storage/localStorage.dart';
import 'package:medivic/services/storage/storageConstants.dart';

class AuthController {
// Validates the email
  static String validateEmail(String email) {
    return EmailValidator.validate(email)
        ? null
        : AppStrings.invalidEmailErrorText;
  }

  // Validates the password
  static String validatePassword(String password) {
    final int len = password.toString().length;
    if (len < 6) {
      return len == 0
          ? AppStrings.invalidPasswordEmpty
          : AppStrings.invalidPasswordTooShort;
    } else {
      return null;
    }
  }

  static String validateFirstName(String name) {
    final int len = name.toString().length;
    if (len < 3) {
      return AppStrings.invalidFirstNameEmpty;
    } else {
      return null;
    }
  }

  static String validateLastName(String name) {
    final int len = name.toString().length;
    if (len < 3) {
      return AppStrings.invalidLastNameEmpty;
    } else {
      return null;
    }
  }

  static String validateAddress(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidAddressEmpty;
    } else {
      return null;
    }
  }

  static String validatecountry(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidAddressEmpty;
    } else {
      return null;
    }
  }

  static String validatePincode(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidAddressEmpty;
    } else {
      return null;
    }
  }

  static String validateStateName(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidStateNameEmpty;
    } else {
      return null;
    }
  }

  static String validateStreateName(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidStreetNameEmpty;
    } else {
      return null;
    }
  }

  static String validateDateOfBirth(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidDateOfBirthEmpty;
    } else {
      return null;
    }
  }

  static String validateNationalId(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidateNationalIdEmpty;
    } else {
      return null;
    }
  }

  static String validatePhoneId(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidatePhoneEmpty;
    } else if (!name.contains('+')) {
      return AppStrings.invalidatePhonestartEmpty;
    } else {
      return null;
    }
  }

  static String validateAge(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidateAgeLength;
    } else {
      return null;
    }
  }

  static String validatHhpcsaNumber(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidateHpcsaNumberEmpty;
    } else {
      return null;
    }
  }

  static String validatIPANumber(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidateIPANumberEmpty;
    } else {
      return null;
    }
  }

  static String validatGroupPracticeNumber(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidateGroupPracticeNumberEmpty;
    } else {
      return null;
    }
  }

  static String validatBriefProfile(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidateBriefProfileEmpty;
    } else {
      return null;
    }
  }

  static String validatlanguage(String name) {
    final int len = name.toString().length;
    if (len == 0) {
      return AppStrings.invalidatePreferredLanguageEmpty;
    } else {
      return null;
    }
  }

  // Validates the confirm password field
  static String validateConfirmPassword(
      String confirmPassword, String password) {
    return password.toString() != confirmPassword.toString()
        ? AppStrings.invalidPasswordNoMatch
        : null;
  }

  static bool validateForm(GlobalKey<FormState> formKey) {
    if (formKey.currentState.validate()) {
      return true;
    } else {
      return false;
    }
  }

  // Save the credentials to local storage for later use upon startup
  static Future<void> saveCredentials(String userId, String email) async {
    await LocalStorage.setString(LocalStorageConstants.USER_ID, userId);
    // await LocalStorage.setString(LocalStorageConstants.EMAIL, email);
    await LocalStorage.setString(
      LocalStorageConstants.ACCOUNT_TYPE,
      LocalStorageConstants.NORMAL_ACCOUNT_TYPE,
    );
    await LocalStorage.setString(LocalStorageConstants.INITIAL_INSTALL, 'done');
  }

  // Save the credentials to local storage for later use upon startup
  static Future<void> saveDoctorCredentials(
      String doctorId, String email) async {
    await LocalStorage.setString(LocalStorageConstants.DOCTOR_ID, doctorId);
    // await LocalStorage.setString(LocalStorageConstants.EMAIL, email);
    await LocalStorage.setString(
      LocalStorageConstants.ACCOUNT_TYPE,
      LocalStorageConstants.DOCTOR_ACCOUNT_TYPE,
    );
    await LocalStorage.setString(LocalStorageConstants.INITIAL_INSTALL, 'done');
  }

  // Set the userId in the provider for future reference.
  static void setUserId(String userId) {
    LocatorService.userProvider().setUserId(userId);
  }

  // Set the doctorId in the provider for future reference.
  static void setDoctorId(String doctorId) {
    LocatorService.doctorProvider().setDoctorId(doctorId);
  }

  /// `Login Specific functions:`

  // Login to the app with email and password
  static Future<FAuthUser> login(String email, String password) async {
    final FAuthUser userInfo =
        await FirebaseAuthService().signInWithEmailAndPassword(
      email,
      password,
    );

    return userInfo;
  }

  // Logout function
  static Future<void> logout() async {
    // pop the navigator route.
    NavigationController.navigator.pop();
    NavigationController.navigator.pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => const Choose()),
        ModalRoute.withName(Routes.choose));
    LocatorService.authService().signOut();
    LocatorService.reset();
    // await LocalStorage.clear();
  }

  /// `SignUp specific functions:`

  // Creates a new users for the app with email and password
  // static Future<FAuthUser> signup(String email, String password, String firstName, String lastName, String age, String phoneNumber, String dob,
  //     String nationalId, String gender, PatientAddress address) async {
  //   final FAuthUser userInfo = await FirebaseAuthService().createUserWithEmailAndPassword(email, password);
  //
  //   if (userInfo.uid.isNotEmpty) {
  //     /// [Important]
  //     /// Run this function every time to create a user document.
  //
  //     final User user = User(
  //       uid: userInfo.uid,
  //       email: userInfo.email,
  //       phoneNumber: phoneNumber,
  //       age: age,
  //       name: firstName.isNotEmpty ? firstName : email != null ? email.split('@')[0] : userInfo.uid.substring(0, 7),
  //       lastName: lastName,
  //       gender: gender,
  //       dob: dob,
  //       imageUrl: Config.placeholedImageUrl,
  //       address: address,
  //       createdAt: DateTime.now(),
  //       updatedAt: DateTime.now(),
  //     )
  //
  //
  //     await FirestoreService.createUser(userInfo.uid, userInfo.email, firstName, lastName, age, phoneNumber, dob, nationalId, gender, address);
  //   }
  //
  //   return userInfo;
  // }

  // Creates a new doctor for the app with email and password
  static Future<FAuthUser> signupDoctor(
      String email, String password, Map<String, dynamic> data) async {
    final FAuthUser userInfo = await FirebaseAuthService()
        .createUserWithEmailAndPassword(email, password);

    if (userInfo.uid.isNotEmpty) {
      /// [Important]
      /// Run this function every time to create a doctor document.
      await FirestoreService.createDoctor(userInfo.uid, userInfo.email, data);
    }

    return userInfo;
  }

  /// [Navigation handler]
  static void navigateToHome() {
    NavigationController.navigator.pushReplacementNamed(Routes.home);
  }

  static void navigateToLogin() {
    NavigationController.navigator.pushReplacementNamed(Routes.login);
  }

  static void navigateToSignUp() {
    NavigationController.navigator.pushReplacementNamed(Routes.signup);
  }

  static void navigateToOTPScreen() {
    NavigationController.navigator.pushReplacementNamed(Routes.otpScreen);
  }

  static void navigateToDoctorOTPScreen() {
    NavigationController.navigator.pushReplacementNamed(Routes.doctorOtpScreen);
  }

  static void navigateToDoctorHome() {
    NavigationController.navigator.pushReplacementNamed(Routes.homeDoctor);
  }

  /// [Auth Providers] to create users
  static Future<FAuthUser> signInWithGoogle() async {
    try {
      final FAuthUser userInfo = await FirebaseAuthService().signInWithGoogle();
      if (userInfo == null) {
        log(
          'No userInfo found',
          name: 'Auth controller',
        );
        // log(e.code, name: 'Error code: Auth');
        Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
        return null;
      }
      return userInfo;
    } on PlatformException catch (e) {
      log(e.message, name: 'Error message: Login page');
      // log(e.code, name: 'Error code: Login page');
      // Change the loading status of the overlay.
      LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(false);
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
    } catch (e) {
      // log(e, name: 'Error: Login Page');
      // Change the loading status of the overlay.
      LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(false);
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
    }
  }

  static Future<void> signInWithFacebook() async {
    try {
      final FAuthUser userInfo =
          await FirebaseAuthService().signInWithFacebook();

      log('$userInfo', name: 'Auth Facebook');

      if (userInfo == null) {
        log(
          'No userInfo found',
          name: 'Error message: Auth platform exception',
        );
        // log(e.code, name: 'Error code: Auth');
        Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
        return;
      }

      // Change the loading status of the overlay.
      LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(true);

      if (userInfo.uid.isNotEmpty) {
        final bool isDataAvailable =
            await LocatorService.userProvider().fetchUserData(userInfo.uid);

        if (isDataAvailable) {
          final user = LocatorService.userProvider().user;
          if (user.isBlock) {
            Fluttertoast.showToast(msg: AppStrings.blockedMsg);
            LocatorService.uiAuthProvider()
                .changeSocialLoginLoadingStatus(false);
            return;
          }
          setUserId(userInfo.uid);
          LocatorService.pushNotificationService()
              .manageNotificationsAtAuth(userId: userInfo.uid);

          await saveCredentials(userInfo.uid, userInfo.email);
          // Change the loading status of the overlay.
          LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(false);
          navigateToHome();
        } else {
          /// [Important]
          /// Run this function every time to create a user document.
          // await FirestoreService.createUser(userInfo.uid, userInfo.email, "", "", "", "", "", "", "", PatientAddress.empty());

          final bool isDataAvailable =
              await LocatorService.userProvider().fetchUserData(userInfo.uid);

          if (isDataAvailable) {
            setUserId(userInfo.uid);
            LocatorService.pushNotificationService()
                .manageNotificationsAtAuth(userId: userInfo.uid);

            await saveCredentials(userInfo.uid, userInfo.email);
            // Change the loading status of the overlay.
            LocatorService.uiAuthProvider()
                .changeSocialLoginLoadingStatus(false);
            navigateToHome();
          }
        }
      }
    } on PlatformException catch (e) {
      log(e.message, name: 'Error message: Auth platform exception');
      // log(e.code, name: 'Error code: Auth');
      // Change the loading status of the overlay.
      LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(false);
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
    } catch (e) {
      log(e.toString(), name: 'Error: Auth');
      // Change the loading status of the overlay.
      LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(false);
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
    }
  }
}
