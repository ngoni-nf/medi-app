import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/notification.dart';
import 'package:medivic/screens/appointment/patient_appointments.dart';
import 'package:medivic/screens/doctorsAccountScreens/appointments/doctor_appointments.dart';

class NotificationScreen extends StatefulWidget {
  @override
  _NotificationScreenState createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: _buildAppBar(), body: _buildBody());
  }

  AppBar _buildAppBar() {
    return AppBar(
      iconTheme: const IconThemeData(color: Colors.white),
      centerTitle: true,
      title: const Text(
        'Notifications',
        style: styleAppbarTitle,
      ),
      backgroundColor: appBarColor,
    );
  }

  Widget _buildBody() {
    final String userId = LocatorService.userProvider().user?.uid ?? LocatorService.doctorProvider().doctor.uid;
    final bool isPatient = LocatorService.userProvider().user != null;
    return StreamBuilder<QuerySnapshot>(
        stream: Firestore.instance
            .collection('notifications')
            .where('userId', isEqualTo: userId)
            .where('isPatient', isEqualTo: isPatient)
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          final List<InAppNotification> notifications = InAppNotification.parseList(snapshot);
          return notifications.isNotEmpty ? _buildListView(notifications) : _buildNoNotificationsLabel();
        });
  }

  Widget _buildListView(List<InAppNotification> notifications) {
    return ListView.builder(itemCount: notifications.length, itemBuilder: (context, index) => NotificationContainer(notifications[index]));
  }

  Widget _buildNoNotificationsLabel() {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Text(
          'You currently have no new notifications.',
          style: TextStyle(fontFamily: fontMontserrat),
        ),
      ),
    );
  }
}

class NotificationContainer extends StatelessWidget {
  final bool isClickable;

  const NotificationContainer(
    this.notification, {
    Key key,
    this.isClickable = true,
  }) : super(key: key);

  final InAppNotification notification;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => isClickable ? _navigateToNextScreen(context, notification.type) : null,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                notification.getDateTime(),
                style: const TextStyle(
                  fontFamily: fontMontserrat,
                  fontSize: 12,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                notification.title,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontFamily: fontMontserrat,
                  color: darkBlueColor,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                notification.body,
                style: const TextStyle(fontFamily: fontMontserrat),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _navigateToNextScreen(BuildContext context, String notificationType) {
    switch (notificationType) {
      case 'APPOINTMENT':
        NavigationController.navigator.push(MaterialPageRoute(
            builder: (context) =>
                LocatorService.userProvider().user == null ? const DoctorAppointmentListScreen() : const PatientAppointmentListScreen()));
        break;
    }
  }
}
