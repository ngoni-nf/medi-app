// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/extensions/string_extensions.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/providers/doctorsDataProvider.dart';
import 'package:medivic/providers/widgets/viewStateSelector.dart';
import 'package:provider/provider.dart';

//
/// ## `Description`
///
/// Screen to show the list of doctors available for the selected
/// format ( call, message, video call, etc ).
///
class DoctorsList extends StatelessWidget {
  const DoctorsList({this.speciality, Key key}) : super(key: key);

  final String speciality;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          AppStrings.doctors,
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: const Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
        ),
      ),
      body: ChangeNotifierProvider.value(
        value: LocatorService.doctorDataProvider(),
        child: ViewStateSelector<DoctorDataProvider>(
          getData: () => LocatorService.doctorDataProvider().getDoctors(),
          child: ListContainer(speciality),
        ),
      ),
    );
  }
}

///
/// ## `Description`
///
/// Widget to get the list of the data and display it using a Future.
/// It waits for the Future while displaying a loading indicator and
/// show the list when the Future is complete.
///

class ListContainer extends StatefulWidget {
  const ListContainer(this.speciality);

  final String speciality;

  @override
  _ListContainerState createState() => _ListContainerState();
}

class _ListContainerState extends State<ListContainer> {
  bool isPerformingRequest = false;

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return Selector<DoctorDataProvider, List<Doctor>>(
      selector: (context, d) => d.doctorList,
      // shouldRebuild: (a, b) => true,
      builder: (context, list, _) {
        list = Doctor.filterDoctorsBySpeciality(list, widget.speciality);
        return RefreshIndicator(
          color: Colors.black,
          onRefresh: () => LocatorService.doctorDataProvider().getDoctors(),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              15.0,
              0.0,
              15.0,
              0.0,
            ),
            child: list.isEmpty
                ? const Center(
                    child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Text(
                      AppStrings.noDoctorsForSpecialization,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontFamily: fontMontserrat),
                    ),
                  ))
                : GridView.builder(
                    shrinkWrap: true,
                    physics: const ScrollPhysics(),
                    scrollDirection: Axis.vertical,
                    addAutomaticKeepAlives: true,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 8.0,
                      mainAxisSpacing: 8.0,
                      childAspectRatio: 0.7,
                    ),
                    itemCount: list.length,
                    itemBuilder: (BuildContext context, int index) {
                      return _buildDoctorGridItem(list[index]);
                    },
                  ),
          ),
        );
      },
    );
  }

  Widget _buildDoctorGridItem(Doctor doctor) {
    return GestureDetector(
      onTap: () => NavigationController.navigator.pushNamed(
        Routes.doctorInfo,
        arguments: DoctorInfoArguments(doctor: doctor),
      ),
      child: Card(
        elevation: 5.0,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 10.0,
            vertical: 8.0,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 120.0,
                // width: 140.0,
                child: CachedNetworkImage(
                  imageUrl:
                      doctor.imageUrl ?? 'https://via.placeholder.com/100',
                  imageBuilder: (context, imageProvider) => Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: imageProvider,
                        fit: BoxFit.cover,
                      ),
                      borderRadius: const BorderRadius.all(
                        Radius.circular(
                          10.0,
                        ),
                      ),
                    ),
                  ),
                  errorWidget: (context, url, error) => const Icon(Icons.error),
                ),
              ),
              const SizedBox(
                height: 6.0,
              ),
              Text(
                '${AppStrings.dr} ' + doctor.name,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  fontFamily: fontMontserrat,
                ),
                maxLines: 2,
                textAlign: TextAlign.center,
                // overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(
                height: 2.0,
              ),
              Text(
                StringUtils.capFirstOfEach(doctor.specialities[0]),
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                  color: Colors.black38,
                  fontFamily: fontMontserrat,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(
                height: 2.0,
              ),
              Text(
                '${AppStrings.exp}: ' +
                    doctor.experience +
                    ' ${AppStrings.years}',
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                  color: Colors.black38,
                  fontFamily: fontMontserrat,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(
                height: 2.0,
              ),
              Text(
                '${Config.CURRENCY_SYMBOL.isNotEmpty ? Config.CURRENCY_SYMBOL : Config.CURRENCY}${doctor.fee ?? ' '}',
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                  color: Colors.black38,
                  fontFamily: fontMontserrat,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
