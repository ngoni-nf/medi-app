import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/screens/appointment/book_appointment.dart';

class Specialization extends StatefulWidget {
  const Specialization(this.doctor);

  final Doctor doctor;

  @override
  _SpecializationState createState() => _SpecializationState();
}

class _SpecializationState extends State<Specialization> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Specializations',
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            ListView.builder(
                itemCount: widget.doctor.specialities.length,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  return Text(
                    widget.doctor.specialities.length > 1 ? '• ' : '' + widget.doctor.specialities[index],
                    style: const TextStyle(
                      fontSize: 16.0,
                      fontFamily: fontMontserrat,
                      color: Colors.black38,
                    ),
                  );
                }),
            const SizedBox(
              height: 50,
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.8,
              height: 50,
              child: RaisedButton(
                color: appBarColor,
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => BookAppointmentScreen(widget.doctor))),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                child: const Text(
                  'Book Appointment',
                  style: TextStyle(color: Colors.white, fontFamily: fontMontserrat, fontSize: 18, fontWeight: FontWeight.normal),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
