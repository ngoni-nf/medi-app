// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/controllers/uiController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/screens/appointment/book_appointment.dart';
import 'package:medivic/screens/doctorInfo/education_screen.dart';
import 'package:medivic/screens/doctorInfo/experience_screen.dart';
import 'package:medivic/screens/doctorInfo/specialization_screen.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/shared/widgets/categoryOptionsModal.dart';
import 'package:medivic/shared/widgets/readmore.dart';
import 'package:medivic/utils/validators.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:medivic/extensions/string_extensions.dart';

import 'membership_screen.dart';

class DoctorInfo extends StatefulWidget {
  const DoctorInfo({Key key, this.doctor}) : super(key: key);
  final Doctor doctor;

  @override
  _DoctorInfoState createState() => _DoctorInfoState();
}

class _DoctorInfoState extends State<DoctorInfo> {
  double rating = 0;
  String comments = '';
  bool _isGetData = true;

  @override
  void initState() {
    super.initState();
    getRating();
  }

  getRating() async {
    await FirestoreService.getRating(
            LocatorService.userProvider().user.uid, widget.doctor.uid)
        .then((value) {
          setState(() {
            _isGetData = false;
            rating = value['rating'];
            comments = value['comment'];
          });
        })
        .timeout(const Duration(seconds: 30))
        .catchError((error) {
          setState(() {
            _isGetData = false;
          });
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          '${AppStrings.dr} ${widget.doctor.name}',
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 20.0,
        ),
        child: ListView(
          shrinkWrap: true,
          children: [
            const SizedBox(
              height: 40.0,
            ),
            Row(
              // mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: 115,
                  width: 115,
                  decoration: BoxDecoration(
                    // boxShadow: const [
                    //   BoxShadow(
                    //     color: Colors.black12,
                    //     spreadRadius: 3,
                    //     blurRadius: 10,
                    //   )
                    // ],
                    borderRadius: const BorderRadius.all(
                      Radius.circular(60.0),
                    ),
                    image: DecorationImage(
                      fit: BoxFit.cover,
                      image: CachedNetworkImageProvider(widget.doctor.imageUrl),
                    ),
                  ),
                ),
                const SizedBox(
                  width: 20.0,
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${AppStrings.dr} ${widget.doctor.name}',
                        style: const TextStyle(
                          fontFamily: fontMontserrat,
                          fontSize: 16.0,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        widget.doctor.specialities[0],
                        style: const TextStyle(
                          fontFamily: fontMontserrat,
                          fontSize: 12.0,
                          color: Colors.black38,
                          // fontWeight: FontWeight.w600,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        widget.doctor.experience + ' years experience overall',
                        style: const TextStyle(
                          fontFamily: fontMontserrat,
                          fontSize: 12.0,
                          color: Colors.black38,
                          // fontWeight: FontWeight.w600,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      SmoothStarRating(
                        allowHalfRating: false,
                        onRated: (v) {},
                        starCount: 5,
                        rating: widget.doctor.rating ?? 0,
                        size: 20.0,
                        isReadOnly: true,
                        color: Colors.orange,
                        borderColor: Colors.orange,
                        spacing: 0.0,
                      )
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 30.0,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 15.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    _getAddress(widget.doctor),
                    style: const TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.normal,
                      fontFamily: fontMontserrat,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        'Consultation Fees: ${Config.CURRENCY_SYMBOL.isNotEmpty ? Config.CURRENCY_SYMBOL : Config.CURRENCY} ${widget.doctor.fee}',
                        style: const TextStyle(
                          fontSize: 16.0,
                          fontFamily: fontMontserrat,
                          color: Colors.black38,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 20.0,
            ),
            const Divider(
              color: Colors.black38,
            ),
            const SizedBox(
              height: 25.0,
            ),
            RaisedButton(
              color: appBarColor,
              padding: const EdgeInsets.all(
                18.0,
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          BookAppointmentScreen(widget.doctor)),
                );
              },
              child: Stack(
                children: [
                  const Center(
                    child: Text(
                      'Book Appointment',
                      style: TextStyle(
                        fontSize: 20.0,
                        fontFamily: fontMontserrat,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  Center(
                    child: Visibility(
                        visible: _isGetData,
                        child: Container(
                          width: 24,
                          height: 24,
                          child: const CircularProgressIndicator(
                            backgroundColor: appBarColor,
                          ),
                        )),
                  )
                ],
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(
                  30.0,
                ),
                side: const BorderSide(
                  color: appBarColor,
                ),
              ),
            ),
            const SizedBox(
              height: 20.0,
            ),
            const Divider(
              color: Colors.black38,
            ),
            const SizedBox(
              height: 10.0,
            ),
            ListView(
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                const Text(
                  'Offered Services:',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0,
                    fontFamily: fontMontserrat,
                  ),
                ),
                const SizedBox(
                  height: 5.0,
                ),
                ListView.builder(
                    itemCount: widget.doctor.specialities.length,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemBuilder: (context, index) {
                      return Text(
                        '• ${StringUtils.capFirstOfEach(widget.doctor.specialities[index])}',
                        style: const TextStyle(
                          fontSize: 16.0,
                          fontFamily: fontMontserrat,
                          color: Colors.black38,
                        ),
                      );
                    }),
              ],
            ),
            const SizedBox(
              height: 20.0,
            ),
            const Divider(
              color: Colors.black38,
            ),
            const SizedBox(
              height: 10.0,
            ),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'More About Me',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18.0,
                      fontFamily: fontMontserrat,
                    ),
                  ),
                  const SizedBox(
                    height: 8.0,
                  ),
                  ReadMoreText(
                    widget.doctor.aboutme != null ? widget.doctor.aboutme : "",
                    trimLines: 2,
                    colorClickableText: appBarColor,
                    trimMode: TrimMode.Line,
                    trimCollapsedText: '  Read More',
                    trimExpandedText: ' Less',
                    style: const TextStyle(
                      fontFamily: fontMontserrat,
                    ),
                  ),
                  const SizedBox(
                    height: 30.0,
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  Specialization(widget.doctor)));
                    },
                    child: Container(
                      height: 65,
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.all(
                          Radius.circular(12.0),
                        ),
                        border: Border.all(
                          color: Colors.black12,
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(
                          right: 15.0,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              width: 15.0,
                              decoration: const BoxDecoration(
                                color: Colors.black38,
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(12.0),
                                  bottomLeft: Radius.circular(12.0),
                                ),
                              ),
                            ),
                            const Text(
                              'Specializations',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                                fontSize: 18.0,
                                fontFamily: fontMontserrat,
                              ),
                            ),
                            const Icon(
                              Icons.arrow_forward,
                              color: Colors.black38,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20.0,
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  Education(widget.doctor)));
                    },
                    child: Container(
                      height: 65,
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.all(
                          Radius.circular(12.0),
                        ),
                        border: Border.all(
                          color: Colors.black12,
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(
                          right: 15.0,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              width: 15.0,
                              decoration: const BoxDecoration(
                                color: Colors.black38,
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(12.0),
                                  bottomLeft: Radius.circular(12.0),
                                ),
                              ),
                            ),
                            const Text(
                              'Education',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                                fontSize: 18.0,
                                fontFamily: fontMontserrat,
                              ),
                            ),
                            const Icon(
                              Icons.arrow_forward,
                              color: Colors.black38,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20.0,
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  Experience(widget.doctor)));
                    },
                    child: Container(
                      height: 65,
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.all(
                          Radius.circular(12.0),
                        ),
                        border: Border.all(
                          color: Colors.black12,
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(
                          right: 15.0,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              width: 15.0,
                              decoration: const BoxDecoration(
                                color: Colors.black38,
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(12.0),
                                  bottomLeft: Radius.circular(12.0),
                                ),
                              ),
                            ),
                            const Text(
                              'Experience',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                                fontSize: 18.0,
                                fontFamily: fontMontserrat,
                              ),
                            ),
                            const Icon(
                              Icons.arrow_forward,
                              color: Colors.black38,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20.0,
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  Membership(widget.doctor)));
                    },
                    child: Container(
                      height: 65,
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.all(
                          Radius.circular(12.0),
                        ),
                        border: Border.all(
                          color: Colors.black12,
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(
                          right: 15.0,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              width: 15.0,
                              decoration: const BoxDecoration(
                                color: Colors.black38,
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(12.0),
                                  bottomLeft: Radius.circular(12.0),
                                ),
                              ),
                            ),
                            const Text(
                              'Memberships',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                                fontSize: 18.0,
                                fontFamily: fontMontserrat,
                              ),
                            ),
                            const Icon(
                              Icons.arrow_forward,
                              color: Colors.black38,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 40.0,
            ),
          ],
        ),
      ),
    );
  }


  String capitalizeFirstofEach(String data) {
    data.split(" ").map((str) => str.substring(0, 1).toUpperCase()).join(" ");
  }

  String _getAddress(Doctor doctor) {
    if (doctor.address == null) return '';
    final String street = doctor.address.street ?? '';
    final String city = doctor.address.city ?? '';
    return street + (city.isNotEmpty ? ', ' + city : '');
  }

  void handleConnect(BuildContext context) {
    if (Validator.isAmountValid(widget.doctor.fee)) {
      // Set the doc id and amount to provider
      LocatorService.consultationProvider().setDoctor = widget.doctor;
      LocatorService.consultationProvider().setAmount = widget.doctor.fee;

      if (LocatorService.consultationProvider().title != null) {
        NavigationController.navigator.pushNamed(Routes.review);
      } else {
        UiController.showModal(context, CategoryOptionsModal());
      }
    } else {
      Fluttertoast.showToast(msg: AppStrings.invalidAmount);
    }
  }
}
