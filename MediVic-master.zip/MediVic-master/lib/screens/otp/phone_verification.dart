import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/authController.dart';
import 'package:medivic/screens/doctorsAccountScreens/signupDoctor/signupDoctor.dart';
import 'package:medivic/screens/home/main_screen.dart';
import 'package:medivic/screens/home/main_screen_doctor.dart';
import 'package:medivic/screens/signup/signup.dart';
import 'package:medivic/shared/authScreenWidgets/authSreenWidgets.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../locator.dart';

class PhoneVerification extends StatefulWidget {
  final bool isPatient, isAuth;
  final String phone;

  const PhoneVerification(
      {Key key, @required this.isPatient, this.isAuth, this.phone})
      : super(key: key);

  @override
  _PhoneVerificationState createState() => _PhoneVerificationState();
}

class _PhoneVerificationState extends State<PhoneVerification> {
  final _phoneController = TextEditingController();
  final _codeController = TextEditingController();
  String initialCountry = 'ZA';
  PhoneNumber number = PhoneNumber(isoCode: 'ZA');
  StreamController<ErrorAnimationType> errorController;
  FirebaseAuth _auth;
  AuthResult result;
  FirebaseUser user;
  AuthCredential credential;
  bool _isCodeSent = false, _isLoading = false;
  bool hasError = false, _isValidate = false;
  String veriFicationId, phoneNumber;

  Future<void> loginOtp(String phone, BuildContext context) async {
    _auth.verifyPhoneNumber(
        phoneNumber: phone,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (AuthCredential credential) async {
          // Navigator.of(context).pop();
          if (widget.isAuth) {
            result = await _auth.signInWithCredential(credential);
            user = result.user;
            if (user != null) {
              // Fluttertoast.showToast(msg: 'Get code');
              if (widget.isPatient) {
                checkPatientUser(user.uid);
              } else {
                checkDoctorUser(user.uid);
              }
            } else {
              Fluttertoast.showToast(msg: 'Something error');
            }
          } else {
            if (widget.isPatient) {
              Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MainScreen(),
                  ),
                  (route) => false);
            } else
              Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MainScreenDoctor(),
                  ),
                  (route) => false);
          }

          //This callback would gets called when verification is done automatically
        },
        verificationFailed: (AuthException exception) {
          setState(() {
            _isLoading = false;
          });
          print('verificationFailed : ${exception.message}');
          Fluttertoast.showToast(msg: exception.message);
        },
        codeSent: (String verificationId, [int forceResendingToken]) {
          setState(() {
            _isCodeSent = true;
            _isLoading = false;
            veriFicationId = verificationId;
          });
          // otpDialog(verificationId);
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          setState(() {
            _isLoading = false;
          });
          print(verificationId);
          Fluttertoast.showToast(msg: 'Timeout');
          print('Timeout');
        });
  }

  Future<void> checkDoctorUser(docId) async {
    final snapShot =
        await Firestore.instance.collection('doctors').document(docId).get();
    setState(() {
      _isLoading = false;
    });
    if (snapShot.exists) {
      print('Exits');
      // Fluttertoast.showToast(msg: 'Exits');
      final bool isDataAvailable =
          await LocatorService.doctorProvider().fetchDoctorData(docId);

      if (isDataAvailable) {
        final int isActive =
            LocatorService.doctorProvider().doctor?.isActive ?? 0;
        if (isActive == 1) {
          AuthController.setDoctorId(docId);
          await AuthController.saveDoctorCredentials(docId, '');

          // Setup push notification for the user.
          LocatorService.pushNotificationService().manageNotificationsAtAuth(
            doctorId: docId,
          );
          AuthController.navigateToDoctorHome();
        } else {
          Fluttertoast.showToast(
              msg:
                  'Account not activated for this user. Please try again later');
          // errorText =
          // 'Account not activated for this email. Please try again later.';
        }
      } else {
        // errorText =
        // 'Could not get the data for this email. Please try again';
      }
    } else {
      Navigator.pushAndRemoveUntil(context,
          MaterialPageRoute(builder: (context) {
        return SignupDoctor(
          doctorId: docId,
          phoneNumber: phoneNumber,
        );
      }), (route) => false);
    }
  }

  Future<void> checkPatientUser(patId) async {
    // Fluttertoast.showToast(msg: 'checkPatientUser');
    final snapShot =
        await Firestore.instance.collection('users').document(patId).get();
    setState(() {
      _isLoading = false;
    });
    if (snapShot.exists) {
      // Fluttertoast.showToast(msg: 'Exists');
      // Get the user data
      final bool isDataAvailable =
          await LocatorService.userProvider().fetchUserData(patId);

      if (isDataAvailable) {
        AuthController.setUserId(patId);
        await AuthController.saveCredentials(patId, '');
        print('-------------------');
        print('isDataAvailable: $patId');
        SharedPreferences preferences = await SharedPreferences.getInstance();
        preferences.setString('email', '');
        // Setup push notification for the user.
        LocatorService.pushNotificationService().manageNotificationsAtAuth(
          userId: patId,
        );
        AuthController.navigateToHome();
      } else
        Fluttertoast.showToast(
            msg: 'Account not activated for this user. Please try again later');
    } else {
      print('Not Exists');
      // Fluttertoast.showToast(msg: 'Not Exists');
      print('Auth: $patId');
      Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => Signup(
          uid: patId,
          phone: phoneNumber,
        ),
      ));
    }
  }

  @override
  void initState() {
    super.initState();
    _auth = FirebaseAuth.instance;
    // _phoneController.text = '+27';
    errorController = StreamController<ErrorAnimationType>();
    if (!widget.isAuth) {
      setState(() {
        _isCodeSent = true;
      });
      loginOtp(widget.phone, context);
    }
  }

  @override
  void dispose() {
    errorController.close();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return Scaffold(
        appBar: AppBar(
          iconTheme: const IconThemeData(color: Colors.white),
          title: Text(
            widget.isPatient
                ? 'Patient Phone Verification'
                : 'Doctor Phone Verification',
            style: styleAppbarTitle,
          ),
          backgroundColor: appBarColor,
        ),
        body: _body());
  }

  Widget _body() {
    final ThemeData _theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(32),
      child: Center(
        child: Form(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const SizedBox(
                height: 16,
              ),
              if (_isCodeSent)
                Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: PinCodeTextField(
                      length: 6,
                      obsecureText: false,
                      animationType: AnimationType.fade,
                      validator: (v) {
                        if (v.length < 3) {
                          return "Please enter proper OTP";
                        } else {
                          return null;
                        }
                      },
                      pinTheme: PinTheme(
                        shape: PinCodeFieldShape.box,
                        borderRadius: BorderRadius.circular(10),
                        inactiveColor:
                            _theme.primaryColorLight.withOpacity(0.8),
                        disabledColor:
                            _theme.primaryColorLight.withOpacity(0.8),
                        inactiveFillColor:
                            _theme.primaryColorLight.withOpacity(0.8),
                        selectedFillColor:
                            _theme.primaryColorLight.withOpacity(0.8),
                        fieldHeight: 45,
                        fieldWidth: 45,
                        activeFillColor: hasError ? Colors.white : Colors.white,
                      ),
                      animationDuration: Duration(milliseconds: 300),
                      enableActiveFill: true,
                      errorAnimationController: errorController,
                      controller: _codeController,
                      onCompleted: (v) {
                        print("Completed");
                      },
                      onChanged: (value) {
                        print(value);
                        setState(() {
                          // currentText = value;
                        });
                      },
                      beforeTextPaste: (text) {
                        print("Allowing to paste $text");
                        return true;
                      },
                    ))
              else
                // CustomInput(
                //   placeholder: AppStrings.phoneNumber,
                //   iconAsset: 'lib/assets/icons/form/phone.png',
                //   controller: _phoneController,
                //   onChange: null,
                //   keyboardType: TextInputType.phone,
                // ),

                ClipRRect(
                  borderRadius: BorderRadius.circular(32),
                  child: InternationalPhoneNumberInput(
                    onInputChanged: (PhoneNumber number) {
                      phoneNumber = number.phoneNumber;
                      print(number.isoCode);
                    },
                    onInputValidated: (bool value) {
                      print(value);
                      setState(() {
                        _isValidate = value;
                      });
                    },
                    selectorConfig: SelectorConfig(
                        selectorType: PhoneInputSelectorType.BOTTOM_SHEET),
                    ignoreBlank: false,
                    inputDecoration: InputDecoration(
                      fillColor: _theme.inputDecorationTheme.fillColor,
                    ),
                    selectorTextStyle: TextStyle(color: Colors.black),
                    initialValue: number,
                    textFieldController: _phoneController,
                  ),
                ),
              const SizedBox(
                height: 16,
              ),
              // Visibility(
              //     visible: _isLoading,
              //     child: const CircularProgressIndicator(
              //       backgroundColor: appBarColor,
              //     )),
              // const SizedBox(
              //   height: 4,
              // ),
              Submit(
                color: appBarColor,
                onPress: () => buttonFun(),
                isLoading: _isLoading,
                lable: _isCodeSent ? 'Confirm' : AppStrings.login,
              ),
            ],
          ),
        ),
      ),
    );
  }

  otpDialog(verificationId) {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            title: const Text('Give the code?',
                style: TextStyle(fontFamily: fontMontserrat)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                TextField(
                  controller: _codeController,
                ),
              ],
            ),
            actions: <Widget>[
              FlatButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text('Cancel',
                      style: TextStyle(fontFamily: fontMontserrat))),
              FlatButton(
                child: const Text('Confirm',
                    style: TextStyle(fontFamily: fontMontserrat)),
                textColor: Colors.white,
                color: darkBlueColor,
                onPressed: () async {
                  _confirm();
                },
              )
            ],
          );
        });
  }

  _confirm() async {
    final code = _codeController.text.trim();
    print(code);
    credential = PhoneAuthProvider.getCredential(
        verificationId: veriFicationId, smsCode: code);

    if (widget.isAuth) {
      result = await _auth.signInWithCredential(credential);

      user = result.user;

      if (user != null) {
        if (widget.isPatient) {
          checkPatientUser(user.uid);
        } else {
          checkDoctorUser(user.uid);
        }

        Fluttertoast.showToast(msg: 'Successfully verified');
      } else {
        setState(() {
          _isLoading = false;
        });
        Fluttertoast.showToast(msg: 'Something Wrong');
        print('Error');
      }
    } else {
      if (widget.isPatient) {
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (context) => MainScreen(),
            ),
            (route) => false);
      } else
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (context) => MainScreenDoctor(),
            ),
            (route) => false);
    }
  }

  buttonFun() {
    print(phoneNumber);

    if (_isCodeSent) {
      if (_codeController.text.length != 6) {
        errorController
            .add(ErrorAnimationType.shake); // Triggering error shake animation
        setState(() {
          hasError = true;
        });
      } else {
        setState(() {
          hasError = false;
          _isLoading = true;
          //check();
          _confirm();
          /*scaffoldKey.currentState.showSnackBar(SnackBar(
                                content: Text("Aye!!"),
                                duration: Duration(seconds: 2),
                              ));*/
        });
      }
    } else {
      if (_isValidate) {
        setState(() {
          _isLoading = true;
        });

        loginOtp(phoneNumber, context);
      } else
        Fluttertoast.showToast(msg: 'Please input valid number');
    }
  }
}
