// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/authController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/SmsHeaderModel.dart';
import 'package:medivic/models/addressModel.dart';
import 'package:medivic/models/mAddress.dart';
import 'package:medivic/models/userModel.dart';
import 'package:medivic/screens/gooogleMap/googleMap.dart';
import 'package:medivic/screens/more/load_html_screen.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/services/authentication/firebaseAuthService.dart';
import 'package:medivic/shared/authScreenWidgets/authSreenWidgets.dart';
import 'package:medivic/shared/customInput.dart';
import 'package:url_launcher/url_launcher.dart';

class SignupForm extends StatefulWidget {
  final String uid;
  final String phoneNumber;
  final String email;
  final bool isAuth;

  const SignupForm(
      {Key key, this.uid, this.phoneNumber, this.email, this.isAuth})
      : super(key: key);

  static int codeOtp = 000000;
  static String phone = "";

  @override
  _SignupFormState createState() => _SignupFormState();
}

class _SignupFormState extends State<SignupForm> {
  String email;
  String uid;
  String password;
  String confirmPassword;
  String firstName;
  String lastName;
  String dateOfBirth;
  String id;
  String phoneNumber;
  String age;
  String gender;
  PatientAddress address = PatientAddress.empty();
  bool _isLoading = false, isCheck = false, isDate = false;
  String errorText = '';
  int _value = 0;
  SmsHeader smsHeader;
  MAddress mAddress;

  DateTime selectedDate = DateTime(2000, 1);
  final dateFormat = DateFormat('dd-MM-yyyy');

  IconData icon;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  Future<void> _submit(BuildContext context) async {
    if (AuthController.validateForm(_formKey)) {
      // Start the indicator

      if (isCheck) {
        setState(() => _isLoading = !_isLoading);

        // Authenticate
        // try {
        switch (_value) {
          case 1:
            gender = 'Male';
            break;
          case 2:
            gender = 'Female';
            break;
          case 3:
            gender = 'Prefer Not To Say';
            break;
        }
        if (uid == null || uid.isEmpty) {
          final authUser = await FirebaseAuthService()
              .createUserWithEmailAndPassword(email, password);
          if (authUser != null && authUser.uid.isNotEmpty) {
            uid = authUser.uid;
          } else {
            setState(() => _isLoading = false);
            return;
          }
        }

        final User user = User(
          uid: uid,
          email: email,
          phoneNumber: phoneNumber,
          age: age,
          name: firstName + ' ' + lastName,
          lastName: lastName,
          id: id,
          gender: gender,
          dob: selectedDate,
          imageUrl: Config.placeholedImageUrl,
          address: address,
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        );
        await FirestoreService.createUser(user);
        final bool isDataAvailable =
            await LocatorService.userProvider().fetchUserData(uid);
        if (isDataAvailable) {
          AuthController.setUserId(uid);
          await AuthController.saveCredentials(uid, email);

          // Setup push notification for the user.
          LocatorService.pushNotificationService().manageNotificationsAtAuth(
            userId: uid,
          );
          AuthController.navigateToLogin();
        } else {
          Fluttertoast.showToast(
              msg: 'Could not get the data for this user. Please try again');
        }
      } else {
        Fluttertoast.showToast(msg: 'Please Accept Terms & Conditions.');
      }
      // Stop the indicator
      setState(() => _isLoading = !_isLoading);
    }
  }

  // TextEditingController controllerAge = TextEditingController();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(1940, 1),
      lastDate: DateTime.now().subtract(const Duration(days: 365 * 16)),
      builder: (BuildContext context, Widget child) {
        return Theme(
          data: ThemeData.light().copyWith(
              //OK/Cancel button text color
              primaryColor: appBarColor, //Head background
              accentColor: appBarColor //selection color
              //dialogBackgroundColor: Colors.white,//Background color
              ),
          child: child,
        );
      },
    );
    if (picked != null && picked != selectedDate)
      setState(() {
        isDate = true;
        selectedDate = picked;
        dateOfBirth = dateFormat.format(selectedDate);
        Duration duration = DateTime.now().difference(selectedDate);
        age = (duration.inDays / 365).floor().toString();
        // controllerAge.text = age;
      });
  }

  @override
  void initState() {
    super.initState();
    phoneNumber = widget.phoneNumber;
    email = widget.email;
    uid = widget.uid;
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Form(
        key: _formKey,
        child: Column(
          children: <Widget>[
            CustomInput(
              placeholder: AppStrings.firstNameLabel,
              onChange: (val) => firstName = val,
              validator: AuthController.validateFirstName,
              iconAsset: 'lib/assets/icons/form/user.png',
            ),
            CustomInput(
              placeholder: AppStrings.lastNameLabel,
              onChange: (val) => lastName = val,
              validator: AuthController.validateLastName,
              iconAsset: 'lib/assets/icons/form/user.png',
            ),
            InkWell(
              onTap: () {
                _selectDate(context);
              },
              child: Container(
                child: Container(
                    height: 65,
                    margin: const EdgeInsets.only(top: 10.0),
                    padding: const EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      color: _theme.inputDecorationTheme.fillColor,
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    child: Container(
                      child: Row(
                        children: <Widget>[
                          Container(
                            margin: const EdgeInsets.only(right: 10.0),
                            height: 38,
                            width: 38,
                            child: Image.asset('lib/assets/icons/form/dob.png'),
                          ),
                          if (isDate)
                            Text(dateFormat.format(selectedDate),
                                style: const TextStyle(
                                    fontSize: 16,
                                    fontFamily: fontMontserrat,
                                    color: darkBlueColor))
                          else
                            const Text(
                              'Date of Birth',
                              style: TextStyle(
                                color: darkBlueColor,
                                fontSize: 16,
                                fontFamily: fontMontserrat,
                              ),
                            ),
                        ],
                      ),
                    )),
              ),
            ),
            CustomInput(
              placeholder: AppStrings.nationalIdNumberLabel,
              onChange: (val) => id = val,
              validator: AuthController.validateNationalId,
              iconAsset: 'lib/assets/icons/form/nid.png',
            ),
            CustomInput(
              data: email,
              placeholder: AppStrings.emailLabel,
              isEnable: email == null ? true : false,
              onChange: (val) => email = val,
              validator: AuthController.validateEmail,
              iconAsset: 'lib/assets/icons/form/email.png',
            ),
            CustomInput(
              data: phoneNumber,
              isEnable: widget.phoneNumber == null || widget.phoneNumber.isEmpty
                  ? true
                  : false,
              placeholder: AppStrings.phoneNumberLabel,
              onChange: (val) => {
                phoneNumber = val,
              },
              keyboardType: TextInputType.phone,
              validator: AuthController.validatePhoneId,
              iconAsset: 'lib/assets/icons/form/phone.png',
            ),
            Container(
                margin: const EdgeInsets.only(top: 10.0),
                padding: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  color: _theme.inputDecorationTheme.fillColor,
                  borderRadius: BorderRadius.circular(30.0),
                ),
                child: Container(
                  child: Row(
                    children: <Widget>[
                      Container(
                        height: 38,
                        width: 38,
                        margin: const EdgeInsets.only(right: 10.0),
                        child: Image.asset('lib/assets/icons/form/gender.png'),
                      ),
                      Expanded(
                        child: DropdownButton(
                            value: _value,
                            isExpanded: true,
                            underline: const SizedBox(),
                            items: const [
                              DropdownMenuItem(
                                child: Text(
                                  'Gender',
                                  style: TextStyle(
                                      fontSize: 16, fontFamily: fontMontserrat),
                                ),
                                value: 0,
                              ),
                              DropdownMenuItem(
                                child: Text(
                                  'Male',
                                  style: TextStyle(
                                      fontSize: 16, fontFamily: fontMontserrat),
                                ),
                                value: 1,
                              ),
                              DropdownMenuItem(
                                child: Text(
                                  'Female',
                                  style: TextStyle(
                                      fontSize: 16, fontFamily: fontMontserrat),
                                ),
                                value: 2,
                              ),
                              DropdownMenuItem(
                                  child: Text(
                                    'Prefer Not To Say',
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontFamily: fontMontserrat),
                                  ),
                                  value: 3)
                            ],
                            onChanged: (value) {
                              setState(() {
                                _value = value;
                              });
                            }),
                      ),
                    ],
                  ),
                )),
            // CustomInput(
            //   controller: controllerAge,
            //   placeholder: AppStrings.ageLabel,
            //   onChange: (val) => age = val,
            //   keyboardType: TextInputType.number,
            //   validator: AuthController.validateAge,
            //   iconAsset: 'lib/assets/icons/form/age.png',
            // ),
            GestureDetector(
              onTap: () => _pickAddressFromMap(context),
              child: Container(
                  margin: const EdgeInsets.only(top: 10.0),
                  padding: const EdgeInsets.all(8.0),
                  decoration: BoxDecoration(
                    color: _theme.inputDecorationTheme.fillColor,
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                  child: Container(
                    child: Row(
                      children: <Widget>[
                        Container(
                          height: 42,
                          width: 38,
                          margin: const EdgeInsets.only(right: 10.0),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.black38),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.location_on,
                            size: 28.0,
                            color: Colors.black38,
                          ),
                        ),
                        Expanded(
                          child: Text(
                              address.address.isNotEmpty
                                  ? address.address
                                  : 'Address',
                              style: const TextStyle(
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: 'Montserrat',
                                  color: darkBlueColor)),
                        ),
                      ],
                    ),
                  )),
            ),
            if (widget.isAuth != null && !widget.isAuth)
              CustomInput(
                placeholder: AppStrings.passwordLabel,
                onChange: (val) => password = val,
                validator: (val) => AuthController.validatePassword(password),
                iconAsset: 'lib/assets/icons/form/password.png',
              ),
            if (widget.isAuth != null && !widget.isAuth)
              CustomInput(
                placeholder: AppStrings.confirmPasswordLabel,
                onChange: (val) => confirmPassword = val,
                iconAsset: 'lib/assets/icons/form/password.png',
                validator: (val) => AuthController.validateConfirmPassword(
                  confirmPassword,
                  password,
                ),
              ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Checkbox(
                      activeColor: appBarColor,
                      value: isCheck,
                      onChanged: (bool value) {
                        setState(() {
                          isCheck = value;
                        });
                      },
                    ),
                    const Text(
                      ' ${AppStrings.iAgreeTo} ',
                      style: TextStyle(
                          color: Colors.black54,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          fontFamily: fontMontserrat),
                    ),
                    GestureDetector(
                      onTap: () => _termsOfService(),
                      child: const Text(
                        AppStrings.termsAndCondition,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            decoration: TextDecoration.underline,
                            fontFamily: fontMontserrat),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Submit(
              onPress: () => {
                if (isCheck) {_submit(context)}
              },
              isLoading: _isLoading,
              lable: AppStrings.signup,
              color: isCheck
                  ? _theme.primaryColorLight.withOpacity(1)
                  : _theme.primaryColorLight.withOpacity(0.2),
            ),
            ShowError(
              text: errorText,
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickAddressFromMap(BuildContext context) async {
    // final LocationResult locationResult = await CommonUtils.openLocationPicker(context);
    // setState(() {
    //   address = PatientAddress.fromPick(locationResult);
    // });

    mAddress = await Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => const GoogleMapScreen(
        isLock: false,
      ),
    ));

    setState(() => address = PatientAddress.fromPickNew(
        mAddress.address, mAddress.lat, mAddress.lng));
  }

  Future<void> _termsOfService() async {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) => LoadHTML(
                  title: 'Standard Terms & Conditions',
                  field: 'terms',
                )));
  }
}

class FooterLinks extends StatelessWidget {
  const FooterLinks({Key key}) : super(key: key);

  // Launch the terms of service URL

  Future<void> _termsOfService() async {
    const url = Config.TERMS_OF_SERVICE_URL;
    if (await canLaunch(url)) {
      await launch(url);
    }
  }

  // Launch the privacy policy URL
  Future<void> _privacyPolicy() async {
    const url = Config.PRIVACY_POLICY_URL;
    if (await canLaunch(url)) {
      await launch(url);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return DefaultTextStyle(
      style: _theme.textTheme.caption.copyWith(
        color: const Color.fromRGBO(200, 200, 200, 1),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Wrap(
          runSpacing: 2,
          alignment: WrapAlignment.center,
          children: <Widget>[
            CheckboxListTile(
              title: const Text('title text'),
              value: false,
              onChanged: (newValue) {},
              controlAffinity:
                  ListTileControlAffinity.leading, //  <-- leading Checkbox
            ),
            const Text(AppStrings.tosPreText),
            GestureDetector(
              onTap: () => _termsOfService(),
              child: const Text(
                AppStrings.termsOfService,
                style: TextStyle(
                  color: Color(0xFF64B5F6),
                ),
              ),
            ),
            const Text(
              ' ${AppStrings.and} ',
            ),
            GestureDetector(
              onTap: () => _privacyPolicy(),
              child: const Text(
                AppStrings.privacyPolicy,
                style: TextStyle(
                  color: Color(0xFF64B5F6),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
