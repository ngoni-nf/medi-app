// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/authController.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/screens/signup/form/signupForm.dart';
import 'package:medivic/shared/authScreenWidgets/authSreenWidgets.dart';
import 'package:medivic/shared/dividerWithText.dart';
import 'package:medivic/shared/socialButtons/socialButtonsContainer.dart';

class Signup extends StatelessWidget {
  final String uid;
  final String email;
  final String phone;

  const Signup({Key key, this.uid, this.email, this.phone}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SocialLoginLoadingOverlay(
        child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 30),
          physics: const BouncingScrollPhysics(),
          children: <Widget>[
            SizedBox(
              height: MediaQuery.of(context).size.height / 12,
            ),
            const Center(
              child: Text(
                AppStrings.signup,
                style: TextStyle(
                  color: darkBlueColor,
                  fontSize: 30.0,
                  fontFamily: fontMontserrat,
                ),
              ),
            ),
            Center(
                child: SvgPicture.asset(
              'lib/assets/svg/cardiogram.svg',
              width: 200,
              height: 200,
            )),
            const SizedBox(
              height: 30,
            ),
            SignupForm(
              uid: uid,
              email: email,
              phoneNumber: phone,
              isAuth: email != null || phone != null,
            ),
            const DividerWithText(
              text: AppStrings.or,
              textStyle: TextStyle(fontFamily: fontMontserrat),
            ),
            SocialButtonsContainer(
              isGoogleVisiable: false,
              isFbVisiable: false,
              isOtpVisiable: false,
              googleLable: AppStrings.signupWithGoogle,
              googleOnPress: () => AuthController.signInWithGoogle(),
              facebookLable: AppStrings.signupWithFacebook,
              facebookOnPress: () => AuthController.signInWithFacebook(),
            ),
            const SizedBox(height: 30),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                const Text(
                  AppStrings.signUpQues,
                  style: TextStyle(
                      color: Colors.black26, fontFamily: fontMontserrat),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: InkWell(
                    onTap: () => NavigationController.navigator
                        .pushReplacementNamed(Routes.login),
                    highlightColor: Colors.transparent,
                    child: const Text(
                      AppStrings.login,
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 16,
                        fontFamily: fontMontserrat,
                        /*color: Color(0xFFE57373),*/
                        color: appBarColor,
                      ),
                    ),
                  ),
                )
              ],
            ),
            const SizedBox(
              height: 100,
            ),
          ],
        ),
      ),
    );
  }
}
