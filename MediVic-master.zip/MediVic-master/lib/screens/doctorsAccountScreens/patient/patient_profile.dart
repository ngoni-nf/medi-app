import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';

class PatientProfile extends StatefulWidget {
  @override
  _PatientProfileState createState() => _PatientProfileState();
}

class _PatientProfileState extends State<PatientProfile> {
  Widget row(String title, String value, bool isWhite) {
    return Container(
      padding: const EdgeInsets.all(20),
      color: isWhite ? Colors.white : null,
      child: Row(
        children: [
          const SizedBox(
            width: 32,
          ),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(color: Colors.grey, fontFamily: fontMontserrat),
            ),
          ),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          AppStrings.patient,
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 32,
            ),
            const Center(
                child: CircleAvatar(
              radius: 85,
              backgroundColor: Colors.white,
              child: CircleAvatar(
                radius: 80,
                backgroundImage: AssetImage("assets/girl2.png"),
              ),
            )),
            const SizedBox(
              height: 32,
            ),
            row("Full Name", "Kelvin Zine", true),
            row("D.O.B", "30 July 1991", false),
            row("Gender", "Female", true),
            row("Age", "30", false),
            row("Email", "Kelvine33@gmail.com", true),
            row("Telephone", "98746329320", false),
            row("Date", "15 July 2020", true),
            row("Time", "12:00 PM", false),
            Container(
              padding: const EdgeInsets.all(20),
              color: Colors.white,
              child: Row(
                children: [
                  const SizedBox(
                    width: 32,
                  ),
                  const Expanded(
                    child: Text(
                      "Appointment Notes",
                      style: TextStyle(color: Colors.grey, fontFamily: fontMontserrat),
                    ),
                  ),
                  Expanded(
                    child: Image.asset(
                      "assets/user.png",
                      height: 20,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                const Text(
                  "View Attachments",
                  style: TextStyle(color: darkBlueColor, fontFamily: fontMontserrat, fontWeight: FontWeight.bold, fontSize: 15),
                ),
                const Text(
                  "View History",
                  style: TextStyle(color: darkBlueColor, fontFamily: fontMontserrat, fontWeight: FontWeight.bold, fontSize: 15),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.28,
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    color: appBarColor,
                    child: const Text(
                      AppStrings.accept,
                      style: TextStyle(fontFamily: fontMontserrat, fontSize: 14, color: Colors.white),
                    ),
                    onPressed: () {},
                  ),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.28,
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    color: Colors.red[900],
                    child: const Text(
                      AppStrings.reject,
                      style: TextStyle(fontFamily: fontMontserrat, fontSize: 14, color: Colors.white),
                    ),
                    onPressed: () {},
                  ),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.28,
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    color: darkBlueColor,
                    child: const Text(
                      AppStrings.reschedule,
                      style: TextStyle(fontFamily: fontMontserrat, fontSize: 14, color: Colors.white),
                    ),
                    onPressed: () {},
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
          ],
        ),
      ),
    );
  }
}
