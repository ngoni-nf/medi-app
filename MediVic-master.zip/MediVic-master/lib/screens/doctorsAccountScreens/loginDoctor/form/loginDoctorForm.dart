// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/authController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/SmsHeaderModel.dart';
import 'package:medivic/screens/doctorsAccountScreens/signupDoctor/signupDoctor.dart';
import 'package:medivic/screens/home/main_screen_doctor.dart';
import 'package:medivic/screens/otp/phone_verification.dart';
import 'package:medivic/screens/signup/signup.dart';
import 'package:medivic/services/storage/localStorage.dart';
import 'package:medivic/services/storage/storageConstants.dart';
import 'package:medivic/shared/authScreenWidgets/authSreenWidgets.dart';
import 'package:medivic/shared/customInput.dart';

class LoginDoctorForm extends StatefulWidget {
  const LoginDoctorForm({Key key}) : super(key: key);

  @override
  _LoginDoctorFormState createState() => _LoginDoctorFormState();
}

class _LoginDoctorFormState extends State<LoginDoctorForm> {
  String email;
  String password;
  String confirmPassword;
  bool _isLoading = false;
  bool _isRemembered = false;
  String errorText = '';
  String phoneNumber;
  SmsHeader smsHeader;
  TextEditingController controllerEmail = TextEditingController();
  TextEditingController controllerPass = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  Future<void> buttonSubmit(BuildContext context) async {
    if (AuthController.validateForm(_formKey)) {
      // Start the indicator
      setState(() => _isLoading = !_isLoading);

      // Authenticate
      try {
        final result = await AuthController.login(email, password);

        if (result == null) {
          setState(() => _isLoading = !_isLoading);
          return;
        }
        // If userId is not empty then check for user data
        if (result.uid.isNotEmpty) {
          // Get the doctor's data
          final bool isDataAvailable =
              await LocatorService.doctorProvider().fetchDoctorData(result.uid);

          if (isDataAvailable) {
            final int isActive =
                LocatorService.doctorProvider().doctor?.isActive ?? 0;
            final isBlock = LocatorService.doctorProvider().doctor.isBlock;
            if (isActive == 1 && !isBlock) {
              AuthController.setDoctorId(result.uid);
              await AuthController.saveDoctorCredentials(result.uid, email);

              // Setup push notification for the user.
              LocatorService.pushNotificationService()
                  .manageNotificationsAtAuth(
                doctorId: result.uid,
              );
              phoneNumber =
                  LocatorService.doctorProvider().doctor.phoneNumber ?? '';
              final String isOtp =
                  LocatorService.doctorProvider().doctor.isOTP ?? '';

              // AuthController.navigateToDoctorHome();
              /// Navigate to tabbar
              if (isOtp == '1') {
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const MainScreenDoctor(),
                    ),
                    (route) => false);
              } else {
                if (phoneNumber.isNotEmpty) {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => PhoneVerification(
                      isPatient: false,
                      isAuth: false,
                      phone: phoneNumber,
                    ),
                  ));
                } else
                  AuthController.navigateToDoctorHome();
              }

              LocalStorage.setString(LocalStorageConstants.REMEMBER_DOCTOR,
                  _isRemembered ? '1' : '0');
              LocalStorage.setString(LocalStorageConstants.EMAIL_DOCTOR, email);
              LocalStorage.setString(
                  LocalStorageConstants.PASS_DOCTOR, password);
            } else {
              if (isBlock) {
                Fluttertoast.showToast(msg: AppStrings.blockedMsg);
                errorText = AppStrings.blockedMsg;
              } else
                errorText =
                    'Account not activated for this email. Please try again later.';
            }
          } else {
            errorText =
                'Could not get the data for this email. Please try again';
          }
        } else {
          errorText = 'Could not find the account. Please try again';
        }
      } on PlatformException catch (e) {
        errorText = e.message.toString();
        log(e.message, name: 'Error log: Login Doctor page');
      } catch (e) {
        errorText = 'Something went wrong';
      }

      // Stop the indicator
      setState(() => _isLoading = !_isLoading);
    }
  }

  void _prepareForm() async {
    final remember =
        await LocalStorage.getString(LocalStorageConstants.REMEMBER_DOCTOR);
    final email =
        await LocalStorage.getString(LocalStorageConstants.EMAIL_DOCTOR);
    final pass =
        await LocalStorage.getString(LocalStorageConstants.PASS_DOCTOR);

    setState(() {
      _isRemembered = remember == '1';
      if (_isRemembered) {
        this.email = email;
        this.password = pass;
        controllerEmail.text = email;
        controllerPass.text = pass;
      }
    });
  }

  @override
  void initState() {
    super.initState();
    _prepareForm();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Form(
        key: _formKey,
        child: Column(
          children: <Widget>[
            CustomInput(
              controller: controllerEmail,
              placeholder: AppStrings.emailLabel,
              onChange: (val) => email = val,
              validator: AuthController.validateEmail,
              iconAsset: 'lib/assets/icons/form/email.png',
            ),
            CustomInput(
              controller: controllerPass,
              placeholder: AppStrings.passwordLabel,
              onChange: (val) => password = val,
              validator: (val) => AuthController.validatePassword(password),
              iconAsset: 'lib/assets/icons/form/password.png',
            ),
            Row(
              children: [
                Checkbox(
                  value: _isRemembered,
                  onChanged: (value) {
                    setState(() {
                      _isRemembered = value;
                    });
                  },
                ),
                const Text(
                  'Remember me',
                  style: TextStyle(fontFamily: fontMontserrat),
                ),
              ],
            ),
            Submit(
              color: appBarColor,
              onPress: () => buttonSubmit(context),
              isLoading: _isLoading,
              lable: AppStrings.login,
            ),
            ShowError(
              text: errorText,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const ForgotPassword(),
                const SizedBox(
                  width: 20,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => SignupDoctor(),
                        ));
                  },
                  child: const Text(
                    'Sign Up',
                    style: TextStyle(
                        fontFamily: fontMontserrat,
                        color: appBarColor,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
