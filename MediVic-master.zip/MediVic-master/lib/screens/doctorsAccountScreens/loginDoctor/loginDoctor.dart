// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/authController.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/screens/doctorsAccountScreens/loginDoctor/form/loginDoctorForm.dart';
import 'package:medivic/screens/doctorsAccountScreens/signupDoctor/signupDoctor.dart';
import 'package:medivic/screens/home/main_screen_doctor.dart';
import 'package:medivic/screens/otp/phone_verification.dart';
import 'package:medivic/shared/dividerWithText.dart';
import 'package:medivic/shared/socialButtons/socialButtonsContainer.dart';

class LoginDoctor extends StatelessWidget {
  const LoginDoctor({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 30),
        physics: const BouncingScrollPhysics(),
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.height / 12,
          ),
          const Center(
            child: Text(
              AppStrings.login,
              style: TextStyle(
                color: darkBlueColor,
                fontSize: 30.0,
                fontFamily: fontMontserrat,
              ),
            ),
          ),
          Center(
              child: SvgPicture.asset(
            'lib/assets/svg/cardiogram.svg'
            '',
            width: 200,
            height: 200,
          )),
          const SizedBox(
            height: 30,
          ),
          const LoginDoctorForm(),
          const DividerWithText(
            text: AppStrings.or,
            textStyle: TextStyle(
              fontFamily: fontMontserrat,
            ),
          ),
          SocialButtonsContainer(
            isGoogleVisiable: true,
            isFbVisiable: false,
            isOtpVisiable: true,
            googleLable: AppStrings.loginWithGoogle,
            googleOnPress: () => handleGoogleSignIn(context),
            facebookLable: AppStrings.loginWithFacebook,
            facebookOnPress: () => AuthController.signInWithFacebook(),
            otpLable: AppStrings.loginWithOtp,
            otpOnPress: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => const PhoneVerification(
                isPatient: false,
                isAuth: true,
              ),
            )),
          ),
        ],
      ),
    );
  }

  void handleGoogleSignIn(BuildContext context) async {
    final userInfo = await AuthController.signInWithGoogle();

    // Change the loading status of the overlay.
    LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(true);

    if (userInfo.uid.isNotEmpty) {
      final bool isDataAvailable =
          await LocatorService.doctorProvider().fetchDoctorData(userInfo.uid);

      if (isDataAvailable) {
        // Change the loading status of the overlay.
        LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(false);
        if (LocatorService.doctorProvider().doctor.isBlock) {
          Fluttertoast.showToast(msg: AppStrings.blockedMsg);
          return;
        }
        if (LocatorService.doctorProvider().doctor.isActive == 1) {
          LocatorService.doctorProvider().setDoctorId(userInfo.uid);
          LocatorService.pushNotificationService()
              .manageNotificationsAtAuth(userId: userInfo.uid);

          await AuthController.saveCredentials(userInfo.uid, userInfo.email);
          Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                builder: (context) => const MainScreenDoctor(),
              ),
              (route) => false);
        } else {
          Fluttertoast.showToast(msg: 'Your account is not active yet!!');
        }
      } else {
        LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(false);
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => SignupDoctor(
                doctorId: userInfo.uid,
                email: userInfo.email,
              ),
            ));
      }
    }
  }
}
