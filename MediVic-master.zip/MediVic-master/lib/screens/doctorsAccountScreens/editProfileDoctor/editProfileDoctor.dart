// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:io';

import 'package:advance_pdf_viewer/advance_pdf_viewer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/addressModel.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/models/mAddress.dart';
import 'package:medivic/models/specialityModel.dart';
import 'package:medivic/screens/gooogleMap/googleMap.dart';
import 'package:medivic/services/api/firebaseStorageService.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/services/imageService/imageService.dart';
import 'package:medivic/shared/authScreenWidgets/authSreenWidgets.dart';
import 'package:medivic/shared/customButtonStyle.dart';
import 'package:medivic/shared/widgets/customTextField.dart';
import 'package:medivic/themes/themeGuide.dart';
import 'package:medivic/utils/utils.dart';
import 'package:medivic/utils/validators.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:url_launcher/url_launcher.dart';

class EditProfileDoctor extends StatefulWidget {
  const EditProfileDoctor({Key key}) : super(key: key);

  @override
  _EditProfileDoctorState createState() => _EditProfileDoctorState();
}

class _EditProfileDoctorState extends State<EditProfileDoctor> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          AppStrings.editProfile,
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
      ),
      body: Padding(
        padding: ThemeGuide.padding20,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: EditProfileDoctorForm(),
        ),
      ),
    );
  }
}

class EditProfileDoctorForm extends StatefulWidget {
  @override
  _EditProfileDoctorFormState createState() => _EditProfileDoctorFormState();
}

class _EditProfileDoctorFormState extends State<EditProfileDoctorForm> {
  Doctor doctor = LocatorService.doctorProvider().doctor;

  // String imageUrl = LocatorService
  //     .doctorProvider()
  //     .doctor
  //     .imageUrl ?? 'https://via.placeholder.com/150';
  FocusNode myFocusnode;

  double listHeight = 80.00;

  String specialities =
      LocatorService.doctorProvider().doctor.specialities != null
          ? LocatorService.doctorProvider()
              .doctor
              .specialities
              .reduce((prev, next) => prev + ',' + next)
          : '';

  int num;

  final gendreDropdownList = [
    const DropdownMenuItem(
        child: Text(
          'Male',
          style: TextStyle(fontFamily: fontMontserrat),
        ),
        value: 'Male'),
    const DropdownMenuItem(
        child: Text(
          'Female',
          style: TextStyle(fontFamily: fontMontserrat),
        ),
        value: 'Female'),
    const DropdownMenuItem(
        child: Text(
          'Prefer Not To Say',
          style: TextStyle(fontFamily: fontMontserrat),
        ),
        value: 'Prefer Not To Say'),
  ];
  List<File> files;
  List<Map<String, dynamic>> bankDocs = [];
  String address = "";
  final dateMaskFormatter = MaskTextInputFormatter(
    mask: '##-##-####',
    filter: {
      '#': RegExp(r'[0-9]'),
    },
  );
  final GlobalKey _formKey = GlobalKey<FormState>();
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  bool isLoading = false;
  DateTime selectedDate = DateTime.now();

  void setGenderValue(String val) {
    setState(() {
      doctor.gender = val;
    });
  }

  @override
  void initState() {
    super.initState();
    num = doctor.practices.length > 0 ? doctor.practices.length : 1;
    listHeight = doctor.practices.length > 0
        ? listHeight * doctor.practices.length
        : 100;
    if (doctor.bankDocuments != null) bankDocs = doctor.bankDocuments;
    myFocusnode = FocusNode();

    myFocusnode.addListener(textFieldFocusDidChange);
  }

  void textFieldFocusDidChange() {
    if (myFocusnode.hasFocus) {
      _showMultiSelect(context);
      //  Fluttertoast.showToast(msg: "Clickable");
      myFocusnode.canRequestFocus = false;
      // myFocusnode.notifyListeners();
    }
  }

  void _showDatePicker() async {
    DateTime d = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(1940, 1),
      lastDate: DateTime.now(),
      builder: (BuildContext context, Widget child) {
        return Theme(
          data: ThemeData.light().copyWith(
              //OK/Cancel button text color
              primaryColor: appBarColor, //Head background
              accentColor: appBarColor //selection color
              //dialogBackgroundColor: Colors.white,//Background color
              ),
          child: child,
        );
      },
    );
    // if (d != null)
    //   setState(() {
    //     selectedDate = d;
    //     dob = DateFormat('dd-MM-yyyy').format(selectedDate);
    //   });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Form(
        key: _formKey,
        child: Column(
          children: <Widget>[
            Container(
                alignment: Alignment.topLeft,
                margin: const EdgeInsetsDirectional.only(start: 6),
                child: const Text(
                  'Profile Completeness:',
                  style: TextStyle(
                      fontFamily: fontMontserrat,
                      color: darkBlueColor,
                      fontWeight: FontWeight.w600,
                      fontSize: 12),
                )),
            Container(
                alignment: Alignment.topLeft,
                margin: const EdgeInsetsDirectional.only(start: 6, top: 8),
                child: Text(
                  doctor.practices.length > 0
                      ? "100% Complete"
                      : "40% Complete",
                  style: const TextStyle(
                      fontFamily: fontMontserrat,
                      color: darkBlueColor,
                      fontWeight: FontWeight.w600,
                      fontSize: 18),
                )),
            Padding(
              padding: const EdgeInsets.only(bottom: 15.0, top: 5.0),
              child: LinearPercentIndicator(
                width: MediaQuery.of(context).size.width - 70,
                lineHeight: 6.0,
                percent: doctor.practices.length > 0 ? 1 : 0.4,
                animationDuration: 2000,
                progressColor: appBarColor,
              ),
            ),
            PhotoUpdate(),
            CustomTextField(
              data: doctor.name,
              hint: AppStrings.name,
              lableText: AppStrings.name,
              validator: validateName,
              onChange: (value) => doctor.name = value,
            ),
            CustomTextField(
              data: doctor.lastName,
              hint: AppStrings.lastNameLabel,
              lableText: AppStrings.lastNameLabel,
              validator: validateName,
              onChange: (value) => doctor.lastName = value,
            ),
            InkWell(
              onTap: () {
                _showDatePicker();
              },
              child: Container(
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.only(top: 10),
                width: double.maxFinite,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(const Radius.circular(10)),
                  color: Colors.grey[200],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Date of Birth',
                      style: TextStyle(
                          fontFamily: fontMontserrat,
                          color: Colors.grey,
                          fontSize: 12),
                    ),
                    const SizedBox(
                      height: 2,
                    ),
                    Text(
                      doctor.dob == null
                          ? 'Pick'
                          : DateFormat('dd/MM/yyyy').format(doctor.dob),
                      style: const TextStyle(
                          fontFamily: fontMontserrat, fontSize: 16),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            DropdownButtonFormField(
              value: doctor.gender.isNotEmpty ? doctor.gender : 'Male',
              items: gendreDropdownList,
              onChanged: setGenderValue,
            ),
            CustomTextField(
              data: doctor.age,
              hint: AppStrings.age,
              lableText: AppStrings.age,
              keyboardType: TextInputType.number,
              // validator: validateExp,
              onChange: (val) => doctor.age = val,
              inputFormatters: [WhitelistingTextInputFormatter.digitsOnly],
            ),
            CustomTextField(
              data: doctor.address.street,
              hint: AppStrings.streetLabel,
              lableText: AppStrings.streetLabel,
              keyboardType: TextInputType.text,
              // validator: validateName,
              onChange: (val) => doctor.address.street = val,
            ),
            CustomTextField(
              data: doctor.address.city,
              hint: AppStrings.cityLabel,
              lableText: AppStrings.cityLabel,
              keyboardType: TextInputType.text,
              // validator: validateName,
              onChange: (val) => doctor.address.city = val,
            ),
            CustomTextField(
              data: doctor.address.state,
              hint: AppStrings.stateLabel,
              lableText: AppStrings.stateLabel,
              keyboardType: TextInputType.text,
              // validator: validateName,
              onChange: (val) => doctor.address.state = val,
            ),
            CustomTextField(
              data: doctor.address.country,
              hint: AppStrings.countryLabel,
              lableText: AppStrings.countryLabel,
              keyboardType: TextInputType.text,
              // validator: validateName,
              onChange: (val) => doctor.address.country = val,
            ),
            CustomTextField(
              data: doctor.address.pin,
              hint: AppStrings.pinLabel,
              lableText: AppStrings.pinLabel,
              keyboardType: TextInputType.text,
              // validator: validateName,
              onChange: (val) => doctor.address.pin = val,
            ),
            _buildLocationPicker(),
            CustomTextField(
              data: doctor.id,
              hint: AppStrings.nationalIdNumberLabel,
              lableText: AppStrings.nationalIdNumberLabel,
              keyboardType: TextInputType.number,
              onChange: (val) => doctor.id = val,
              validator: validateName,
            ),
            CustomTextField(
              data: doctor.hpcaNumber,
              hint: AppStrings.hpcsaLabel,
              lableText: AppStrings.hpcsaLabel,
              keyboardType: TextInputType.text,
              onChange: (val) => doctor.hpcaNumber = val,
              validator: validateName,
            ),
            CustomTextField(
              data: doctor.ipaNumber,
              hint: AppStrings.IPALabel,
              lableText: AppStrings.IPALabel,
              keyboardType: TextInputType.text,
              // validator: validateName,
              onChange: (val) => doctor.ipaNumber = val,
            ),
            CustomTextField(
              data: doctor.groupPracticeNumber,
              hint: AppStrings.groupPracticeLabel,
              lableText: AppStrings.groupPracticeLabel,
              keyboardType: TextInputType.text,
              // validator: validateName,
              onChange: (val) => doctor.groupPracticeNumber = val,
            ),
            Container(
              width: double.infinity,
              height: 40,
              margin: const EdgeInsets.only(top: 12),
              child: InkWell(
                onTap: () {
                  setState(() {
                    num++;
                    listHeight = listHeight + 80.00;
                  });
                },
                child: Container(
                  child: const CustomButtonStyle(
                    color: appBarColor,
                    child: Center(
                      child: Text(
                        AppStrings.AddPracticestabel,
                        style: TextStyle(
                            fontFamily: fontMontserrat,
                            color: Colors.white,
                            fontSize: 14),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              height: listHeight,
              child: ListView.builder(
                  itemCount: num,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return CustomTextField(
                      lableText: AppStrings.numberOfprcaticeandaddressabel,
                      data: doctor.practices.length > index
                          ? doctor.practices[index]
                          : "",
                      onChange: (val) => {
                        if (doctor.practices.length > index)
                          {
                            doctor.practices.removeAt(index),
                            doctor.practices.insert(index, val),
                            print(doctor.practices.length),
                            print(doctor.practices)
                          }
                        else
                          {
                            doctor.practices.insert(index, val),
                            print(doctor.practices.length),
                            print(doctor.practices)
                          },
                      },
                      keyboardType: TextInputType.text,
                      validator: validateName,
                    );
                  }),
            ),
            CustomTextField(
              data: doctor.briefProfile,
              hint: AppStrings.briefProfileLabel,
              lableText: AppStrings.briefProfileLabel,
              keyboardType: TextInputType.text,
              // validator: validateName,
              onChange: (val) => doctor.briefProfile = val,
            ),
            CustomTextField(
              data: doctor.language,
              hint: AppStrings.preferredLanguageLabel,
              lableText: AppStrings.preferredLanguageLabel,
              keyboardType: TextInputType.text,
              // validator: validateName,
              onChange: (val) => doctor.language = val,
            ),
            CustomTextField(
              data: doctor.phoneNumber,
              isEnable: false,
              hint: AppStrings.phoneNumber,
              lableText: AppStrings.phoneNumber,
              keyboardType: TextInputType.phone,
              // validator: validatePhoneNumber,
              onChange: (val) => doctor.phoneNumber = val,
            ),
            CustomTextField(
              data: doctor.experience,
              hint: AppStrings.experience,
              lableText: AppStrings.experience,
              keyboardType: TextInputType.number,
              validator: validateName,
              onChange: (val) => doctor.experience = val,
            ),
            CustomTextField(
              data: doctor.fee,
              hint: AppStrings.fee,
              lableText: AppStrings.fee,
              keyboardType: TextInputType.number,
              validator: validatefees,
              onChange: (val) => doctor.fee = val,
            ),
            CustomTextField(
              data: specialities,
              hint: AppStrings.specialities,
              myfocusnode: myFocusnode,
              key: Key(specialities),
              lableText: AppStrings.specialitiesLable,
              validator: validateName,
              onChange: (val) => specialities = val,
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
                height:
                    doctor.documentUrl != null && doctor.documentUrl.isNotEmpty
                        ? doctor.documentUrl.length > 4
                            ? 150
                            : 100
                        : 0,
                margin: const EdgeInsetsDirectional.only(start: 8, end: 8),
                child: GridView.builder(
                    itemCount: doctor.documentUrl != null &&
                            doctor.documentUrl.isNotEmpty
                        ? doctor.documentUrl.length
                        : 0,
                    physics: AlwaysScrollableScrollPhysics(),
                    shrinkWrap: true,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      childAspectRatio: MediaQuery.of(context).size.width /
                          (MediaQuery.of(context).size.height / 2),
                    ),
                    itemBuilder: (contxt, indx) {
                      return Container(
                        child: InkWell(
                          onTap: () {
                            _documents(doctor.documentUrl[indx]);
                          },
                          child: const Card(
                              color: Colors.white,
                              child: Center(
                                child: Icon(
                                  // Icons.call,
                                  Icons.attach_file,
                                  size: 28.0,
                                  color: Colors.black38,
                                ),
                              )),
                        ),
                      );
                    })),
            Container(
              width: double.infinity,
              height: 40,
              margin: const EdgeInsets.only(top: 12),
              child: InkWell(
                onTap: () {
                  uploadDocuments();
                },
                child: Container(
                  child: const CustomButtonStyle(
                    color: appBarColor,
                    child: Center(
                      child: Text(
                        AppStrings.uploadDocumentLabel,
                        style: TextStyle(
                            fontFamily: fontMontserrat,
                            color: Colors.white,
                            fontSize: 14),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Visibility(
              visible: files != null,
              child: Container(
                height: 100,
                child: ListView.builder(
                    itemCount: files != null ? files.length : 0,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return Center(
                        child: files == null
                            ? const Text(
                                'No file selected.',
                                style: TextStyle(fontFamily: fontMontserrat),
                              )
                            : Text(
                                'File ' + files[index].path,
                                style:
                                    const TextStyle(fontFamily: fontMontserrat),
                              ),
                      );
                    }),
              ),
            ),
            const Center(
              child: Text('Banking Details',
                  style: TextStyle(
                      fontWeight: FontWeight.bold, fontFamily: fontMontserrat)),
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
              decoration: BoxDecoration(
                border: Border.all(),
              ),
              padding: const EdgeInsets.all(10),
              child: Column(
                children: [
                  Row(
                    children: [
                      const Icon(
                        Icons.star_outlined,
                        size: 15,
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      Expanded(
                        child: DropdownButtonFormField(
                          isExpanded: true,
                          value: doctor.bankName ?? 'BANK NAME',
                          items: [
                            'BANK NAME',
                            'ABSA Bank Limited',
                            'African Bank Limited',
                            'Bidvest Bank Limited',
                            'Capitec Bank Limited',
                            'Discovery Bank Limited',
                            'FirstRand Bank Limited',
                            'Grindrod Bank Limited',
                            'Investec Bank Limited',
                            'Nedbank Limited',
                            'Sasfin Bank Limited',
                            'Standard Bank of South Africa Limited',
                            'Tyme Bank Limited',
                            'UBANK Limited'
                          ]
                              .map<DropdownMenuItem>((e) => DropdownMenuItem(
                                    value: e,
                                    child: Text(
                                      e,
                                      style: const TextStyle(
                                          fontFamily: fontMontserrat),
                                    ),
                                  ))
                              .toList(),
                          onChanged: (value) => doctor.bankName = value,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      const Icon(
                        Icons.star_outlined,
                        size: 15,
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      Expanded(
                        child: DropdownButtonFormField(
                          isExpanded: true,
                          value: doctor.bankAccType ?? 'ACCOUNT TYPE',
                          items: [
                            'ACCOUNT TYPE',
                            'Cheque/Current',
                            'Investment',
                            'Savings',
                            'Transmission',
                            'Transactional',
                          ]
                              .map<DropdownMenuItem>((e) => DropdownMenuItem(
                                    value: e,
                                    child: Text(
                                      e,
                                      style: const TextStyle(
                                          fontFamily: fontMontserrat),
                                    ),
                                  ))
                              .toList(),
                          onChanged: (value) => doctor.bankAccType = value,
                        ),
                      ),
                    ],
                  ),
                  Row(children: [
                    const Icon(
                      Icons.star_outlined,
                      size: 15,
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    Expanded(
                      child: CustomTextField(
                        data: doctor.bankAccHolderName ?? '',
                        hint: AppStrings.accountHolderName,
                        lableText: AppStrings.accountHolderName,
                        validator: validateName,
                        onChange: (val) => doctor.bankAccHolderName = val,
                      ),
                    ),
                  ]),
                  Row(children: [
                    const Icon(
                      Icons.star_outlined,
                      size: 15,
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    Expanded(
                      child: CustomTextField(
                        data: doctor.bankAccNumber?.toString(),
                        hint: AppStrings.accountNumber,
                        lableText: AppStrings.accountNumber,
                        keyboardType: TextInputType.number,
                        validator: validateName,
                        onChange: (val) =>
                            doctor.bankAccNumber = int.parse(val),
                      ),
                    ),
                  ]),
                  Container(
                    margin: const EdgeInsets.only(left: 20),
                    child: CustomTextField(
                      data: doctor.bankBranchCode?.toString(),
                      hint: AppStrings.branchCode,
                      lableText: AppStrings.branchCode,
                      keyboardType: TextInputType.number,
                      onChange: (val) => doctor.bankBranchCode =
                          val.isEmpty ? null : int.parse(val),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(left: 20),
                    child: CustomTextField(
                      data: doctor.bankBranchName,
                      hint: AppStrings.branchName,
                      lableText: AppStrings.branchName,
                      onChange: (val) => doctor.bankBranchName = val,
                    ),
                  ),
                  Container(
                    height: 40,
                    margin: const EdgeInsets.only(top: 12),
                    child: InkWell(
                      onTap: () {
                        uploadBankDocuments();
                      },
                      child: Container(
                        child: const CustomButtonStyle(
                          color: appBarColor,
                          child: Center(
                            child: Text(
                              AppStrings.uploadBankDocumentLabel,
                              style: TextStyle(
                                  fontFamily: fontMontserrat,
                                  color: Colors.white,
                                  fontSize: 14),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Visibility(
                    visible: bankDocs != null,
                    child: Container(
                      height: 100,
                      child: ListView.builder(
                          itemCount: bankDocs != null ? bankDocs.length : 0,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return Row(
                              children: [
                                Expanded(
                                  child: InkWell(
                                    child: Text(
                                      bankDocs[index]['fileName'],
                                      style: const TextStyle(
                                          fontFamily: fontMontserrat,
                                          decoration: TextDecoration.underline),
                                    ),
                                    onTap: () =>
                                        _openFile(bankDocs[index]['url']),
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.remove_circle_outline),
                                  color: Colors.red,
                                  onPressed: () {
                                    bankDocs.removeAt(index);
                                    setState(() {});
                                  },
                                )
                              ],
                            );
                          }),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
              height: 100,
              child: Center(
                child: Submit(
                  color: appBarColor,
                  onPress: () => saveChanges(),
                  isLoading: isLoading,
                  lable: AppStrings.save,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openFile(String path) async {
    if (path.contains('firebasestorage')) {
      final bytes = await Utils.imageDownload(path);
      _scaffoldKey.currentState.showSnackBar(SnackBar(
        duration: const Duration(hours: 1),
        backgroundColor: Colors.white,
        content: Image.memory(
          bytes,
          fit: BoxFit.fill,
        ),
      ));
    } else if (path.contains('pdf')) {
      final doc = await PDFDocument.fromURL(path);
      _scaffoldKey.currentState.showSnackBar(SnackBar(
        backgroundColor: Colors.white,
        duration: const Duration(hours: 1),
        content: PDFViewer(document: doc),
      ));
    }
  }

  String _getFileName(String path) {
    return path.split('/').last;
  }

  Widget _buildLocationPicker() {
    return GestureDetector(
      child: Container(
        padding: const EdgeInsets.all(10),
        margin: const EdgeInsets.only(top: 10),
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.all(Radius.circular(10)),
          color: Colors.grey[200],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Latitude/Longitude',
              style: TextStyle(
                fontFamily: fontMontserrat,
                color: Colors.grey,
              ),
            ),
            Text(
              doctor.location.toString(),
              style: const TextStyle(
                fontFamily: fontMontserrat,
                fontSize: 18,
              ),
            ),
          ],
        ),
      ),
      onTap: () => _pickAddressFromMap(context),
    );
  }

  Future<void> _pickAddressFromMap(BuildContext context) async {
    MAddress mAddress = await Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => const GoogleMapScreen(
        isLock: false,
      ),
    ));

    if (mAddress != null)
      setState(() =>
          doctor.location = Location.pickedNew(mAddress.lat, mAddress.lng));
  }

  void _showMultiSelect(BuildContext context) async {
    final items = <MultiSelectDialogItem<int, String, String>>[
      MultiSelectDialogItem(1, "ORTHOPEDICS", "JOINTS AND BONES"),
      MultiSelectDialogItem(2, "GYNEACOLOGY&OBSTRECIANS", "WOMEN\'S HEALTH"),
      MultiSelectDialogItem(3, "UROLOGIST", "URINARY TRACT HEALTH"),
      MultiSelectDialogItem(4, "DERMATOLOGIST", "SKIN"),
      MultiSelectDialogItem(5, "SEXOLOGIST", "SEX SPECIALIST"),
      MultiSelectDialogItem(6, "PHYSIOTHERAPIST", "PHYSICAL INABILITY"),
      MultiSelectDialogItem(7, "DIETICIAN", "DIET AND FITNESS"),
      MultiSelectDialogItem(8, "PSYCHOLOGISTS", "MENTAL HEALTH"),
      MultiSelectDialogItem(9, "PULMONOLOGIST", "LUNG HEALTH"),
      MultiSelectDialogItem(10, "NEPHROLOGIST", "KIDNEYS"),
      MultiSelectDialogItem(11, "HOMEOPATH", "ALTERNATIVE MEDICINE"),
      MultiSelectDialogItem(12, "INFECTIOUS DISEASE SPECIALIST", "HIV/AIDS"),
      MultiSelectDialogItem(13, "GASTROENTEROLOGIST", "DIGESTIVE"),
      MultiSelectDialogItem(14, "PULMONOLORIST", "HEART CONDITION"),
      MultiSelectDialogItem(15, "INFECTIOUS DISEASE SPECIALIST", "COVID-19"),
      MultiSelectDialogItem(
          16, "GENERAL PRACTITIONER", "ACUTE & CHRONIC ILLNESS"),
      MultiSelectDialogItem(17, "GENERAL SURGEON", "OPERATIVE MANAGEMENT"),
      MultiSelectDialogItem(18, "OPTOMETRIST/OPHTHALMOLOGIST", "EYE CARE"),
      MultiSelectDialogItem(19, "OTOLARYNGOLOGIST", "EAR NOSE AND THROAT"),
      MultiSelectDialogItem(20, "ENDOCRINOLOGIST", "DIABETES SPECIALIST"),
      MultiSelectDialogItem(21, "DENTIST/ENDODONTIST", "DENTAL HEALTH"),
      MultiSelectDialogItem(22, "PEADITRICIAN", "CHILD CARE HEALTH"),
      MultiSelectDialogItem(23, "ONCOLOGIST", "CANCER"),
      MultiSelectDialogItem(24, "NEUROLOGIST", "NERVES"),
    ];

    final selectedValues = await showDialog<List<String>>(
      context: context,
      builder: (BuildContext context) {
        return MultiSelectDialog(
          items: items,
          initialSelectedValues: [1, 3].toSet(),
        );
      },
    );

    setState(() {
      specialities = "";
      specialities = selectedValues.join(",");
      print(specialities);
    });
  }

  Future<void> uploadDocuments() async {
    // Wait to get the file path.
    List<File> documentfiles = await FilePicker.getMultiFile(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'pdf', 'doc', 'jpeg'],
    );
    if (documentfiles != null) {
      setState(() {
        files = documentfiles;
      });
    }
  }

  Future<void> uploadBankDocuments() async {
    // Wait to get the file path.
    List<File> documentfiles = await FilePicker.getMultiFile(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'pdf', 'jpeg'],
    );
    if (documentfiles != null) {
      documentfiles.forEach((element) {
        bankDocs
            .add({'fileName': _getFileName(element.path), 'url': element.path});
      });
      setState(() {});
    }
  }

  Future<void> _documents(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    }
  }

  /// Save the changes to the firestore, when the update is complete, sava the changes
  /// in the local storage as well.
  Future<void> saveChanges() async {
    if (bankDocs.isEmpty) {
      Fluttertoast.showToast(
          msg: 'Bank documents should not be empty',
          toastLength: Toast.LENGTH_LONG);
      return;
    }
    if (doctor.bankName == 'BANK NAME') {
      Fluttertoast.showToast(
          msg: 'Please select a bank', toastLength: Toast.LENGTH_LONG);
      return;
    }
    if (doctor.bankAccType == 'ACCOUNT TYPE') {
      Fluttertoast.showToast(
          msg: 'Please select a bank account type',
          toastLength: Toast.LENGTH_LONG);
      return;
    }
    if (validateForm(_formKey)) {
      try {
        setState(() {
          isLoading = true;
        });
        List<String> urls = [];
        // If the file value is not null proceed
        if (files != null) {
          String newUrl = "";
          // get the user id
          /* final userId = LocatorService.userProvider().user.uid;
          String newUrl = "";*/
          // start uploading
          for (var i = 0; i < files.length; i++) {
            newUrl = await FirebaseStorageService.uploadFile(
              files[i],
              fileName: DateTime.now().millisecondsSinceEpoch.toString(),
            );
            urls.insert(i, newUrl);
          }

          // check for upload status
          if (urls != null) {
            doctor.documentUrl = [];
            doctor.documentUrl.addAll(urls);
          }
        }
        if (bankDocs.isNotEmpty) {
          String newUrl = "";
          // get the user id
          /* final userId = LocatorService.userProvider().user.uid;
          String newUrl = "";*/
          // List<Map<String, dynamic>> docs = [];
          // start uploading
          for (var i = 0; i < bankDocs.length; i++) {
            String url = bankDocs[i]['url'];
            if (!url.contains('firebasestorage')) {
              newUrl = await FirebaseStorageService.uploadFile(
                File(url),
                fileName: DateTime.now().millisecondsSinceEpoch.toString(),
              );
              bankDocs[i]['url'] = newUrl;
            }
          }
          doctor.bankDocuments = bankDocs;
        }
        await FirestoreService.updateDoctorData(doctor.toJson());
        LocatorService.doctorProvider().updateDoctorData(doctor);
        setState(() {
          isLoading = false;
        });
        NavigationController.navigator.pop();
      } catch (e) {
        print('____ERR___${e.toString()}');
        Fluttertoast.showToast(msg: e.toString());
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<void> uploadDocument() async {
    List<String> urls = [];
    // If the file value is not null proceed
    if (files != null) {
      // get the user id
      final userId = LocatorService.userProvider().user.uid;
      String newUrl = "";
      if (userId != null && userId != '') {
        // start uploading
        for (var i = 0; i < files.length; i++) {
          newUrl = await FirebaseStorageService.uploadFile(
            files[i],
            fileName: DateTime.now().millisecondsSinceEpoch.toString(),
          );
          urls.insert(i, newUrl);
        }

        // check for upload status
        if (urls != null) {
          // update the database
          await FirestoreService.updateDocumentUrl(urls, userId);
        }
      } else {}
    }
  }

// Functions
  static bool validateForm(GlobalKey<FormState> formKey) {
    if (formKey.currentState.validate()) {
      return true;
    } else {
      return false;
    }
  }

  String validateName(val) {
    if (val.length == 0) {
      return AppStrings.errorShortName;
    }
    return null;
  }

  String validatePhoneNumber(val) {
    if (val == null || val == '') {
      return null;
    }
    if (val.toString().length > 13 || val.toString().length < 7) {
      return AppStrings.errorNumberInvalid;
    }
    if (!val.toString().contains("+27")) {
      return AppStrings.invalidatePhonestartEmpty;
    } else {
      return null;
    }
  }

/*static bool validateFees(GlobalKey<FormState> formKey) {
    if (formKey.currentState.validate()) {
      return true;
    } else {
      return false;
    }
  }*/

  String validatefees(val) {
    if (val.length == 0) {
      return AppStrings.errorShortName;
    } else if (int.parse(val.toString()) < 250) {
      return AppStrings.errorFees;
    }
    return null;
  }

  String validateExp(String val) {
    if (val.isEmpty) {
      return AppStrings.invalidFieldEmpty;
    }

    if (int.parse(val) > 70) {
      return AppStrings.invalidExperienceTooMuch;
    }
    return null;
  }

/* String validateFee(String val) {
    if (val.isEmpty) {
      return AppStrings.invalidFieldEmpty;
    }

    if (int.parse(val) <= 0) {
      return AppStrings.invalidFeeZero;
    }
    return null;
  }*/

  String validateSpecialities(String val) {
    if (val.isEmpty) {
      return AppStrings.invalidFieldEmpty;
    }

    if (Validator.isSpecialitiesValid(val)) {
      return null;
    }
    return AppStrings.invalidSpecialities;
  }
}

///
/// ## `Description`
///
/// PhotoUpdate handler
///
class PhotoUpdate extends StatefulWidget {
  @override
  _PhotoUpdateState createState() => _PhotoUpdateState();
}

class _PhotoUpdateState extends State<PhotoUpdate> {
  bool isLoading = false;
  String url = LocatorService.doctorProvider().doctor.imageUrl;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 120,
      height: 120,
      child: Stack(
        children: <Widget>[
          InkWell(
            onTap: () {
              uploadPhoto();
            },
            child: CachedNetworkImage(
              imageUrl: url,
              placeholder: (context, url) => const CircularProgressIndicator(
                backgroundColor: appBarColor,
              ),
              imageBuilder: (context, imageProvider) => Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image:
                      DecorationImage(image: imageProvider, fit: BoxFit.fill),
                ),
              ),
            ),
          ),
          if (isLoading)
            const Center(
              child: CircularProgressIndicator(
                backgroundColor: appBarColor,
              ),
            ),
        ],
      ),
    );
  }

  Future<void> uploadPhoto() async {
    // Wait to get the file path.
    final imageFile = await ImageService.getImage();

    // If the file value is not null proceed
    if (imageFile != null) {
      setState(() {
        isLoading = true;
      });

      // get the doctor id
      final userId = LocatorService.doctorProvider().doctor.uid;

      if (userId != null && userId != '') {
        // start uploading
        final newUrl = await FirebaseStorageService.uploadFile(
          imageFile,
          fileName: userId,
        );

        // check for upload status
        if (newUrl != null) {
          // update the database
          await FirestoreService.updateDoctorImageUrl(newUrl);
          // Update the data
          LocatorService.doctorProvider().updateImage(newUrl);

          setState(() {
            url = newUrl;
            isLoading = false;
          });
        } else {
          setState(() {
            isLoading = false;
          });
        }
      } else {
        setState(() {
          isLoading = false;
        });
      }
    }
  }
}

class MultiSelectDialogItem<V, String, A> {
  const MultiSelectDialogItem(this.value, this.label, this.metaData);

  final int value;
  final String label;
  final String metaData;
}

class MultiSelectDialog<V> extends StatefulWidget {
  MultiSelectDialog({Key key, this.items, this.initialSelectedValues})
      : super(key: key);

  final List<MultiSelectDialogItem<V, String, String>> items;
  final Set<V> initialSelectedValues;

  @override
  State<StatefulWidget> createState() => _MultiSelectDialogState<V>();
}

class _MultiSelectDialogState<V> extends State<MultiSelectDialog<V>> {
  final _selectedValues = Set<V>();
  List<Speciality> selected = [];

  void initState() {
    super.initState();
    if (widget.initialSelectedValues != null) {
      _selectedValues.addAll(widget.initialSelectedValues);
    }
  }

  void _onItemCheckedChange(String itemValue, bool checked, String metadata) {
    setState(() {
      Speciality speciality = new Speciality();
      speciality.speciality = itemValue;
      speciality.metaData = metadata;
      speciality.ischecked = checked;
      if (checked) {
        selected.add(speciality);
      } else {
        selected.remove(speciality);
      }
    });
  }

  void _onCancelTap() {
    Navigator.pop(context);
  }

  void _onSubmitTap() {
    Navigator.pop(context, selected);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.white,
      title: Text(
        'Select Specialities',
        style: TextStyle(fontFamily: 'Montserrat'),
      ),
      contentPadding: EdgeInsets.only(top: 12.0),
      content: SingleChildScrollView(
        child: Container(
          color: Colors.white,
          child: ListBody(
            children: widget.items.map(_buildItem).toList(),
          ),
        ),
      ),
      actions: <Widget>[
        FlatButton(
          color: appBarColor,
          child: Text(
            'CANCEL',
            style: TextStyle(fontFamily: 'Montserrat'),
          ),
          onPressed: _onCancelTap,
        ),
        FlatButton(
          color: appBarColor,
          child: Text(
            'OK',
            style: TextStyle(fontFamily: 'Montserrat'),
          ),
          onPressed: _onSubmitTap,
        )
      ],
    );
  }

  Widget _buildItem(MultiSelectDialogItem<V, String, String> item) {
    bool checked = false;
    for (int i = 0; i < selected.length; i++) {
      if (selected[i].speciality == item.label) {
        checked = true;
        break;
      }
    }

    return CheckboxListTile(
      value: checked,
      title: Text(
        item.label,
        style: TextStyle(fontFamily: 'Montserrat'),
      ),
      controlAffinity: ListTileControlAffinity.leading,
      onChanged: (checked) =>
          _onItemCheckedChange(item.label, checked, item.metaData),
    );
  }
}
