import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/customized/pie_chart/pie_chart.dart';
import 'package:medivic/customized/pie_chart/chart_values_options.dart';
import 'package:medivic/customized/pie_chart/legend_options.dart';
import 'package:medivic/customized/pie_chart/pie_chart.dart';
import 'package:medivic/extensions/date_extensions.dart';
import 'package:medivic/models/payment.dart';

class EarningsPieChart extends StatefulWidget {
  const EarningsPieChart(this.payments);

  final List<Payment> payments;

  @override
  _EarningsPieChartState createState() => _EarningsPieChartState();
}

class _EarningsPieChartState extends State<EarningsPieChart> {
  final List<String> spans = const ['Day', 'Week', 'Month', 'Year'];
  String span;

  @override
  void initState() {
    super.initState();
    span = spans.first;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildDropdownButton(),
            const Divider(),
            _buildEarningPieChart(
              _calculateEarningsForSpan(false),
              _calculateEarningsForSpan(true),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildDropdownButton() {
    return DropdownButton<String>(
      isExpanded: true,
      value: span,
      icon: const Icon(Icons.keyboard_arrow_down),
      iconSize: 32,
      elevation: 16,
      underline: Container(),
      onChanged: (String value) => setState(() => span = value),
      items: spans.map((String value) => _buildDropDownItem(value)).toList(),
    );
  }

  DropdownMenuItem<String> _buildDropDownItem(String value) {
    return DropdownMenuItem(
      value: value,
      child: Text(
        value,
        style: const TextStyle(
          fontSize: 16,
          fontFamily: fontMontserrat,
        ),
      ),
    );
  }

  Widget _buildEarningPieChart(double reserved, double received) {
    final Map<String, double> dataMap = {
      'Reserved': reserved,
      'Received': received,
    };
    return Container(
      margin: const EdgeInsets.only(top: 16),
      child: PieChart(
        dataMap: dataMap,
        animationDuration: const Duration(milliseconds: 800),
        chartRadius: MediaQuery.of(context).size.width / 3,
        colorList: [Colors.red, appBarColor],
        initialAngleInDegree: 0,
        chartType: ChartType.ring,
        chartLegendSpacing: 32,
        ringStrokeWidth: 28,
        legendOptions: const LegendOptions(
          showLegendsInRow: true,
          legendPosition: LegendPosition.bottom,
          showLegends: true,
          legendShape: BoxShape.circle,
          legendTextStyle: TextStyle(
            fontWeight: FontWeight.bold,
            fontFamily: fontMontserrat,
          ),
        ),
        formatChartValues: (double val) => 'R ${val.toStringAsFixed(2)}',
        chartValuesOptions: const ChartValuesOptions(
          showChartValueBackground: true,
          showChartValues: true,
          showChartValuesInPercentage: false,
          showChartValuesOutside: true,
        ),
      ),
    );
  }

  double _calculateEarningsForSpan(bool paid) {
    DateTime boundary;
    if (span == 'Week') {
      boundary = DateExtension.getStartOfWeek();
    } else if (span == 'Month') {
      boundary = DateExtension.getStartOfMonth();
    } else if (span == 'Year') {
      boundary = DateExtension.getStartOfYear();
    } else {
      boundary = DateExtension.getStartOfToday();
    }
    final List<double> fees = widget.payments
        .where((element) => element.paid == paid)
        .where((element) => element.getCreatedAt().isAfter(boundary))
        .map((e) => e.feeWithoutCommission())
        .toList();
    return fees.isEmpty ? 0 : fees.reduce((a, b) => a + b);
  }
}
