import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/extensions/date_extensions.dart';
import 'package:medivic/models/payment.dart';
import 'package:medivic/shared/widgets/tooltip.dart';

class EarningsTable extends StatelessWidget {
  const EarningsTable(this.payments, this.viewType, this.received);

  final List<Payment> payments;
  final int viewType;
  final bool received;

  @override
  Widget build(BuildContext context) {
    if (payments.isEmpty) {
      return const Expanded(
        child: Center(
            child: Text(
          'There are no transactions during selected period.',
          style: TextStyle(fontFamily: fontMontserrat),
        )),
      );
    } else {
      return _buildTable();
    }
  }

  Widget _buildTable() {
    final List<TableRow> tableChildren = [_buildTableHeadRow()];
    tableChildren.addAll(payments.map((e) => _buildTableRow(e)).toList());
    tableChildren.add(_buildTableHeadFooter());
    return Table(
      border: TableBorder.all(color: Colors.black26, width: 1),
      children: tableChildren,
    );
  }

  TableRow _buildTableHeadRow() {
    String primaryColumnTitle = 'Patient';
    if (viewType == 1) {
      primaryColumnTitle = 'Date';
    } else if (viewType == 2) {
      primaryColumnTitle = 'Month';
    }
    return TableRow(
        decoration: const BoxDecoration(color: appBarColor),
        children: [
          TableCell(
            child: _buildTableHeadData(primaryColumnTitle),
            verticalAlignment: TableCellVerticalAlignment.middle,
          ),
          TableCell(
            child: _buildTableHeadData('Fee'),
            verticalAlignment: TableCellVerticalAlignment.middle,
          ),
          TableCell(
            child: _buildTableHeadData(
              'Commission',
              message: 'Commission Paid',
            ),
            verticalAlignment: TableCellVerticalAlignment.middle,
          ),
          TableCell(
            child: _buildTableHeadData(
              received ? 'Received' : 'Reserved',
              message: 'Net Amount ${received ? 'Received' : 'Reserved'}',
            ),
            verticalAlignment: TableCellVerticalAlignment.middle,
          ),
        ]);
  }

  Widget _buildTableHeadData(String text, {String message}) {
    return ToolTip(
      message: message ?? '',
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
        child: Row(
          children: [
            Expanded(
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontFamily: fontMontserrat,
                  color: Colors.white,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            if (message == null)
              Container()
            else
              const Icon(
                Icons.info_outline,
                color: Colors.white,
                size: 16,
              ),
          ],
        ),
      ),
    );
  }

  TableRow _buildTableRow(Payment payment) {
    String primaryColumnData = payment.patientName;
    if (viewType == 1) {
      primaryColumnData = payment.getCreatedAt().formatShortDate();
    } else if (viewType == 2) {
      primaryColumnData = payment.getCreatedAt().formatMonthName();
    }
    return TableRow(children: [
      TableCell(
        child: _buildTableData(primaryColumnData),
        verticalAlignment: TableCellVerticalAlignment.middle,
      ),
      TableCell(
        child: _buildTableData(payment.fee.toStringAsFixed(2)),
        verticalAlignment: TableCellVerticalAlignment.middle,
      ),
      TableCell(
        child: _buildTableData(payment.commission().toStringAsFixed(2)),
        verticalAlignment: TableCellVerticalAlignment.middle,
      ),
      TableCell(
        child:
            _buildTableData(payment.feeWithoutCommission().toStringAsFixed(2)),
        verticalAlignment: TableCellVerticalAlignment.middle,
      ),
    ]);
  }

  Widget _buildTableData(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
      child: ToolTip(
        message: text,
        child: Text(
          text,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontFamily: fontMontserrat,
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

  TableRow _buildTableHeadFooter() {
    return TableRow(
      decoration: const BoxDecoration(color: appBarColor),
      children: [
        TableCell(
          child: _buildTableHeadData('Totals'),
          verticalAlignment: TableCellVerticalAlignment.middle,
        ),
        TableCell(
          child: _buildTableHeadData(_getTotalFee().toStringAsFixed(2)),
          verticalAlignment: TableCellVerticalAlignment.middle,
        ),
        TableCell(
          child: _buildTableHeadData(_getTotalCommission().toStringAsFixed(2)),
          verticalAlignment: TableCellVerticalAlignment.middle,
        ),
        TableCell(
          child: _buildTableHeadData(
              _getTotalFeeWithoutCommission().toStringAsFixed(2)),
          verticalAlignment: TableCellVerticalAlignment.middle,
        ),
      ],
    );
  }

  double _getTotalFee() {
    return payments.isEmpty
        ? 0
        : payments.map((e) => e.fee).reduce((a, b) => a + b);
  }

  double _getTotalCommission() {
    return payments.isEmpty
        ? 0
        : payments.map((e) => e.commission()).reduce((a, b) => a + b);
  }

  double _getTotalFeeWithoutCommission() {
    return payments.isEmpty
        ? 0
        : payments.map((e) => e.feeWithoutCommission()).reduce((a, b) => a + b);
  }
}
