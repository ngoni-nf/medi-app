import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/extensions/date_extensions.dart';
import 'package:medivic/models/payment.dart';
import 'package:medivic/screens/doctorsAccountScreens/earnings/components/table.dart';

class EarningsReportScreen extends StatelessWidget {
  EarningsReportScreen(this.title, this.payments, this.received);

  final List<String> tabTitles = ['Day', 'Week', 'Month', 'Year'];

  final String title;
  final List<Payment> payments;
  final bool received;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: tabTitles.length,
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: _buildBody(),
      ),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      title: Text(
        title,
        style: styleAppbarTitle,
      ),
      backgroundColor: appBarColor,
      leading: IconButton(
        icon: const Icon(
          Icons.arrow_back,
          color: Colors.white,
          size: 30,
        ),
        onPressed: () => Navigator.of(context).pop(),
      ),
      iconTheme: const IconThemeData(color: Colors.white),
      bottom: _buildTabBar(),
    );
  }

  TabBar _buildTabBar() {
    return TabBar(
      indicatorColor: Colors.white,
      tabs: tabTitles.map((e) => Tab(text: e)).toList(),
    );
  }

  TabBarView _buildBody() {
    return TabBarView(
      children: tabTitles.map((e) => _buildReport(e)).toList(),
    );
  }

  Widget _buildReport(String span) {
    DateTime boundary;
    String spanTitle;
    int viewType;

    if (span == 'Week') {
      boundary = DateExtension.getStartOfWeek();
      spanTitle =
          '${boundary.formatWeekDate()} - ${DateTime.now().formatWeekDate()}';
      viewType = 1;
    } else if (span == 'Month') {
      boundary = DateExtension.getStartOfMonth();
      spanTitle = boundary.formatMonthYear();
      viewType = 1;
    } else if (span == 'Year') {
      boundary = DateExtension.getStartOfYear();
      spanTitle = boundary.year.toString();
      viewType = 2;
    } else {
      boundary = DateExtension.getStartOfToday();
      spanTitle = boundary.formatFullDate();
      viewType = 0;
    }

    final List<Payment> filteredPayments = payments
        .where((element) => element.getCreatedAt().isAfter(boundary))
        .toList();

    return Padding(
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          _buildSpanTitle(spanTitle),
          const SizedBox(height: 8),
          EarningsTable(
            getGroupedPayments(
              filteredPayments,
              viewType,
            ),
            viewType,
            received,
          ),
        ],
      ),
    );
  }

  Widget _buildSpanTitle(String text) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Text(
        text,
        style: const TextStyle(
          fontFamily: fontMontserrat,
          fontSize: 18,
        ),
      ),
    );
  }

  List<Payment> getGroupedPayments(
    List<Payment> filteredPayments,
    int viewType,
  ) {
    if (viewType == 0) {
      return filteredPayments;
    }
    final Map<DateTime, Payment> paymentsByDate = {};
    for (final Payment payment in filteredPayments) {
      DateTime paymentDate = payment.getCreatedAt();
      if (viewType == 1) {
        paymentDate = DateTime(
          paymentDate.year,
          paymentDate.month,
          paymentDate.day,
        );
      } else if (viewType == 2) {
        paymentDate = DateTime(
          paymentDate.year,
          paymentDate.month,
        );
      }
      if (paymentsByDate.containsKey(paymentDate)) {
        paymentsByDate[paymentDate].fee =
            payment.fee + paymentsByDate[paymentDate].fee;
      } else {
        paymentsByDate[paymentDate] = payment.copy();
      }
    }
    return paymentsByDate.values.toList();
  }
}
