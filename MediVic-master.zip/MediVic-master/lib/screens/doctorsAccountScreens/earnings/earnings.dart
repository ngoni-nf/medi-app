import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/payment.dart';
import 'package:medivic/screens/doctorsAccountScreens/earnings/components/pie_chart.dart';
import 'package:medivic/screens/doctorsAccountScreens/homeDoctor/drawerDoctor.dart';
import 'package:medivic/screens/notification/notification.dart';
import 'package:medivic/utils/hex_color.dart';

import 'earnings_report.dart';

class EarningsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(context),
      body: _buildBody(),
      endDrawer: SafeArea(child: DrawerDoctor()),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
        title: const Text(
          'Earnings Report',
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
        leading: IconButton(
          icon: const Icon(
            Icons.notifications,
            color: Colors.white,
            size: 30,
          ),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => NotificationScreen()),
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white));
  }

  Widget _buildBody() {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: FutureBuilder<List<Payment>>(
        future: _fetchPayments(),
        builder: (BuildContext context, AsyncSnapshot<List<Payment>> snapshot) {
          if (snapshot.hasData) {
            return _buildEarningsBody(snapshot.data);
          } else if (snapshot.hasError) {
            print(snapshot.error);
            return _buildError();
          } else {
            return _buildProgress();
          }
        },
      ),
    );
  }

  Widget _buildEarningsBody(List<Payment> payments) {
    return SingleChildScrollView(
      child: Column(
        children: [
          _buildEarningsButton(
            'Reserved Earnings',
            payments.where((element) => !element.paid).toList(),
            false,
          ),
          _buildEarningsButton(
            'Received Earnings',
            payments.where((element) => element.paid).toList(),
            true,
          ),
          const SizedBox(height: 8),
          EarningsPieChart(payments),
        ],
      ),
    );
  }

  Widget _buildEarningsButton(String title, List<Payment> payments, bool paid) {
    return InkWell(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: fontMontserrat,
                  color: darkBlueColor,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${Config.CURRENCY} ${_getTotalEarnings(payments).toStringAsFixed(2)}',
                style: const TextStyle(
                  fontSize: 24,
                  color: Colors.grey,
                  fontFamily: fontMontserrat,
                ),
              ),
              const Text(
                'Tap for details',
                style: TextStyle(
                  fontFamily: fontMontserrat,
                  color: Colors.grey,
                  fontSize: 12,
                ),
              )
            ],
          ),
        ),
      ),
      onTap: () {
        NavigationController.navigator.push(
          MaterialPageRoute(
              builder: (context) => EarningsReportScreen(
                    title,
                    payments,
                    paid,
                  )),
        );
      },
    );
  }

  Widget _buildProgress() {
    return const Center(
      child: CircularProgressIndicator(backgroundColor: appBarColor),
    );
  }

  Widget _buildError() {
    return const Center(
      child: Text(
        AppStrings.somethingWentWrong,
        style: TextStyle(fontFamily: fontMontserrat),
      ),
    );
  }

  Future<List<Payment>> _fetchPayments() async {
    final QuerySnapshot querySnapshot = await Firestore.instance
        .collection(Payment.COLLECTION_NAME)
        .where('doctorId',
            isEqualTo: LocatorService.doctorProvider().doctor.uid)
        .getDocuments();
    return Payment.parseList(querySnapshot);
  }

  double _getTotalEarnings(List<Payment> payments) {
    final List<double> fees =
        payments.map((e) => e.feeWithoutCommission()).toList();
    return fees.isEmpty ? 0 : fees.reduce((a, b) => a + b);
  }
}
