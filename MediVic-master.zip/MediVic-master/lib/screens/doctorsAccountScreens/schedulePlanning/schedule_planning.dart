import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/extensions/date_extensions.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/appointment.dart';
import 'package:medivic/models/operation.dart';
import 'package:medivic/models/slot.dart';
import 'package:medivic/screens/doctorsAccountScreens/homeDoctor/drawerDoctor.dart';
import 'package:medivic/screens/doctorsAccountScreens/schedulePlanning/components/slot_table.dart';
import 'package:medivic/screens/notification/notification.dart';
import 'package:medivic/utils/appointment_utils.dart';

class SchedulePlanningScreen extends StatefulWidget {
  @override
  _SchedulePlanningScreenState createState() => _SchedulePlanningScreenState();
}

class _SchedulePlanningScreenState extends State<SchedulePlanningScreen> {
  final String doctorId = LocatorService.doctorProvider().doctor.uid;
  final GlobalKey<ScaffoldState> _drawerKey = GlobalKey();

  DateTime selectedDay;
  List<DateTime> monthDays = [];
  List<DateTime> weekDays = [];
  List<Slot> slots = [];
  List<Slot> doctorAvailableSlots;
  List<Slot> doctorAvailableSlotsForSelectedDay = [];
  bool savingData = false;
  bool officeHoursView = true;

  @override
  void initState() {
    super.initState();
    selectedDay = DateTime.now();
    _fetchDoctorAvailableSlots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _drawerKey,
      appBar: _buildAppBar(),
      body: _buildBody(),
      endDrawer: SafeArea(child: DrawerDoctor()),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
        title: const Text(
          AppStrings.schedulePlanning,
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
        // leading: GestureDetector(
        //   onTap: () => Navigator.pop(context),
        //   child: const Icon(Icons.arrow_back, color: Colors.white),
        // ),
        leading: IconButton(
            icon: const Icon(
              Icons.notifications,
              color: Colors.white,
              size: 30,
            ),
            onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => NotificationScreen(),
                ))),
        actions: doctorAvailableSlots == null
            ? [
                IconButton(
                  icon: const Icon(
                    Icons.menu,
                    size: 28,
                    color: Colors.white,
                  ),
                  onPressed: () => _drawerKey.currentState.openEndDrawer(),
                ),
              ]
            : [
                PopupMenuButton(
                  icon: const Icon(Icons.more_vert, color: Colors.white),
                  onSelected: (choice) {
                    setState(() => officeHoursView = !officeHoursView);
                  },
                  itemBuilder: (BuildContext context) {
                    return {
                      if (officeHoursView)
                        '24 hour view'
                      else
                        '08:00 to 18:00 view'
                    }.map((String choice) {
                      return PopupMenuItem<String>(
                        value: choice,
                        child: Text(
                          choice,
                          style: const TextStyle(fontFamily: fontMontserrat),
                        ),
                      );
                    }).toList();
                  },
                ),
                IconButton(
                  icon: const Icon(
                    Icons.menu,
                    size: 28,
                    color: Colors.white,
                  ),
                  onPressed: () => _drawerKey.currentState.openEndDrawer(),
                ),
              ]);
  }

  Widget _buildBody() {
    return doctorAvailableSlots == null
        ? const Center(
            child: CircularProgressIndicator(backgroundColor: appBarColor),
          )
        : Container(
            padding: const EdgeInsets.all(8),
            child: Column(
              children: [
                _buildDaySelector(),
                SlotTable(
                  slots,
                  doctorId,
                  officeHoursView,
                  (value) => slots = value,
                ),
                _buildSaveButtons(),
              ],
            ),
          );
  }

  Widget _buildDaySelector() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios),
            color: selectedDay.difference(DateTime.now()).inDays > 6
                ? Colors.black
                : Colors.grey.withOpacity(0.5),
            onPressed: () =>
                _setSelectedDay(selectedDay.subtract(const Duration(days: 7))),
          ),
          IconButton(
            icon: const Icon(Icons.keyboard_arrow_left),
            color: selectedDay.isAfterToday()
                ? Colors.black
                : Colors.grey.withOpacity(0.5),
            onPressed: () =>
                _setSelectedDay(selectedDay.subtract(const Duration(days: 1))),
          ),
          GestureDetector(
            child: Column(
              children: [
                Text(
                  selectedDay.formatShortDate(),
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontFamily: fontMontserrat,
                    fontFeatures: [FontFeature.tabularFigures()],
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Week #${selectedDay.weekNumber()}',
                  style: const TextStyle(
                    fontSize: 12,
                    fontFamily: fontMontserrat,
                  ),
                ),
              ],
            ),
            onTap: () => _showDatePicker(context),
          ),
          IconButton(
            icon: const Icon(Icons.keyboard_arrow_right),
            onPressed: () =>
                _setSelectedDay(selectedDay.add(const Duration(days: 1))),
          ),
          IconButton(
            icon: const Icon(Icons.arrow_forward_ios),
            onPressed: () =>
                _setSelectedDay(selectedDay.add(const Duration(days: 7))),
          ),
        ],
      ),
    );
  }

  void _setSelectedDay(DateTime day) {
    if (day.isBeforeToday() || !mounted) {
      return;
    }
    setState(() {
      selectedDay = day;
      monthDays =
          AppointmentUtils.getMonthDays(selectedDay.year, selectedDay.month);
      weekDays = AppointmentUtils.getWeekDays(selectedDay);
      slots = AppointmentUtils.generateSlots(selectedDay);
      doctorAvailableSlotsForSelectedDay = doctorAvailableSlots
          .where((element) => element.date.isSameDay(selectedDay))
          .toList();
      for (final Slot slot in slots) {
        slot.doctorId = doctorAvailableSlotsForSelectedDay
                .where((element) => element.equals(slot))
                .isNotEmpty
            ? doctorId
            : '';
      }
    });
  }

  Widget _buildSaveButtons() {
    return Stack(
      alignment: Alignment.center,
      children: [
        Visibility(
            visible: savingData,
            child:
                const CircularProgressIndicator(backgroundColor: appBarColor)),
        Visibility(
          visible: !savingData,
          maintainSize: true,
          maintainAnimation: true,
          maintainState: true,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildSaveButton(
                '',
                'Apply',
                () => _saveSlots([selectedDay]),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                      child: _buildSaveButton(
                    weekDays.isEmpty
                        ? ''
                        : '${weekDays.first.formatDayAndMonthShort()} - ${weekDays.last.formatDayAndMonthShort()}',
                    'Apply to the week',
                    () => _saveSlots(weekDays),
                  )),
                  const SizedBox(width: 8),
                  Expanded(
                      child: _buildSaveButton(
                    monthDays.isEmpty
                        ? ''
                        : '${monthDays.first.formatDayAndMonthShort()} - ${monthDays.last.formatDayAndMonthShort()}',
                    'Apply to the month',
                    () => _saveSlots(monthDays),
                  )),
                ],
              )
            ],
          ),
        )
      ],
    );
  }

  Widget _buildSaveButton(String label, String text, Function onPressed) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Center(
            child: Text(label,
                style:
                    const TextStyle(fontSize: 12, fontFamily: fontMontserrat))),
        RaisedButton(
          onPressed: onPressed,
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Text(
              text,
              style: const TextStyle(
                  color: Colors.white, fontFamily: fontMontserrat),
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _showDatePicker(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
      context: context,
      initialDate: selectedDay,
      firstDate: DateTime.now(),
      lastDate: DateTime(selectedDay.year + 2),
      builder: (BuildContext context, Widget child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(primary: appBarColor),
          ),
          child: child,
        );
      },
    );
    if (pickedDate != null && !pickedDate.isSameDay(selectedDay)) {
      _setSelectedDay(pickedDate);
    }
  }

  Future<void> _fetchDoctorAvailableSlots() async {
    await Firestore.instance
        .collection(Slot.COLLECTION_NAME)
        .where('doctorId', isEqualTo: doctorId)
        .getDocuments()
        .then((value) => doctorAvailableSlots = Slot.parseList(value.documents))
        .catchError((err) => doctorAvailableSlots = []);
    _setSelectedDay(selectedDay);
  }

  Future<void> _saveSlots(List<DateTime> dates) async {
    setState(() => savingData = true);
    try {
      final firestoreInstance = Firestore.instance;
      final CollectionReference collectionRef =
          firestoreInstance.collection(Slot.COLLECTION_NAME);
      final QuerySnapshot querySnapshot = await collectionRef
          .where('doctorId', isEqualTo: doctorId)
          .getDocuments();
      final List<Operation> operations = [];
      for (final DateTime date in dates) {
        //Generate slots & ids on local for that day
        final List<Slot> localAvailableSlots =
            slots.where((element) => element.isDoctorAvailable()).toList();
        for (final Slot slot in localAvailableSlots) {
          slot.setDate(date);
        }
        final List<String> localAvailableSlotsId =
            localAvailableSlots.map((e) => e.getId()).toList();

        //Remove slots that exists on server but does not exist on local
        for (final DocumentSnapshot docSnapshot in querySnapshot.documents) {
          final Slot slot = Slot.fromJson(docSnapshot.data);
          if (slot.date.isSameDay(date) &&
              !localAvailableSlotsId.contains(slot.getId())) {
            operations.add(Operation(
                collectionRef.document(docSnapshot.documentID), null));
          }
        }

        //Generate id of slots on server for that day
        final List<String> serverAvailableSlotsId =
            Slot.parseList(querySnapshot.documents)
                .where((element) => element.date.isSameDay(date))
                .map((e) => e.getId())
                .toList();

        //Add slots that exists on local but not exists on server
        for (final Slot slot in localAvailableSlots) {
          if (!serverAvailableSlotsId.contains(slot.getId())) {
            operations.add(Operation(collectionRef.document(), slot.toJson()));
          }
        }
      }

      //Commit your changes to firestore by creating batch 0f 500 operations
      if (operations.isNotEmpty) {
        for (final List<Operation> chunk
            in Operation.convertToChunks(operations)) {
          final WriteBatch batch = firestoreInstance.batch();
          for (final operation in chunk) {
            if (operation.data == null) {
              batch.delete(operation.document);
            } else {
              batch.setData(operation.document, operation.data);
            }
          }
          await batch.commit();
        }
        await _fetchDoctorAvailableSlots();
      }
    } catch (e) {
      print(e.toString());
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
    }
    setState(() => savingData = false);
  }
}
