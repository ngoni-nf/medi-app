import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/models/slot.dart';
import 'package:medivic/screens/doctorsAccountScreens/schedulePlanning/components/availability_switch.dart';

class SlotTable extends StatefulWidget {
  const SlotTable(
    this.slots,
    this.doctorId,
    this.officeHoursView,
    this.function,
  );

  final List<Slot> slots;
  final String doctorId;
  final bool officeHoursView;
  final Function function;

  @override
  _SlotTableState createState() => _SlotTableState();
}

class _SlotTableState extends State<SlotTable> {
  List<Slot> slots;

  @override
  void initState() {
    super.initState();
    slots = widget.slots;
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          _buildSlotTableHead(),
          _buildSlotTableBody(),
        ],
      ),
    );
  }

  Widget _buildSlotTableHead() {
    return Row(
      children: [
        _buildSlotTableData(text: 'Start', header: true),
        _buildSlotTableData(text: 'End', header: true),
        _buildSlotTableData(text: 'Available', header: true, selectAll: true),
      ],
    );
  }

  Widget _buildSlotTableBody() {
    return Expanded(
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(
            width: 0.6,
            color: Colors.grey,
          ),
        ),
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: slots.length,
          itemBuilder: (context, index) => _buildSlotTableRow(index),
        ),
      ),
    );
  }

  Widget _buildSlotTableRow(int index) {
    final Slot slot = slots[index];
    if (widget.officeHoursView && !slot.insideOfficeHour) {
      return Container();
    } else {
      return IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildSlotTableData(text: slot.startTime),
            _buildSlotTableData(text: slot.endTime),
            Expanded(
              child: Container(
                decoration: _buildSlotTableDataDecoration(false),
                child: Center(
                  child: AvailabilitySwitch(
                    slot.isDoctorAvailable(),
                    (value) {
                      slots[index].doctorId = value ? widget.doctorId : '';
                      _notifyChange();
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }
  }

  Widget _buildSlotTableData({
    String text = '',
    bool header = false,
    bool selectAll = false,
  }) {
    return Expanded(
      child: InkWell(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: _buildSlotTableDataDecoration(header),
          child: Center(
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontWeight: header ? FontWeight.bold : FontWeight.normal,
                color: header ? Colors.white : Colors.black,
                fontFamily: fontMontserrat,
              ),
            ),
          ),
        ),
        onTap: () {
          if (selectAll) {
            _updateAll();
          }
        },
      ),
    );
  }

  BoxDecoration _buildSlotTableDataDecoration(bool header) {
    return BoxDecoration(
        border: Border.all(width: 0.2, color: Colors.grey),
        color: header ? appBarColor : Colors.white);
  }

  void _notifyChange() => widget.function(slots);

  void _updateAll() {
    final bool available = slots
        .where((element) => !widget.officeHoursView || element.insideOfficeHour)
        .where((element) => !element.isDoctorAvailable())
        .isNotEmpty;
    for (final Slot slot in slots) {
      if (!widget.officeHoursView || slot.insideOfficeHour)
        slot.doctorId = available ? widget.doctorId : '';
    }
    setState(() {});
    _notifyChange();
  }

  @override
  void didUpdateWidget(covariant SlotTable oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!listEquals(oldWidget.slots, widget.slots)) {
      slots = widget.slots;
    }
  }
}
