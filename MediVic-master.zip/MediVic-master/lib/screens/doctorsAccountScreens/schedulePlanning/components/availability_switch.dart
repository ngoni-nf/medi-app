import 'package:flutter/material.dart';

class AvailabilitySwitch extends StatefulWidget {
  const AvailabilitySwitch(this.value, this.function, {Key key})
      : super(key: key);

  final bool value;
  final Function function;

  @override
  _AvailabilitySwitchState createState() => _AvailabilitySwitchState();
}

class _AvailabilitySwitchState extends State<AvailabilitySwitch> {
  _AvailabilitySwitchState();

  bool value;

  @override
  void initState() {
    super.initState();
    value = widget.value;
  }

  @override
  Widget build(BuildContext context) {
    return Switch(
      onChanged: (bool v) {
        setState(() => value = v);
        widget.function(v);
      },
      value: value,
    );
  }

  @override
  void didUpdateWidget(covariant AvailabilitySwitch oldWidget) {
    super.didUpdateWidget(oldWidget);
    value = widget.value;
  }
}
