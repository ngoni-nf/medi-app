import 'package:advance_pdf_viewer/advance_pdf_viewer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/note.dart';
import 'package:medivic/screens/doctorsAccountScreens/add_note.dart';
import 'package:medivic/services/api/firebaseStorageService.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/utils/utils.dart';
import 'package:collection/collection.dart';

class ViewNotes extends StatefulWidget {
  @override
  _ViewNotesState createState() => _ViewNotesState();
}

class _ViewNotesState extends State<ViewNotes> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: appBarColor,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Notes',
          style: styleAppbarTitle,
        ),
      ),
      body: FutureBuilder(
        future: FirestoreService.getNotes(
            LocatorService.doctorProvider().doctor.uid),
        builder: (BuildContext context, AsyncSnapshot<List<Note>> snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data.isNotEmpty)
              return _buildNameList(snapshot.data);
            else
              return const Center(
                child: Text(
                  'No notes found',
                  style: TextStyle(fontFamily: fontMontserrat),
                ),
              );
          }

          return const Center(
              child: CircularProgressIndicator(backgroundColor: appBarColor));
        },
      ),
    );
  }

  Widget leading(String name) {
    return CircleAvatar(
      maxRadius: 25,
      child: Text(
        name.substring(0, 1).toUpperCase(),
        style: const TextStyle(
            fontFamily: fontMontserrat,
            fontSize: 20,
            fontWeight: FontWeight.bold),
      ),
      backgroundColor: darkBlueColor,
    );
  }

  Widget _buildNameList(List<Note> prescriptions) {
    final Map<String, List<Note>> data =
        groupBy(prescriptions, (Note obj) => obj.patientName);

    return ListView.builder(
      itemCount: data.keys.length,
      itemBuilder: (context, index) => Card(
        color: Colors.grey[200],
        child: ListTile(
          onTap: () {
            // _buildList(data.values.elementAt(index));
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => NoteList(
                    notes: data.values.elementAt(index),
                  ),
                ));
          },
          title: Text(data.keys.elementAt(index)),
          leading: leading(data.keys.elementAt(index)),
        ),
      ),
    );
  }
}

class NoteList extends StatefulWidget {
  final List<Note> notes;

  const NoteList({Key key, this.notes}) : super(key: key);
  @override
  _NoteListState createState() => _NoteListState();
}

class _NoteListState extends State<NoteList> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  void deleteNote(Note note, List<Note> notes) async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.white,
        content: const Text(
          'Are you sure to delete?',
          style: TextStyle(fontFamily: fontMontserrat),
        ),
        actions: [
          FlatButton(
              onPressed: () async {
                FirestoreService.deleteNote(note.docId, () {
                  notes.remove(note);
                  setState(() {});
                });
                Navigator.pop(context);
              },
              child: const Text(
                'Yes',
                style: TextStyle(fontFamily: fontMontserrat),
              )),
          FlatButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text(
                'No',
                style: TextStyle(fontFamily: fontMontserrat),
              ))
        ],
      ),
    );
  }

  Widget _buildList(List<Note> notes) {
    return ListView.builder(
      itemCount: notes.length,
      itemBuilder: (context, index) {
        final note = notes[index];
        return InkWell(
          onLongPress: () {
            deleteNote(note, notes);
          },
          onTap: () async {
            final bool isAdded = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AddNote(
                    note: note,
                  ),
                ));
            if (isAdded != null && isAdded) {
              setState(() {});
            }
          },
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            child: Padding(
              padding: const EdgeInsets.all(14.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    note.note,
                    style: const TextStyle(fontFamily: fontMontserrat),
                    maxLines: 2,
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        Utils.getDateStr(note.createdAt),
                        style: const TextStyle(
                            fontFamily: fontMontserrat, fontSize: 12),
                      ),
                      Text(
                        Utils.getTimeStr(note.createdAt),
                        style: const TextStyle(
                            fontFamily: fontMontserrat, fontSize: 10),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (note.imageUrl != null)
                        _buildImageOrPDF(note.imageUrl),
                      const SizedBox(
                        width: 10,
                      ),
                      if (note.fileUrl != null) _buildImageOrPDF(note.fileUrl),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildImageOrPDF(String fileUrl) {
    return InkWell(
      onTap: () => fileUrl.contains('pdf')
          ? _pdfDownload(fileUrl)
          : _imageDownload(fileUrl),
      child: fileUrl.contains('pdf')
          ? Image.asset(
              'assets/pdf.png',
              width: 50,
              height: 50,
            )
          : CachedNetworkImage(
              imageUrl: fileUrl,
              width: 50,
              height: 50,
              placeholder: (context, url) => const Center(
                child: CircularProgressIndicator(
                  backgroundColor: appBarColor,
                ),
              ),
            ),
    );
  }

  void _pdfDownload(String fileUrl) async {
    Fluttertoast.showToast(msg: 'PDF file is downloading');
    final doc = await PDFDocument.fromURL(fileUrl);
    print('download completed ${doc.count}');

    _scaffoldKey.currentState.showSnackBar(SnackBar(
      backgroundColor: Colors.white,
      duration: const Duration(hours: 1),
      content: PDFViewer(document: doc),
    ));
  }

  void _imageDownload(String url) async {
    final bodyBytes = await FirebaseStorageService.imageDownload(url);
    _scaffoldKey.currentState.showSnackBar(SnackBar(
      backgroundColor: Colors.white,
      content: Image.memory(
        bodyBytes,
        fit: BoxFit.fill,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: appBarColor,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          widget.notes.isNotEmpty ? widget.notes[0].patientName : 'Notes',
          style: styleAppbarTitle,
        ),
      ),
      key: _scaffoldKey,
      body: _buildList(widget.notes),
    );
  }
}
