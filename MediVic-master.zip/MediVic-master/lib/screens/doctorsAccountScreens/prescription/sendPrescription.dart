import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_email_sender/flutter_email_sender.dart';
import 'package:medivic/const.dart';
import 'package:medivic/models/hospitalModel.dart';

class SendPrescription extends StatefulWidget {
  final Hospital hospital;

  const SendPrescription({Key key, this.hospital}) : super(key: key);

  @override
  _SendPrescriptionState createState() => _SendPrescriptionState();
}

class _SendPrescriptionState extends State<SendPrescription> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  String attachment,
      fileName = '',
      body = '',
      cc = '',
      subject = '',
      toEmail = '';
  File file;

  //
  // final _recipientController = TextEditingController();
  // final _ccController = TextEditingController();
  //
  // final _subjectController = TextEditingController();
  //
  // final _bodyController = TextEditingController(
  //   text: 'Mail body.',
  // );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: appBarColor,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Send Prescription',
          style: styleAppbarTitle,
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    return Container(
      color: Colors.white,
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.hospital.name,
                style: const TextStyle(
                    color: Colors.black,
                    fontFamily: fontMontserrat,
                    fontWeight: FontWeight.bold)),
            const Divider(
              color: Colors.grey,
            ),
            Row(
              children: [
                const Text('TO:',
                    style: TextStyle(
                        color: Colors.black, fontFamily: fontMontserrat)),
                Expanded(
                  child: TextFormField(
                    // controller: _recipientController,
                    onChanged: (value) => toEmail = value,
                    decoration: const InputDecoration(fillColor: Colors.white),
                    initialValue: widget.hospital.email,
                    style: const TextStyle(
                        color: Colors.black, fontFamily: fontMontserrat),
                  ),
                ),
              ],
            ),
            const Divider(
              color: Colors.grey,
            ),
            Row(
              children: [
                const Text(
                  'CC:',
                  style: TextStyle(
                      color: Colors.black, fontFamily: fontMontserrat),
                ),
                Expanded(
                  child: TextFormField(
                    // controller: _ccController,
                    onChanged: (value) => cc = value,
                    decoration: const InputDecoration(fillColor: Colors.white),
                    style: const TextStyle(
                        color: Colors.black, fontFamily: fontMontserrat),
                  ),
                ),
              ],
            ),
            const Divider(
              color: Colors.grey,
            ),
            Row(
              children: [
                const Text(
                  'Subject:',
                  style: TextStyle(
                      color: Colors.black, fontFamily: fontMontserrat),
                ),
                Expanded(
                  child: TextFormField(
                    // controller: _subjectController,
                    onChanged: (value) => subject = value,
                    decoration: const InputDecoration(fillColor: Colors.white),
                    style: const TextStyle(
                        color: Colors.black, fontFamily: fontMontserrat),
                  ),
                ),
              ],
            ),
            const Divider(
              color: Colors.grey,
            ),
            InkWell(
              onTap: () async {
                file = await FilePicker.getFile();
                attachment = file.path;
                fileName = file.path.split('/').last;
                setState(() {});
              },
              child: Row(
                children: [
                  Icon(Icons.attachment),
                  SizedBox(
                    width: 6,
                  ),
                  Text(
                    fileName ?? '',
                    style: TextStyle(
                        color: Colors.black, fontFamily: fontMontserrat),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 6,
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 200,
              decoration: const BoxDecoration(
                  border: Border(
                left: BorderSide(color: Colors.grey),
                right: BorderSide(color: Colors.grey),
                top: BorderSide(color: Colors.brown),
                bottom: BorderSide(color: Colors.brown),
              )),
              child: TextFormField(
                keyboardType: TextInputType.text,
                onChanged: (value) => body = value,
                maxLines: null,
                style: const TextStyle(
                    color: Colors.black54, fontFamily: fontMontserrat),
                decoration: const InputDecoration(
                  hintStyle: TextStyle(
                      color: Colors.black, fontFamily: fontMontserrat),
                  fillColor: Colors.white,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20),
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                height: 40,
                child: RaisedButton(
                  color: appBarColor,
                  onPressed: () {
                    // _confirmationDialog();
                    send();
                  },
                  child: Text(
                    'Send Prescription'.toUpperCase(),
                    style: const TextStyle(
                        color: Colors.white, fontFamily: fontMontserrat),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmationDialog() async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          content: const SingleChildScrollView(
            child: Center(
              child: Text(
                'The prescription was successfully send to the pharmacy',
                textAlign: TextAlign.center,
              ),
            ),
          ),
          actions: <Widget>[
            FlatButton(
              child: const Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> send() async {
    toEmail = toEmail.isNotEmpty ? toEmail : widget.hospital.email;
    final Email email = Email(
      body: body,
      subject: subject,
      recipients: [toEmail],
      cc: [cc],
      attachmentPaths: attachment != null ? [attachment] : [],
    );

    String platformResponse;

    try {
      await FlutterEmailSender.send(email);
      platformResponse = 'success';
    } catch (error) {
      platformResponse = error.toString();
    }

    if (!mounted) return;

    _scaffoldKey.currentState.showSnackBar(SnackBar(
      content: Text(platformResponse),
    ));
  }
}
