import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/hospitalModel.dart';
import 'package:medivic/screens/doctorsAccountScreens/prescription/selectPharmacy.dart';
import 'package:medivic/screens/gooogleMap/googleMap.dart';
import 'package:medivic/services/api/firestoreService.dart';

class FindPharmacy extends StatefulWidget {
  @override
  _FindPharmacyState createState() => _FindPharmacyState();
}

class _FindPharmacyState extends State<FindPharmacy> {
  List<Hospital> _hospitalList = [];
  List<Hospital> _searchHospitalList = [];
  String searchTxt;
  bool _isLoading = false;

  void _searchByName() async {
    if (searchTxt == null || searchTxt.isEmpty) {
      return;
    }
    setState(() {
      _isLoading = true;
    });

    LocatorService.searchProvider().getHospitals(searchTxt).then((value) {
      if (value != null && value.isNotEmpty) {
        _searchHospitalList = value;
      }
      setState(() {
        _isLoading = false;
      });
    });
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Find Pharmacy',
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Search pharmacy by name',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: fontMontserrat),
            ),
            const SizedBox(
              height: 6,
            ),
            _buildSearchView(),
            const SizedBox(
              height: 10,
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              height: 50,
              child: RaisedButton(
                onPressed: () => _searchByName(),
                color: appBarColor,
                child: const Text(
                  'Find',
                  style: TextStyle(
                      color: Colors.white, fontFamily: fontMontserrat),
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const Text(
              'Results',
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: fontMontserrat),
            ),
            const SizedBox(
              height: 6,
            ),
            if (_isLoading)
              const Center(
                child: CircularProgressIndicator(
                  backgroundColor: appBarColor,
                ),
              )
            else
              _buildListView()
          ],
        ),
      ),
    );
  }

  Widget _buildSearchView() {
    return Row(
      children: [
        Expanded(
            child: TextFormField(
          onChanged: (value) => searchTxt = value,
          decoration: const InputDecoration(
              // labelText: 'Search pharmacy by keyword',
              border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.brown, width: 1))),
        )),
        // IconButton(
        //   icon: const Icon(Icons.my_location),
        //   onPressed: () {},
        // )
      ],
    );
  }

  Widget _buildListView() {
    return _searchHospitalList.isNotEmpty
        ? Expanded(
            child: ListView.builder(
              itemCount: _searchHospitalList.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => SelectPharmacy(
                      hospital: _searchHospitalList[index],
                    ),
                  )),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 6, horizontal: 4),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _searchHospitalList[index].name,
                                  style: const TextStyle(
                                      color: darkBlueColor,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: fontMontserrat),
                                ),
                                Text(
                                  _searchHospitalList[index].address.city,
                                  style: const TextStyle(
                                      color: Colors.black,
                                      fontSize: 14,
                                      fontFamily: fontMontserrat),
                                ),
                                Text(
                                  _searchHospitalList[index].address.street,
                                  style: const TextStyle(
                                      color: Colors.black,
                                      fontSize: 14,
                                      fontFamily: fontMontserrat),
                                ),
                              ],
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              double latitude = -25.9811147;
                              double longitude = 28.2391756;
                              Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => GoogleMapScreen(
                                  lat: latitude,
                                  lng: longitude,
                                  isLock: true,
                                ),
                              ));
                            },
                            child: Column(
                              children: [
                                const Icon(Icons.directions),
                                Text('Directions'.toUpperCase()),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          )
        : const Center(
            child: Text('No pharmacy found'),
          );
  }
}
