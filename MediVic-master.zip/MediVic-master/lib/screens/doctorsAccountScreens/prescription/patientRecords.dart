import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/extensions/date_extensions.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/appointment.dart';
import 'package:medivic/screens/doctorsAccountScreens/prescription/patientProfile.dart';

class PatientRecords extends StatefulWidget {
  @override
  _PatientRecordsState createState() => _PatientRecordsState();
}

class _PatientRecordsState extends State<PatientRecords> {
  List<Appointment> records = [];
  bool isLoading = false;

  @override
  void initState() {
    super.initState();

    getPatients();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: appBarColor,
        title: const Text(
          'Patient Records',
          style: styleAppbarTitle,
        ),
      ),
      body: buildBody(),
    );
  }

  Widget buildBody() {
    return Container(
        child: !isLoading
            ? records.isNotEmpty
                ? ListView.builder(
                    itemCount: records.length,
                    itemBuilder: (context, index) => buildRow(records[index]),
                  )
                : Center(
                    child: Text('You have no patient record',style: TextStyle(fontFamily: fontMontserrat),),
                  )
            : const Center(
                child: CircularProgressIndicator(
                  backgroundColor: appBarColor,
                ),
              ));
  }

  Widget buildRow(Appointment appointment) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              CachedNetworkImage(
                imageUrl: appointment.userImageUrl,
                imageBuilder: (context, imageProvider) => Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image: DecorationImage(
                          image: imageProvider, fit: BoxFit.cover)),
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      appointment.userName,
                      style: const TextStyle(
                          fontSize: 12,
                          fontFamily: fontMontserrat,
                          fontWeight: FontWeight.bold,
                          color: darkBlueColor),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(
                      'Last Consultation: ${appointment.date.formatFullDate()}',
                      style: const TextStyle(
                          fontSize: 12,
                          fontFamily: fontMontserrat,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    SizedBox(
                      height: 25,
                      child: RaisedButton(
                        color: appBarColor,
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => PatientProfileRecords(
                                  userId: appointment.userId,
                                ),
                              ));
                        },
                        child: const Text(
                          'View Records',
                          style: TextStyle(
                              fontFamily: fontMontserrat,
                              color: Colors.white,
                              fontSize: 10),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> getPatients() async {
    setState(() => isLoading = true);

    final QuerySnapshot querySnapshot = await Firestore.instance
        .collection(Appointment.COLLECTION_NAME)
        .where('doctorId',
            isEqualTo: LocatorService.doctorProvider().doctor.uid)
        .getDocuments();

    records = Appointment.parseList(querySnapshot.documents);

    setState(() => isLoading = false);
  }
}
