import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/models/documentModel.dart';
import 'package:medivic/models/userModel.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/utils/utils.dart';

class PatientProfileRecords extends StatefulWidget {
  final String userId;

  const PatientProfileRecords({Key key, this.userId}) : super(key: key);

  @override
  _PatientProfileState createState() => _PatientProfileState();
}

class _PatientProfileState extends State<PatientProfileRecords> {
  User user;
  List<Document> profileDocuments = [];
  List<Document> consultDocuments = [];
  bool isLoading = false;
  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    getOnlineData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: appBarColor,
        title: const Text(
          'Patient Records',
          style: styleAppbarTitle,
        ),
      ),
      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(
                backgroundColor: appBarColor,
              ),
            )
          : buildBody(),
    );
  }

  Widget buildBody() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            buildPatient(),
            const SizedBox(
              height: 10,
            ),
            const Text(
              'Profile Records',
              style: TextStyle(
                  fontFamily: fontMontserrat,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black),
            ),
            if (profileDocuments.isEmpty)
              const Text(
                'No file found!!',
                style:
                    TextStyle(fontFamily: fontMontserrat, color: Colors.grey),
              )
            else
              ListView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: profileDocuments.length,
                itemBuilder: (context, index) => Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: ListTile(
                    onTap: () async {
                      final bytes = await Utils.imageDownload(
                          profileDocuments[index].fileUrl);
                      _scaffoldKey.currentState.showSnackBar(SnackBar(
                        backgroundColor: Colors.white,
                        content: Image.memory(
                          bytes,
                          fit: BoxFit.fill,
                        ),
                      ));
                    },
                    leading: profileDocuments[index].fileUrl.contains('jpg') ||
                            profileDocuments[index].fileUrl.contains('png')||profileDocuments[index].fileUrl.contains('jpeg')
                        ? CachedNetworkImage(
                            width: 50,
                            height: 50,
                            imageUrl: profileDocuments[index].fileUrl,
                            placeholder: (context, url) =>
                                const CircularProgressIndicator(backgroundColor: appBarColor,),
                          )
                        : Image.asset(
                            'lib/assets/images/pdf.png',
                            width: 50,
                            height: 50,
                          ),
                    title: Text(
                      profileDocuments[index].fileName,
                      style: const TextStyle(fontFamily: fontMontserrat),
                    ),
                  ),
                ),
              ),
            const SizedBox(
              height: 10,
            ),
            RaisedButton(
              color: appBarColor,
              onPressed: () {},
              child: const Text(
                'Consultations',
                style:
                    TextStyle(color: Colors.white, fontFamily: fontMontserrat),
              ),
            ),
            if (profileDocuments.isEmpty)
              const Text(
                'No file found!!',
                style:
                    TextStyle(fontFamily: fontMontserrat, color: Colors.grey),
              ),
            ListView.builder(
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: consultDocuments.length,
              itemBuilder: (context, index) => Padding(
                padding: const EdgeInsets.all(5.0),
                child: ListTile(
                  title: Text(
                    consultDocuments[index].fileName,
                    style: const TextStyle(fontFamily: fontMontserrat),
                  ),
                  leading: Image.asset('assets/pdf.png'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildPatient() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            CachedNetworkImage(
              imageUrl: user.imageUrl,
              imageBuilder: (context, imageProvider) => Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                        image: imageProvider, fit: BoxFit.cover)),
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    user.name,
                    style: const TextStyle(
                        fontSize: 12,
                        fontFamily: fontMontserrat,
                        fontWeight: FontWeight.bold,
                        color: darkBlueColor),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Text(
                    'D.O.B: ${user.dob}',
                    style: const TextStyle(
                        fontSize: 12,
                        fontFamily: fontMontserrat,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Text(
                    'Address: ${user.address.address}',
                    style: const TextStyle(
                        fontSize: 12,
                        fontFamily: fontMontserrat,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void getOnlineData() async {
    isLoading = true;
    final userMap = await FirestoreService.getUserInfo(widget.userId);
    user = User.fromJson(userMap);
    if (user != null && user.docsVisibility) {
      profileDocuments = await FirestoreService.getDocuments(widget.userId);
      // consultPrescriptions = await FirestoreService.getPrescriptionsUser(widget.userId);
    }
    setState(() {
      isLoading = false;
    });
  }
}
