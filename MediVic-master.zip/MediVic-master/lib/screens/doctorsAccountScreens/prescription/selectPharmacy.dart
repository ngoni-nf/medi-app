import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/models/hospitalModel.dart';
import 'package:medivic/screens/doctorsAccountScreens/prescription/sendPrescription.dart';

class SelectPharmacy extends StatefulWidget {
  final Hospital hospital;

  const SelectPharmacy({Key key, this.hospital}) : super(key: key);

  @override
  _SelectPharmacyState createState() => _SelectPharmacyState();
}

class _SelectPharmacyState extends State<SelectPharmacy> {
  int _radioValue = 0;



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: appBarColor,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Select Pharmacy',
          style: styleAppbarTitle,
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
      width: MediaQuery.of(context).size.width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(
            height: 10,
          ),
          Text(
            widget.hospital.name,
            style: const TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontFamily: fontMontserrat),
          ),
          _buildCardView(),
          _buildRadio(),
          _buildButton()
        ],
      ),
    );
  }

  void _handleRadioValueChange(int value) {
    _radioValue = value;
    setState(() {});
  }

  Widget _buildButton() {
    return SizedBox(
      width: MediaQuery
          .of(context)
          .size
          .width,
      height: 50,
      child: RaisedButton(
        color: appBarColor,
        onPressed: () {
          Navigator.of(context).push(MaterialPageRoute(builder: (context) =>
              SendPrescription(hospital: widget.hospital,),));
        },
        child: const Text(
          'Email Prescription',
          style: TextStyle(color: Colors.white, fontFamily: fontMontserrat),
        ),
      ),
    );
  }

  Widget _buildRadio() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Row(
          children: [
            Radio(
              value: 1,
              groupValue: _radioValue,
              onChanged: _handleRadioValueChange,
            ),
            const Text(
              'Customer to collect from pharmacy',
              style: TextStyle(color: Colors.black, fontFamily: fontMontserrat),
            ),
          ],
        ),
        Row(
          children: [
            Radio(
              value: 2,
              groupValue: _radioValue,
              onChanged: _handleRadioValueChange,
            ),
            const Text(
              'Deliver to customer',
              style: TextStyle(color: Colors.black, fontFamily: fontMontserrat),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildCardView() {
    return Container(
      width: MediaQuery
          .of(context)
          .size
          .width,
      child: Card(
        elevation: 3,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${widget.hospital.address.street},${widget.hospital.address
                    .state},${widget.hospital.address.city},${widget.hospital
                    .address.country},${widget.hospital.address.pin}',
                style: const TextStyle(
                    color: Colors.black, fontFamily: fontMontserrat),
              ),
              Text(
                widget.hospital.phoneNumber,
                style: const TextStyle(
                    color: Colors.black, fontFamily: fontMontserrat),
              ),
              Text(
                widget.hospital.specialities[0],
                style: const TextStyle(
                    color: Colors.black, fontFamily: fontMontserrat),
              ),
              Text(
                widget.hospital.email,
                style: const TextStyle(
                    color: Colors.black, fontFamily: fontMontserrat),
              ),
              const SizedBox(
                height: 20,
              ),
              Text(
                'Operating Hours'.toUpperCase(),
                style: const TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontFamily: fontMontserrat),
              ),
              const Text(
                'Monday - Friday: 08:00 - 18:00',
                style: TextStyle(
                    color: Colors.black, fontFamily: fontMontserrat),
              ),
              const Text(
                'Friday: 08:00 - 18:00',
                style: TextStyle(
                    color: Colors.black, fontFamily: fontMontserrat),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
