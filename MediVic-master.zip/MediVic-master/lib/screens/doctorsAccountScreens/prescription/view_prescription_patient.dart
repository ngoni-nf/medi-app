import 'package:advance_pdf_viewer/advance_pdf_viewer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/prescriptionNew.dart';
import 'package:medivic/screens/doctorsAccountScreens/prescription/add_prescription.dart';
import 'package:medivic/services/api/firebaseStorageService.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/utils/utils.dart';
import 'package:collection/collection.dart';

class ViewPrescriptionPatient extends StatefulWidget {
  @override
  _ViewPrescriptionState createState() => _ViewPrescriptionState();
}

class _ViewPrescriptionState extends State<ViewPrescriptionPatient> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
          key: _scaffoldKey,
          appBar: AppBar(
            iconTheme: const IconThemeData(color: Colors.white),
            backgroundColor: appBarColor,
            title: const Text(
              'View Prescriptions',
              style: styleAppbarTitle,
            ),
            bottom: const TabBar(
              tabs: [
                Tab(
                  text: 'Uploaded by me',
                ),
                Tab(
                  text: 'Sent to me',
                )
              ],
            ),
          ),
          body: TabBarView(
            children: [
              FutureBuilder(
                future: FirestoreService.getPrescriptions(
                    LocatorService.userProvider().userId, true),
                builder: (BuildContext context,
                    AsyncSnapshot<List<PrescriptionNew>> snapshot) {
                  if (snapshot.hasData) {
                    if (snapshot.data.isNotEmpty)
                      return _buildNameList(snapshot.data, true);
                    else
                      return const Center(
                        child: Text(
                          'No prescription found',
                          style: TextStyle(fontFamily: fontMontserrat),
                        ),
                      );
                  }

                  return const Center(
                      child: CircularProgressIndicator(
                          backgroundColor: appBarColor));
                },
              ),
              FutureBuilder(
                future: FirestoreService.getPrescriptions(
                    LocatorService.userProvider().userId, false),
                builder: (BuildContext context,
                    AsyncSnapshot<List<PrescriptionNew>> snapshot) {
                  if (snapshot.hasData) {
                    if (snapshot.data.isNotEmpty)
                      return _buildNameList(snapshot.data, false);
                    else
                      return const Center(
                        child: Text(
                          'No prescription found',
                          style: TextStyle(fontFamily: fontMontserrat),
                        ),
                      );
                  }

                  return const Center(
                      child: CircularProgressIndicator(
                          backgroundColor: appBarColor));
                },
              ),
            ],
          )),
    );
  }

  Widget _buildNameList(List<PrescriptionNew> prescriptions, bool isEditable) {
    final Map<String, List<PrescriptionNew>> data =
        groupBy(prescriptions, (PrescriptionNew obj) => obj.doctorName);

    return ListView.builder(
      itemCount: data.keys.length,
      itemBuilder: (context, index) => Card(
        color: Colors.grey[200],
        child: ListTile(
          onTap: () {
            // _buildList(data.values.elementAt(index));
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PrescriptionList(
                    prescriptions: data.values.elementAt(index),
                    isEditable: isEditable,
                  ),
                ));
          },
          title: Text(data.keys.elementAt(index)),
          leading: leading(data.keys.elementAt(index)),
        ),
      ),
    );
  }

  Widget leading(String name) {
    if (name == null || name.length < 2) {
      name = 'No Name';
    }
    return CircleAvatar(
      maxRadius: 25,
      child: Text(
        name.substring(0, 1).toUpperCase(),
        style: const TextStyle(
            fontFamily: fontMontserrat,
            fontSize: 20,
            fontWeight: FontWeight.bold),
      ),
      backgroundColor: darkBlueColor,
    );
  }
}

class PrescriptionList extends StatefulWidget {
  final List<PrescriptionNew> prescriptions;
  final bool isEditable;

  const PrescriptionList({Key key, this.prescriptions, this.isEditable = false})
      : super(key: key);
  @override
  _PrescriptionListState createState() => _PrescriptionListState();
}

class _PrescriptionListState extends State<PrescriptionList> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  Widget _buildImageOrPDF(String fileUrl) {
    return InkWell(
      onTap: () => fileUrl.contains('pdf')
          ? _pdfDownload(fileUrl)
          : _imageDownload(fileUrl),
      child: fileUrl.contains('pdf')
          ? Image.asset(
              'assets/pdf.png',
              width: 50,
              height: 50,
            )
          : CachedNetworkImage(
              imageUrl: fileUrl,
              width: 50,
              height: 50,
              placeholder: (context, url) => const Center(
                child: CircularProgressIndicator(
                  backgroundColor: appBarColor,
                ),
              ),
            ),
    );
  }

  void _pdfDownload(String fileUrl) async {
    Fluttertoast.showToast(msg: 'PDF file is downloading');
    final doc = await PDFDocument.fromURL(fileUrl);
    print('download completed ${doc.count}');
    _scaffoldKey.currentState.showSnackBar(SnackBar(
      backgroundColor: Colors.white,
      duration: const Duration(hours: 1),
      content: PDFViewer(document: doc),
    ));
  }

  void _imageDownload(String url) async {
    final bodyBytes = await FirebaseStorageService.imageDownload(url);
    _scaffoldKey.currentState.showSnackBar(SnackBar(
      backgroundColor: Colors.white,
      content: Image.memory(
        bodyBytes,
        fit: BoxFit.fill,
      ),
    ));
  }

  Widget _buildList(List<PrescriptionNew> prescriptions) {
    return ListView.builder(
      itemCount: prescriptions.length,
      itemBuilder: (context, index) {
        final PrescriptionNew prescription = prescriptions[index];
        return InkWell(
          onTap: () {
            if (widget.isEditable)
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AddPrescription(
                      prescription: prescription,
                    ),
                  ));
          },
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            child: Padding(
              padding: const EdgeInsets.all(14.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    prescription.patientName,
                    style: const TextStyle(
                        fontFamily: fontMontserrat,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Text(
                    prescription.note,
                    style: const TextStyle(fontFamily: fontMontserrat),
                    maxLines: 2,
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        Utils.getDateStr(prescription.createdAt),
                        style: const TextStyle(
                            fontFamily: fontMontserrat, fontSize: 12),
                      ),
                      Text(
                        Utils.getTimeStr(prescription.createdAt),
                        style: const TextStyle(
                            fontFamily: fontMontserrat, fontSize: 10),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (prescription.imageUrl != null)
                        _buildImageOrPDF(prescription.imageUrl),
                      if (prescription.fileUrl != null)
                        _buildImageOrPDF(prescription.fileUrl),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: appBarColor,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          widget.prescriptions.isNotEmpty
              ? widget.prescriptions[0].patientName
              : 'Prescriptions',
          style: styleAppbarTitle,
        ),
      ),
      key: _scaffoldKey,
      body: _buildList(widget.prescriptions),
    );
  }
}
