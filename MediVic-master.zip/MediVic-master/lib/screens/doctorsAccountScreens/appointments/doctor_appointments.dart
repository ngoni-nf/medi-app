// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/extensions/date_extensions.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/appointment.dart';
import 'package:medivic/models/appointment_status.dart';
import 'package:medivic/models/note.dart';
import 'package:medivic/models/notification.dart';
import 'package:medivic/models/prescriptionNew.dart';
import 'package:medivic/screens/call/agora/video_call.dart';
import 'package:medivic/screens/call/sessionConfirmation/session_confirmation.dart';
import 'package:medivic/screens/doctorsAccountScreens/add_note.dart';
import 'package:medivic/screens/doctorsAccountScreens/homeDoctor/drawerDoctor.dart';
import 'package:medivic/screens/doctorsAccountScreens/prescription/add_prescription.dart';
import 'package:medivic/screens/notification/notification.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/shared/customButton.dart';

class DoctorAppointmentListScreen extends StatefulWidget {
  const DoctorAppointmentListScreen(
      {this.withAppBar = true, this.title, Key key})
      : super(key: key);

  final bool withAppBar;
  final String title;

  @override
  _DoctorAppointmentListScreenState createState() =>
      _DoctorAppointmentListScreenState();
}

class _DoctorAppointmentListScreenState
    extends State<DoctorAppointmentListScreen> {
  int selected = 0;
  bool loading;
  List<Appointment> appointments = [];
  final TextEditingController _textEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.withAppBar) {
      return Scaffold(
        appBar: _buildAppBar(),
        body: _buildBody(),
        endDrawer: SafeArea(child: DrawerDoctor()),
      );
    } else {
      return _buildBody();
    }
  }

  AppBar _buildAppBar() {
    return AppBar(
      title: Text(widget.title ?? AppStrings.appointmentsTitle,
          style: styleAppbarTitle),
      backgroundColor: appBarColor,
      leading: IconButton(
          icon: const Icon(
            Icons.notifications,
            color: Colors.white,
            size: 30,
          ),
          onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => NotificationScreen(),
              ))),
      iconTheme: const IconThemeData(color: Colors.white),
    );
  }

  Widget _buildBody() {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              AppStrings.appointmentsTitle,
              style: TextStyle(
                fontFamily: fontMontserrat,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ),
          const SizedBox(height: 10),
          _buildSelectionSide(),
          const SizedBox(height: 10),
          if (loading)
            const Expanded(
              child: Center(
                  child:
                      CircularProgressIndicator(backgroundColor: appBarColor)),
            )
          else
            _buildAppointmentListView(),
        ],
      ),
    );
  }

  Widget _buildAppointmentListView() {
    // for notification
    if (selected == 0) {
      return Expanded(child: _buildNotification());
    }

    final List<Appointment> filteredAppointments = _filterAppointments();
    return Expanded(
      child: filteredAppointments.isNotEmpty
          ? ListView.builder(
              itemCount: filteredAppointments.length,
              itemBuilder: (context, index) {
                return _buildAppointmentListItem(filteredAppointments[index]);
              },
            )
          : Center(
              child: Text(
                getNoSessionsMsg(),
                style: const TextStyle(fontFamily: fontMontserrat),
              ),
            ),
    );
  }

  String getNoSessionsMsg() {
    if (selected == 1)
      return 'You have no upcoming sessions.';
    else if (selected == 2) {
      return 'You have no completed sessions.';
    }
    return 'You have no notifications';
  }

  Widget _buildAppointmentListItem(Appointment appointment) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ClipOval(
              child: CachedNetworkImage(
                imageUrl: appointment.userImageUrl ??
                    'https://via.placeholder.com/100',
                width: 64,
                height: 64,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    appointment.userName,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        fontFamily: fontMontserrat),
                  ),
                  Text('Date : ${appointment.date.formatFullDate()}',
                      style: const TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                          fontFamily: fontMontserrat)),
                  Text('Time : ${appointment.getInterval()}',
                      style: const TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                          fontFamily: fontMontserrat)),
                  _buildControls(appointment),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildControls(Appointment appointment) {
    final List<Widget> controls = [];
    if (selected == 2) {
      controls.add(AppButton(
        text: 'Add Prescription',
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AddPrescription(
              prescription: PrescriptionNew(
                  fromId: appointment.doctorId,
                  toId: appointment.userId,
                  doctorName: appointment.doctorName,
                  patientName: appointment.userName),
            ),
          ),
        ),
        bgColor: appBarColor,
        fontSize: 10,
      ));
      controls.add(AppButton(
        text: 'Add Note',
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AddNote(
              note: Note(
                doctorId: appointment.doctorId,
                patientId: appointment.userId,
                patientName: appointment.userName,
              ),
            ),
          ),
        ),
        bgColor: appBarColor,
        fontSize: 10,
      ));
      if (!appointment.sessionConfirmed) {
        controls.add(AppButton(
          text: AppStrings.sessionConfirmationTitle,
          onPressed: () => _showSessionConfirmationDialog(context, appointment),
          bgColor: appBarColor,
          fontSize: 10,
        ));
      }
    } else if (selected == 1) {
      if (!appointment.sessionConfirmed) {
        controls.add(
          AppButton(
            text: 'Initiate',
            // onPressed: () => VonageVideoCall.start(context, appointment),
            onPressed: () => VideoCallScreen.start(context, appointment),
            bgColor: appBarColor,
            fontSize: 10,
          ),
        );
      }
      if (appointment.isReschedulable()) {
        controls.add(
          AppButton(
            fontSize: 10,
            text: AppStrings.reschedule,
            bgColor: darkBlueColor,
            onPressed: () =>
                showRescheduleConfirmationDialog(context, appointment)
                    .then((value) {
              if (value != null) {
                _rescheduleAppointment(appointment, value);
              }
            }),
          ),
        );
      }
    }
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      direction: Axis.horizontal,
      children: controls,
    );
  }

  Widget _buildSelectionSide() {
    return Center(
      child: Container(
        height: 45,
        width: MediaQuery.of(context).size.width * 0.85,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(32),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.3),
              spreadRadius: 5,
              blurRadius: 7,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              flex: 1,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(32),
                child: Container(
                  height: 45,
                  child: RaisedButton(
                    onPressed: () => setState(() => selected = 0),
                    color: selected == 0 ? darkBlueColor : Colors.white,
                    child: Text(
                      AppStrings.notifications,
                      style: TextStyle(
                          color: selected == 0 ? Colors.white : Colors.grey,
                          fontFamily: fontMontserrat),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              flex: 1,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(32),
                child: Container(
                  height: 45,
                  child: RaisedButton(
                    onPressed: () => setState(() => selected = 1),
                    color: selected == 1 ? darkBlueColor : Colors.white,
                    child: Text(
                      AppStrings.upComing,
                      style: TextStyle(
                          color: selected == 1 ? Colors.white : Colors.grey,
                          fontFamily: fontMontserrat),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              flex: 1,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(32),
                child: Container(
                  height: 45,
                  child: RaisedButton(
                    onPressed: () => setState(() => selected = 2),
                    color: selected == 2 ? darkBlueColor : Colors.white,
                    child: Text(
                      AppStrings.completed,
                      style: TextStyle(
                          color: selected == 2 ? Colors.white : Colors.grey,
                          fontFamily: fontMontserrat),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSessionConfirmationDialog(
      BuildContext context, Appointment appointment) {
    SessionConfirmation.showSessionConfirmationDialog(
      context,
      appointment.id,
      appointment.sessionConfirmed,
      true,
    ).then((value) {
      if (value != null && value) {
        _fetchAppointments();
      }
    });
  }

  void _fetchAppointments() {
    setState(() => loading = true);
    FirestoreService.getAppointmentsForDoctor(
            LocatorService.doctorProvider().doctor.uid)
        .then((value) => setState(() {
              appointments = value;
              loading = false;
            }))
        .catchError((err) {
      if (mounted) {
        setState(() => loading = false);
      }
    });
  }

  Future<String> showRescheduleConfirmationDialog(
    BuildContext context,
    Appointment appointment,
  ) {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                  'Are you sure you want to request the patient to reschedule?'),
              const SizedBox(height: 16),
              TextField(
                decoration:
                    const InputDecoration(hintText: 'Reason to Reschedule'),
                keyboardType: TextInputType.multiline,
                maxLines: 6,
                controller: _textEditingController,
              )
            ],
          ),
          actions: [
            FlatButton(
              child: const Text('Request to reschedule'),
              onPressed: () {
                if (_textEditingController.text.isNotEmpty) {
                  Navigator.of(context).pop(_textEditingController.text);
                } else {
                  Fluttertoast.showToast(
                      msg: 'Please provide reason for reschedule.');
                }
              },
            ),
            FlatButton(
              child: const Text('Close'),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        );
      },
    );
  }

  Future<void> _rescheduleAppointment(
      Appointment appointment, String cancellationReason) async {
    try {
      setState(() => loading = true);
      await Firestore.instance
          .collection(Appointment.COLLECTION_NAME)
          .document(appointment.id)
          .updateData({
        'status': AppointmentStatus.CANCELLED,
        'cancelledByPatient': false,
        'cancellationReason': cancellationReason
      });
      _fetchAppointments();
    } catch (e) {
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
      setState(() => loading = false);
    }
  }

  List<Appointment> _filterAppointments() {
    return appointments
        .where((element) =>
            element.status != AppointmentStatus.CANCELLED &&
            ((selected == 1 && !element.sessionEnded()) ||
                (selected == 2 && element.sessionEnded())))
        .toList();
  }

  /// notification part

  Widget _buildNotification() {
    final String userId = LocatorService.userProvider().user?.uid ??
        LocatorService.doctorProvider().doctor.uid;
    final bool isPatient = LocatorService.userProvider().user != null;
    return StreamBuilder<QuerySnapshot>(
        stream: Firestore.instance
            .collection('notifications')
            .where('userId', isEqualTo: userId)
            .where('isPatient', isEqualTo: isPatient)
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          final List<InAppNotification> notifications =
              InAppNotification.parseList(snapshot);
          return notifications.isNotEmpty
              ? _buildListView(notifications)
              : _buildNoNotificationsLabel();
        });
  }

  Widget _buildListView(List<InAppNotification> notifications) {
    return ListView.builder(
        itemCount: notifications.length,
        itemBuilder: (context, index) => NotificationContainer(
              notifications[index],
              isClickable: false,
            ));
  }

  Widget _buildNoNotificationsLabel() {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Text(
          'You currently have no new notifications.',
          style: TextStyle(fontFamily: fontMontserrat),
        ),
      ),
    );
  }
}
