// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/providers/doctorProvider.dart';
import 'package:medivic/screens/doctorsAccountScreens/appointments/doctor_appointments.dart';
import 'package:medivic/screens/notification/notification.dart';
import 'package:medivic/shared/specialityContainer.dart';
import 'package:medivic/themes/themeGuide.dart';
import 'package:provider/provider.dart';

import 'drawerDoctor.dart';

class HomeDoctor extends StatefulWidget {
  const HomeDoctor({Key key}) : super(key: key);

  @override
  _HomeDoctorState createState() => _HomeDoctorState();
}

class _HomeDoctorState extends State<HomeDoctor> {
  int selected = 0;

  @override
  void initState() {
    super.initState();
    LocatorService.inActivityTimer().resetTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: appBarColor,
        title: Text(
          'Welcome ${LocatorService.doctorProvider().doctor.name}',
          style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w400,
              fontFamily: fontMontserrat),
          maxLines: 2,
        ),
        titleSpacing: -10,
        leading: IconButton(
            icon: const Icon(
              Icons.notifications,
              color: Colors.white,
              size: 30,
            ),
            onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => NotificationScreen(),
                ))),
      ),
      endDrawer: SafeArea(child: DrawerDoctor()),
      body: const DoctorAppointmentListScreen(withAppBar: false),
    );
  }

  // void reschedule(OnlineAppointment appointment) {
  //   showDialog(
  //     context: context,
  //     builder: (context) => AlertDialog(
  //       backgroundColor: Colors.white,
  //       title: const Text(
  //         'Appointment Cancel',
  //         style: TextStyle(fontFamily: fontMontserrat),
  //       ),
  //       content: Container(
  //         height: 150,
  //         child: Column(
  //           children: [
  //             TextFormField(
  //               initialValue:
  //                   'Dear ${appointment.name}. Due to unforseen circumstances, I am unable to attend our booked session. Please rebook your next convenient slot in the system. Kind regards, Dr ${LocatorService.doctorProvider().doctor.name}',
  //               maxLines: 6,
  //               style: const TextStyle(
  //                 fontFamily: fontMontserrat,
  //                 fontSize: 12,
  //               ),
  //             ),
  //           ],
  //         ),
  //       ),
  //       actions: [
  //         FlatButton(
  //           onPressed: () {
  //             Navigator.pop(context);
  //             cancelAppointment(appointment);
  //           },
  //           child: const Text(
  //             'Cancel Appointment',
  //             style: TextStyle(fontFamily: fontMontserrat, color: darkBlueColor),
  //           ),
  //         ),
  //         FlatButton(
  //           onPressed: () => Navigator.of(context).pop(),
  //           child: const Text(
  //             'Close',
  //             style: TextStyle(fontFamily: fontMontserrat, color: darkBlueColor),
  //           ),
  //         ),
  //       ],
  //     ),
  //   );
  // }
  //
  // void cancelAppointment(OnlineAppointment appointment) async {
  //   await FirestoreService.cancelAppointment(appointment.docId);
  //   setState(() {
  //     // appointments.remove(appointment);
  //   });
  //
  //   Fluttertoast.showToast(msg: 'Appointment canceled successfully');
  // }

  Widget selectionSide() {
    return Container(
      height: 45,
      width: MediaQuery.of(context).size.width * 0.85,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(32),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 5,
            blurRadius: 7,
            offset: Offset(0, 3), // changes position of shadow
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(32),
              child: Container(
                height: 45,
                child: RaisedButton(
                  onPressed: () {
                    setState(() {
                      selected = 0;
                    });
                  },
                  color: selected == 0 ? darkBlueColor : Colors.white,
                  child: Text(
                    AppStrings.nothing,
                    style: TextStyle(
                        color: selected == 0 ? Colors.white : Colors.grey,
                        fontFamily: fontMontserrat),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(32),
              child: Container(
                height: 45,
                child: RaisedButton(
                  onPressed: () {
                    setState(() {
                      selected = 1;
                    });
                  },
                  color: selected == 1 ? darkBlueColor : Colors.white,
                  child: Text(
                    AppStrings.upComing,
                    style: TextStyle(
                        color: selected == 1 ? Colors.white : Colors.grey,
                        fontFamily: fontMontserrat),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(32),
              child: Container(
                height: 45,
                child: RaisedButton(
                  onPressed: () {
                    setState(() {
                      selected = 2;
                    });
                  },
                  color: selected == 2 ? darkBlueColor : Colors.white,
                  child: Text(
                    AppStrings.completed,
                    style: TextStyle(
                        color: selected == 1 ? Colors.white : Colors.grey,
                        fontFamily: fontMontserrat),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class HomeDoctorHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(16.0),
      margin: const EdgeInsets.all(10),
      child: Consumer<DoctorProvider>(
        builder: (context, data, _) {
          final d = data.doctor;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(10.0),
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  borderRadius: ThemeGuide.borderRadius16,
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: CachedNetworkImageProvider(
                      d.imageUrl ?? 'https://via.placeholder.com/100',
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Text(
                '${AppStrings.dr} ' + d.name,
                style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 20.0,
                    fontFamily: fontMontserrat),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 4,
                runSpacing: 4,
                children: renderSpecialities(d.specialities),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: 20,
                ),
                decoration: const BoxDecoration(
                  borderRadius: ThemeGuide.borderRadius,
                  color: Color.fromRGBO(230, 230, 230, 1),
                ),
                child: Wrap(
                  children: <Widget>[
                    Text(
                      '${Config.CURRENCY_SYMBOL.isNotEmpty ? Config.CURRENCY_SYMBOL : Config.CURRENCY} ',
                      style: _theme.textTheme.subtitle1.copyWith(
                        color: Colors.black38,
                        fontWeight: FontWeight.w600,
                        fontFamily: fontMontserrat,
                      ),
                    ),
                    Text(
                      d.fee ?? AppStrings.notProvided,
                      style: _theme.textTheme.subtitle1.copyWith(
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                        fontFamily: fontMontserrat,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: 20,
                ),
                decoration: const BoxDecoration(
                  borderRadius: ThemeGuide.borderRadius,
                  color: Color.fromRGBO(230, 230, 230, 1),
                ),
                child: DefaultTextStyle(
                  style: _theme.textTheme.bodyText1.copyWith(
                      color: Colors.black87, fontFamily: fontMontserrat),
                  child: Wrap(
                    runSpacing: 4,
                    spacing: 4,
                    children: <Widget>[
                      Text(
                        d.address.street,
                        style: const TextStyle(fontFamily: fontMontserrat),
                      ),
                      Text(
                        d.address.city,
                        style: const TextStyle(fontFamily: fontMontserrat),
                      ),
                      Text(
                        d.address.state,
                        style: const TextStyle(fontFamily: fontMontserrat),
                      ),
                      Text(
                        d.address.country,
                        style: const TextStyle(fontFamily: fontMontserrat),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(
                  vertical: 8,
                  horizontal: 20,
                ),
                decoration: const BoxDecoration(
                  borderRadius: ThemeGuide.borderRadius,
                  color: Color.fromRGBO(230, 230, 230, 1),
                ),
                child: Wrap(
                  children: <Widget>[
                    Text(
                      AppStrings.exp + ' ',
                      style: _theme.textTheme.subtitle1.copyWith(
                        color: Colors.black38,
                        fontWeight: FontWeight.w600,
                        fontFamily: fontMontserrat,
                      ),
                    ),
                    Text(
                      d.experience + ' ' + AppStrings.yr,
                      style: _theme.textTheme.subtitle1.copyWith(
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                        fontFamily: fontMontserrat,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<Widget> renderSpecialities(List<String> specialities) {
    final ar = specialities ?? [];
    if (ar.isEmpty) {
      return [
        const SpecialityContainer.small(speciality: AppStrings.notProvided),
      ];
    }
    return ar.map((speciality) {
      return SpecialityContainer.small(speciality: speciality);
    }).toList();
  }
}
