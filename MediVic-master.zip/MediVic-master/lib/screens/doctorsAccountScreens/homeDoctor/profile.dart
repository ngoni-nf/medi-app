// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/routes/router.gr.dart';
import 'package:medivic/screens/doctorsAccountScreens/homeDoctor/drawerDoctor.dart';
import 'package:medivic/screens/doctorsAccountScreens/prescription/view_prescription.dart';
import 'package:medivic/screens/notification/notification.dart';

///
/// ## `Description`
///
/// Screen to render Account info of the user.
/// Will work well when used with `username` or `id`
/// for the network request.
///
class DoctorProfileScreen extends StatelessWidget {
  const DoctorProfileScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          AppStrings.accountInfo,
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
        leading: IconButton(
          icon: const Icon(Icons.notifications, color: Colors.white, size: 30.0),
          onPressed: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => NotificationScreen(),
                ));
          },
        ),
      ),
      endDrawer: DrawerDoctor(),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        color: Colors.white,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Center(
                child: Column(
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.all(10.0),
                      width: 250,
                      height: 250,
                      child: CircleAvatar(
                        backgroundColor: Colors.black12,
                        backgroundImage: CachedNetworkImageProvider(LocatorService.doctorProvider().doctor.imageUrl),
                      ),
                    ),
                    Text(
                      LocatorService.doctorProvider().doctor.name,
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 20.0, fontFamily: fontMontserrat),
                    ),
                    Text(
                      LocatorService.doctorProvider().doctor.email,
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14.0, color: Colors.black38, fontFamily: fontMontserrat),
                    ),
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 20, bottom: 10),
                child: Divider(
                  color: Colors.black12,
                  height: 2.0,
                  thickness: 1.5,
                  indent: 20,
                  endIndent: 20,
                ),
              ),
              buildListTile(
                title: AppStrings.editProfile,
                onTap: () => NavigationController.navigator.pushNamed(Routes.editProfileDoctor),
              ),
              buildListTile(
                title: AppStrings.appointmentsTitle,
                onTap: () => NavigationController.navigator.pushNamed(Routes.appointments),
              ),
              buildListTile(
                title: AppStrings.medicineCourse,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => ViewPrescription())),
              ),
              // buildListTile(
              //   title: AppStrings.savedBlogs,
              //   onTap: () => NavigationController.navigator.pushNamed(Routes.savedBlogs),
              // ),
            ],
          ),
        ),
      ),
    );
  }

  ///
  /// ## `Description`
  ///
  /// Function that returns the list tile for the various options
  /// provided to the user.
  ///
  ListTile buildListTile({@required String title, Function onTap}) {
    return ListTile(
      onTap: () => onTap(),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      trailing: const Icon(
        Icons.arrow_forward_ios,
        size: 16,
        color: Colors.black,
      ),
      title: Text(
        title ?? '',
        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w500, fontFamily: fontMontserrat),
      ),
    );
  }
}
