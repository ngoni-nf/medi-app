// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/screens/doctorsAccountScreens/signupDoctor/form/signupDoctorForm.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class SignupDoctor extends StatelessWidget {
  final String doctorId;
  final String phoneNumber;
  final String email;
  const SignupDoctor({Key key, this.doctorId, this.phoneNumber, this.email})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 30),
        physics: const BouncingScrollPhysics(),
        children: <Widget>[
          SizedBox(
            height: MediaQuery.of(context).size.height / 12,
          ),
          const Center(
            child: Text(
              AppStrings.signup,
              style: TextStyle(
                color: darkBlueColor,
                fontSize: 30.0,
                fontFamily: fontMontserrat,
              ),
            ),
          ),
          Center(
              child: SvgPicture.asset(
            'lib/assets/svg/cardiogram.svg',
            width: 200,
            height: 200,
          )),
          const SizedBox(
            height: 30,
          ),
          SignupDoctorForm(
            doctorId: doctorId,
            phoneNumber: phoneNumber,
            email: email,
            isAuth: email != null || phoneNumber != null,
          ),
          const SizedBox(
            height: 20,
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const Text(
                AppStrings.signUpQues,
                style: TextStyle(
                  color: Colors.black26,
                  fontFamily: fontMontserrat,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: InkWell(
                  onTap: () => NavigationController.navigator
                      .pushReplacementNamed(Routes.loginDoctor),
                  highlightColor: Colors.transparent,
                  child: Text(
                    AppStrings.loginAsDoctor,
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                      fontFamily: fontMontserrat,
                      color: appBarColor,
                    ),
                  ),
                ),
              )
            ],
          ),
          const SizedBox(height: 100),
        ],
      ),
    );
  }
}
