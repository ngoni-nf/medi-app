// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:developer';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/authController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/SmsHeaderModel.dart';
import 'package:medivic/models/addressModel.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/models/mAddress.dart';
import 'package:medivic/screens/gooogleMap/googleMap.dart';
import 'package:medivic/screens/more/load_html_screen.dart';
import 'package:medivic/screens/splash/choose_screen.dart';
import 'package:medivic/services/api/firebaseStorageService.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/services/authentication/firebaseAuthService.dart';
import 'package:medivic/shared/authScreenWidgets/authSreenWidgets.dart';
import 'package:medivic/shared/customInput.dart';
import 'package:medivic/utils/validators.dart';
import 'package:url_launcher/url_launcher.dart';

class SignupDoctorForm extends StatefulWidget {
  static int codeOtp = 000000;
  static String phonenumber = "";
  final String doctorId;
  final String phoneNumber;
  final String email;
  final bool isAuth;

  const SignupDoctorForm(
      {Key key, this.doctorId, this.phoneNumber, this.email, this.isAuth})
      : super(key: key);

  @override
  _SignupDoctorFormState createState() => _SignupDoctorFormState();
}

class _SignupDoctorFormState extends State<SignupDoctorForm> {
  String email,
      doctorId,
      name = "",
      confirmPassword = "",
      password = "",
      specialities = "",
      fee = "",
      city = "",
      country = "",
      pincode = "",
      state = "",
      street = "";
  String firstName = "";
  String lastName = "";
  String id = "";
  String phoneNumber;
  String age = "";
  String gender = "",
      hpcsaNumber = "",
      ipaNumber = "",
      groupPracticeNumber = "",
      briefProfile = "",
      language = "",
      numberPractices = "";
  Location location;

  bool _isLoading = false, isDate = false, isCheck = false;
  String errorText = '';
  int _value = 0;
  IconData icon;
  var listOfFields = <Widget>[];
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  List<String> PracticesList = [];
  List _myActivities;
  String _myActivitiesResult;
  final multyformKey = new GlobalKey<FormState>();
  int num = 1;
  double listHeight = 100.00;
  File imagefile;
  List<File> files;
  SmsHeader smsHeader;

  @override
  void initState() {
    super.initState();
    _myActivities = [];
    _myActivitiesResult = '';
    phoneNumber = widget.phoneNumber;
    email = widget.email;
    doctorId = widget.doctorId;
    controllerExp.text = '0';
  }

  DateTime selectedDate = DateTime(2000, 1);
  DateTime selectedPracticingDate = DateTime.now();
  final dateFormat = DateFormat("dd-MM-yyyy");

  // TextEditingController controllerAge = TextEditingController();
  TextEditingController controllerExp = TextEditingController();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(1940, 1),
      lastDate: DateTime.now().subtract(const Duration(days: 365 * 16)),
      builder: (BuildContext context, Widget child) {
        return Theme(
          data: ThemeData.light().copyWith(
              //OK/Cancel button text color
              primaryColor: appBarColor, //Head background
              accentColor: appBarColor //selection color
              //dialogBackgroundColor: Colors.white,//Background color
              ),
          child: child,
        );
      },
    );
    if (picked != null && picked != selectedDate)
      setState(() {
        isDate = true;
        selectedDate = picked;
        final duration = DateTime.now().difference(selectedDate);
        age = (duration.inDays / 365).floor().toString();
        // controllerAge.text = age;
      });
  }

  void showPracticingDatePicker() async {
    final DateTime picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1940, 1),
      lastDate: DateTime.now(),
      builder: (BuildContext context, Widget child) {
        return Theme(
          data: ThemeData.light().copyWith(
              //OK/Cancel button text color
              primaryColor: appBarColor, //Head background
              accentColor: appBarColor //selection color
              //dialogBackgroundColor: Colors.white,//Background color
              ),
          child: child,
        );
      },
    );

    if (picked != null) {
      setState(() {
        selectedPracticingDate = picked;
        Duration duration = DateTime.now().difference(selectedPracticingDate);
        controllerExp.text = (duration.inDays / 365).floor().toString();
      });
    }
  }

  void pickImage() async {
    final pickedFile =
        await ImagePicker().getImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        imagefile = File(pickedFile.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Form(
        key: _formKey,
        child: Column(
          children: <Widget>[
            Center(
              child: InkWell(
                onTap: () {
                  pickImage();
                },
                child: CircleAvatar(
                  backgroundColor: Colors.white,
                  backgroundImage: imagefile == null
                      ? const AssetImage('assets/profile.png')
                      : FileImage(imagefile),
                  radius: 60,
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const Text(
              'Professional Portrait Guidelines',
              style: TextStyle(
                  color: appBarColor, fontSize: 16, fontFamily: fontMontserrat),
            ),
            const Text(
              '-Taken in full-face view directly facing the camera.\n- Your face and shoulders should take up the entire frame of the photo',
              style: TextStyle(fontSize: 10, fontFamily: fontMontserrat),
            ),
            const SizedBox(
              height: 10,
            ),
            CustomInput(
              placeholder: AppStrings.firstNameLabel,
              onChange: (val) => firstName = val,
              validator: AuthController.validateFirstName,
              iconAsset: 'lib/assets/icons/form/user.png',
            ),
            CustomInput(
              placeholder: AppStrings.lastNameLabel,
              onChange: (val) => lastName = val,
              validator: AuthController.validateLastName,
              iconAsset: 'lib/assets/icons/form/user.png',
            ),
            InkWell(
              onTap: () {
                _selectDate(context);
              },
              child: Container(
                  height: 60,
                  margin: const EdgeInsets.only(top: 10.0),
                  padding: const EdgeInsets.all(8.0),
                  decoration: BoxDecoration(
                    color: _theme.inputDecorationTheme.fillColor,
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                  child: Row(
                    children: <Widget>[
                      Container(
                        height: 38,
                        width: 38,
                        margin: const EdgeInsets.only(right: 10.0),
                        child: Image.asset('lib/assets/icons/form/dob.png'),
                      ),
                      if (isDate)
                        Text(dateFormat.format(selectedDate),
                            style: const TextStyle(
                                fontSize: 16, fontFamily: fontMontserrat))
                      else
                        const Text(
                          'Date of Birth',
                          style: TextStyle(
                              color: darkBlueColor,
                              fontSize: 16,
                              fontFamily: fontMontserrat),
                        ),
                    ],
                  )),
            ),
            Container(
                width: 350,
                margin: const EdgeInsets.only(top: 10.0),
                padding: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  color: _theme.inputDecorationTheme.fillColor,
                  borderRadius: BorderRadius.circular(30.0),
                ),
                child: Container(
                  child: Row(
                    children: <Widget>[
                      Container(
                        height: 38,
                        width: 38,
                        margin: const EdgeInsets.only(right: 10.0),
                        child: Image.asset('lib/assets/icons/form/gender.png'),
                      ),
                      DropdownButton(
                          value: _value,
                          underline: SizedBox(),
                          items: [
                            DropdownMenuItem(
                              child: Text(
                                'Gender',
                                style: TextStyle(
                                    fontSize: 16, fontFamily: fontMontserrat),
                              ),
                              value: 0,
                            ),
                            DropdownMenuItem(
                              child: Text(
                                'Male',
                                style: TextStyle(
                                    fontSize: 16, fontFamily: fontMontserrat),
                              ),
                              value: 1,
                            ),
                            DropdownMenuItem(
                              child: Text(
                                'Female',
                                style: TextStyle(
                                    fontSize: 16, fontFamily: fontMontserrat),
                              ),
                              value: 2,
                            ),
                            DropdownMenuItem(
                                child: Text(
                                  'Prefer Not To Say',
                                  style: TextStyle(
                                      fontSize: 16, fontFamily: fontMontserrat),
                                ),
                                value: 3)
                          ],
                          onChanged: (value) {
                            setState(() {
                              _value = value;
                            });
                          }),
                    ],
                  ),
                )),
            CustomInput(
              placeholder: AppStrings.nationalIdNumberLabel,
              onChange: (val) => id = val,
              validator: AuthController.validateNationalId,
              iconAsset: 'lib/assets/icons/form/nid.png',
            ),
            CustomInput(
              placeholder: AppStrings.hpcsaLabel,
              onChange: (val) => hpcsaNumber = val,
              validator: AuthController.validatHhpcsaNumber,
              iconAsset: 'lib/assets/icons/form/hpsa.png',
            ),
            CustomInput(
              data: email,
              isEnable: email == null ? true : false,
              placeholder: AppStrings.emailLabel,
              onChange: (val) => email = val,
              validator: AuthController.validateEmail,
              iconAsset: 'lib/assets/icons/form/email.png',
            ),
            CustomInput(
              data: phoneNumber ?? '+27',
              isEnable: widget.phoneNumber == null || widget.phoneNumber.isEmpty
                  ? true
                  : false,
              placeholder: AppStrings.phoneNumberLabel,
              onChange: (val) => phoneNumber = val,
              keyboardType: TextInputType.phone,
              validator: AuthController.validatePhoneId,
              iconAsset: 'lib/assets/icons/form/phone.png',
            ),
            CustomInput(
              placeholder: AppStrings.streetLabel,
              onChange: (val) => street = val,
              // validator: (val) => AuthController.validateStreateName(street),
              iconAsset: 'lib/assets/icons/form/street.png',
            ),
            CustomInput(
              placeholder: AppStrings.cityLabel,
              onChange: (val) => city = val,
              // validator: (val) => AuthController.validateAddress(city),
              iconAsset: 'lib/assets/icons/form/city.png',
            ),
            CustomInput(
              placeholder: AppStrings.stateLabel,
              onChange: (val) => state = val,
              // validator: (val) => AuthController.validateStateName(state),
              iconAsset: 'lib/assets/icons/form/street.png',
            ),
            CustomInput(
              placeholder: AppStrings.countryLabel,
              onChange: (val) => country = val,
              // validator: (val) => AuthController.validatecountry(country),
              iconAsset: 'lib/assets/icons/form/country.png',
            ),
            CustomInput(
              placeholder: AppStrings.pinLabel,
              onChange: (val) => pincode = val,
              // validator: (val) => AuthController.validatePincode(pincode),
            ),
            _buildLocationPicker(),
            InkWell(
              onTap: () {
                showPracticingDatePicker();
              },
              child: Container(
                height: 70,
                child: Container(
                    margin: const EdgeInsets.only(top: 10.0),
                    padding: const EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      color: _theme.inputDecorationTheme.fillColor,
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    child: Row(
                      children: <Widget>[
                        Container(
                          height: 36,
                          width: 36,
                          margin: const EdgeInsets.only(right: 10.0),
                          child: Image.asset('lib/assets/icons/form/dob.png'),
                        ),
                        Text(
                            selectedPracticingDate == null
                                ? 'Date Started Practicing'
                                : dateFormat.format(selectedPracticingDate),
                            style: const TextStyle(
                                fontSize: 16, fontFamily: fontMontserrat)),
                      ],
                    )),
              ),
            ),
            CustomInput(
              placeholder: '${AppStrings.experience} ${AppStrings.years}',
              onChange: (val) {},
              validator: validateExp,
              keyboardType: TextInputType.number,
              iconAsset: 'lib/assets/icons/form/experience.png',
              inputFormatters: [WhitelistingTextInputFormatter.digitsOnly],
              controller: controllerExp,
            ),
            CustomInput(
              placeholder: AppStrings.fee,
              onChange: (val) => fee = val,
              inputFormatters: [WhitelistingTextInputFormatter.digitsOnly],
              validator: validateFee,
              iconAsset: 'lib/assets/icons/form/fee.png',
              keyboardType: TextInputType.number,
              prefixText:
                  '${Config.CURRENCY_SYMBOL.isEmpty ? Config.CURRENCY : Config.CURRENCY_SYMBOL} ',
            ),
            InkWell(
              onTap: () {
                _showMultiSelect(context);
              },
              child: Container(
                child: Container(
                    width: 350,
                    margin: const EdgeInsets.only(top: 10.0),
                    padding: const EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      color: _theme.inputDecorationTheme.fillColor,
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    child: Container(
                      height: 50,
                      child: Row(
                        children: <Widget>[
                          Container(
                            height: 38,
                            width: 38,
                            margin: const EdgeInsets.only(right: 10.0),
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.black38),
                              shape: BoxShape.circle,
                            ),
                            child: Image.asset(
                                'lib/assets/icons/form/speciality.png'),
                          ),
                          if (specialities.isNotEmpty)
                            Expanded(
                              child: Text(
                                specialities,
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontFamily: fontMontserrat,
                                ),
                              ),
                            )
                          else
                            const Text(
                              'Add Specialities',
                              style: TextStyle(
                                color: Colors.black38,
                                fontSize: 16,
                                fontFamily: fontMontserrat,
                              ),
                            ),
                        ],
                      ),
                    )),
              ),
            ),
            if (widget.isAuth != null && !widget.isAuth)
              CustomInput(
                placeholder: AppStrings.passwordLabel,
                onChange: (val) => password = val,
                validator: (val) => AuthController.validatePassword(password),
                iconAsset: 'lib/assets/icons/form/password.png',
              ),
            if (widget.isAuth != null && !widget.isAuth)
              CustomInput(
                placeholder: AppStrings.confirmPasswordLabel,
                onChange: (val) => confirmPassword = val,
                iconAsset: 'lib/assets/icons/form/password.png',
                validator: (val) => AuthController.validateConfirmPassword(
                  confirmPassword,
                  password,
                ),
              ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Checkbox(
                      activeColor: appBarColor,
                      value: isCheck,
                      onChanged: (bool value) {
                        setState(() {
                          isCheck = value;
                        });
                      },
                    ),
                    const Text(
                      ' ${AppStrings.iAgreeTo} ',
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 12,
                        fontFamily: fontMontserrat,
                      ),
                    ),
                    GestureDetector(
                      onTap: () => _termsOfService(),
                      child: const Text(
                        AppStrings.termsAndCondition,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 12,
                          fontFamily: fontMontserrat,
                          fontWeight: FontWeight.bold,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Submit(
              onPress: () => {
                if (isCheck) {submit(context)}
              },
              isLoading: _isLoading,
              lable: AppStrings.signup,
              color: isCheck
                  ? _theme.primaryColorLight.withOpacity(1)
                  : _theme.primaryColorLight.withOpacity(0.2),
            ),
            ShowError(
              text: errorText,
            ),
            /*FooterLinks(),*/
          ],
        ),
      ),
    );
  }

  void _showMultiSelect(BuildContext context) async {
    List<String> names = [
      'JOINTS AND BONES',
      'WOMEN\'S HEALTH',
      'URINARY TRACT HEALTH',
      'SKIN',
      'SEX SPECIALIST',
      'PHYSICAL INABILITY',
      'DIET AND FITNESS',
      'MENTAL HEALTH',
      'LUNG HEALTH',
      'KIDNEYS',
      'ALTERNATIVE MEDICINE',
      'HIV/AIDS',
      'DIGESTIVE',
      'HEART CONDITION',
      'COVID-19',
      'ACUTE & CHRONIC ILLNESS',
      'OPERATIVE MANAGEMENT',
      'EYE CARE',
      'EAR NOSE AND THROAT',
      'DIABETES SPECIALIST',
      'DENTAL HEALTH',
      'CHILD CARE HEALTH',
      'CANCER',
      'NERVES'
    ];
    names.sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    final List items = <MultiSelectDialogItem<int>>[];
    for (int i = 0; i < names.length; i++) {
      items.add(MultiSelectDialogItem(i + 1, names[i]));
    }

    final selectedValues = await showDialog<List<String>>(
      context: context,
      builder: (BuildContext context) {
        return MultiSelectDialog(
          items: items,
          initialSelectedValues: [1, 3].toSet(),
        );
      },
    );

    if (selectedValues != null && selectedValues.isNotEmpty)
      setState(() {
        specialities = selectedValues.join(",");
      });
  }

  Future<void> _termsOfService() async {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) => LoadHTML(
                  title: 'Standard Terms & Conditions',
                  field: 'terms',
                )));
  }

  String validateName(String value) {
    if (value.length <= 3) {
      return AppStrings.invalidNameShort;
    }
    return null;
  }

  String validateExp(String value) {
    if (value.isEmpty) {
      return AppStrings.invalidFieldEmpty;
    }

    if (Validator.isExperienceValid(value)) {
      if (int.parse(value) <= 70) {
        return null;
      } else {
        return AppStrings.invalidExperienceTooMuch;
      }
    }
    return AppStrings.invalidExperience;
  }

  String validateFee(String value) {
    if (value.isEmpty) {
      return AppStrings.invalidFieldEmpty;
    } else if (int.parse(value.toString()) < 250) {
      return AppStrings.errorFees;
    }
    return null;
  }

  String validateSpecialities(String val) {
    if (val.isEmpty) {
      return AppStrings.invalidFieldEmpty;
    }

    if (Validator.isSpecialitiesValid(val)) {
      return null;
    }
    return AppStrings.invalidSpecialities;
  }

  Future<void> submit(BuildContext context) async {
    if (specialities == null || specialities.isEmpty) {
      Fluttertoast.showToast(msg: 'Please select specialities');
      return;
    }
    if (imagefile == null) {
      Fluttertoast.showToast(msg: 'Please select profile picture');
      return;
    }

    if (AuthController.validateForm(_formKey)) {
      // Start the indicator
      setState(() => _isLoading = !_isLoading);

      if (email.isNotEmpty) {
        final isEmailExist = await FirestoreService.isEmailExist(email, true);
        if (isEmailExist) {
          Fluttertoast.showToast(msg: 'Your given email is already used');
          setState(() => _isLoading = !_isLoading);
          return;
        }
      }

      if (phoneNumber.isNotEmpty) {
        final isPhoneExist =
            await FirestoreService.isPhoneExist(phoneNumber, true);
        if (isPhoneExist) {
          Fluttertoast.showToast(
              msg: 'Your given phone number is already used');
          setState(() => _isLoading = !_isLoading);
          return;
        }
      }

      // creates the specialities array with lower case strings.
      List createSpecialities() {
        final list = <String>[];
        if (specialities != null && specialities.isNotEmpty) {
          final List<String> tempList = specialities.split(',');
          for (final e in tempList) {
            list.add(e.trim().toLowerCase());
          }
        }
        return list;
      }

      if (isCheck) {
        // Authenticate doctor
        try {
          switch (_value) {
            case 1:
              gender = 'Male';
              break;
            case 2:
              gender = 'Female';
              break;
            case 3:
              gender = 'Prefer Not To Say';
              break;
          }

          if (doctorId == null || doctorId.isEmpty) {
            final authUser = await FirebaseAuthService()
                .createUserWithEmailAndPassword(email, password);
            if (authUser != null && authUser.uid.isNotEmpty) {
              doctorId = authUser.uid;
            } else {
              setState(() => _isLoading = false);
              return;
            }
          }

          String fileUrl;
          if (imagefile != null) {
            fileUrl = await FirebaseStorageService.uploadFile(imagefile,
                fileName: doctorId);
            log('url $fileUrl', name: 'Upload');
          }

          final doctor = Doctor(
            uid: doctorId,
            name: firstName + ' ' + lastName ?? '',
            lastName: lastName,
            id: id,
            email: email,
            gender: gender,
            dob: selectedDate,
            phoneNumber: phoneNumber,
            age: age,
            hpcaNumber: hpcsaNumber,
            ipaNumber: ipaNumber,
            groupPracticeNumber: groupPracticeNumber,
            practices: PracticesList,
            briefProfile: briefProfile,
            imageUrl: fileUrl ?? Config.placeholedImageUrl,
            experience: controllerExp.text,
            isOTP: '0',
            isActive: 0,
            fee: fee,
            address: Address(
                city: city,
                street: street,
                country: country,
                state: state,
                pin: pincode),
            location: location,
            specialities: createSpecialities(),
          );

          await FirestoreService.createDoctor(doctorId, email, doctor.toJson())
              .then((value) {});

          // If doctorId is not empty then set the doctorId in the provider
          if (doctorId != null && doctorId.isNotEmpty) {
            final bool isDataAvailable =
                await LocatorService.doctorProvider().fetchDoctorData(doctorId);
            if (isDataAvailable) {
              AuthController.setDoctorId(doctorId);
              await AuthController.saveDoctorCredentials(doctorId, email);
              // Setup push notification for the user.
              LocatorService.pushNotificationService()
                  .manageNotificationsAtAuth(
                doctorId: doctorId,
              );
            } else
              Fluttertoast.showToast(
                  msg:
                      'Could not get the data for this user. Please try again');

            showInfoDialog();
          } else {
            errorText = 'Could not find the account. Please try again';
          }
        } on PlatformException catch (e) {
          errorText = e.message.toString();
          log(e.message, name: 'Error log: Signup page');
        } catch (e) {
          errorText = e.toString();
        }
      } else {
        Fluttertoast.showToast(msg: "Please Accept Terms & Conditions");
      }
      // Stop the indicator
      setState(() => _isLoading = !_isLoading);
    }
  }

  void showInfoDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          title: const Text(
            'Registration Info',
            style: TextStyle(fontFamily: fontMontserrat),
          ),
          content: const Text(
            'Thank you for signing up. Your profile is undergoing our verification process and should be accessible within 48 hours.',
            style: TextStyle(fontFamily: fontMontserrat),
          ),
          actions: [
            FlatButton(
              color: appBarColor,
              child: const Text(
                'Close',
                style: TextStyle(fontFamily: fontMontserrat),
              ),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const Choose(),
                    ),
                    (route) => false);
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> uploadImage(String uid) async {
    // If the file value is not null proceed
    if (imagefile != null) {
      // get the user id
      //final userId = LocatorService.userProvider().user.uid;

      if (uid != null && uid != '') {
        // start uploading
        final newUrl = await FirebaseStorageService.uploadFile(
          imagefile,
          fileName: uid,
        );

        // check for upload status
        if (newUrl != null) {
          // update the database
          await FirestoreService.updateSignupImageUrl(newUrl, uid);
          //LocatorService.userProvider().updateImage(newUrl);
        }
      } else {}
    }
  }

  Future<void> uploadDocument(String uid) async {
    List<String> urls = [];
    // If the file value is not null proceed
    if (files != null) {
      // get the user id
      // final userId = LocatorService.userProvider().user.uid;
      String newUrl = "";
      if (uid != null && uid != '') {
        // start uploading
        for (var i = 0; i < files.length; i++) {
          newUrl = await FirebaseStorageService.uploadFile(
            files[i],
            fileName: DateTime.now().millisecondsSinceEpoch.toString(),
          );
          urls.insert(i, newUrl);
        }

        // check for upload status
        if (urls != null) {
          // update the database
          await FirestoreService.updateDocumentUrl(urls, uid);
        }
      } else {}
    }
  }

  Widget _buildLocationPicker() {
    return GestureDetector(
      child: Container(
        width: double.infinity,
        height: 60,
        margin: const EdgeInsets.only(top: 10.0),
        padding: const EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          color: Theme.of(context).inputDecorationTheme.fillColor,
          borderRadius: BorderRadius.circular(30.0),
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              margin: const EdgeInsets.only(right: 10.0),
              child: Image.asset('lib/assets/icons/form/street.png'),
            ),
            Text(
              location == null ? 'Location' : location.toString(),
              style: const TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.w500,
                fontFamily: fontMontserrat,
                color: darkBlueColor,
              ),
            ),
          ],
        ),
      ),
      onTap: () async {
        // final locationResult = await CommonUtils.openLocationPicker(context);
        // setState(() => location = Location.picked(locationResult));
        MAddress address = await Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => const GoogleMapScreen(
            isLock: false,
          ),
        ));

        if (address != null)
          setState(
              () => location = Location.pickedNew(address.lat, address.lng));
      },
    );
  }
}

class FooterLinks extends StatelessWidget {
  // Launch the terms of service URL
  Future<void> _launchURL1() async {
    const url = 'https://flutter.dev';
    if (await canLaunch(url)) {
      await launch(url);
    }
  }

  // Launch the privacy policy URL
  Future<void> _launchURL2() async {
    const url = 'https://flutter.dev';
    if (await canLaunch(url)) {
      await launch(url);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return DefaultTextStyle(
      style: _theme.textTheme.caption.copyWith(
        color: const Color.fromRGBO(200, 200, 200, 1),
        fontFamily: fontMontserrat,
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Wrap(
          runSpacing: 2,
          alignment: WrapAlignment.center,
          children: <Widget>[
            const Text(
              AppStrings.tosPreText,
              style: TextStyle(fontFamily: fontMontserrat),
            ),
            GestureDetector(
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (BuildContext context) => LoadHTML(
                            title: 'Standard Terms & Conditions',
                            field: 'terms',
                          ))),
              child: const Text(
                AppStrings.termsOfService,
                style: TextStyle(
                  color: Color(0xFF64B5F6),
                  fontFamily: fontMontserrat,
                ),
              ),
            ),
            const Text(
              ' ${AppStrings.and} ',
              style: TextStyle(fontFamily: fontMontserrat),
            ),
            GestureDetector(
              onTap: () => _launchURL2(),
              child: const Text(
                AppStrings.privacyPolicy,
                style: TextStyle(
                    color: Color(0xFF64B5F6), fontFamily: fontMontserrat),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MultiSelectDialogItem<V> {
  const MultiSelectDialogItem(this.value, this.label);

  final V value;
  final String label;
}

class MultiSelectDialog<V> extends StatefulWidget {
  MultiSelectDialog({Key key, this.items, this.initialSelectedValues})
      : super(key: key);

  final List<MultiSelectDialogItem<V>> items;
  final Set<V> initialSelectedValues;

  @override
  State<StatefulWidget> createState() => _MultiSelectDialogState<V>();
}

class _MultiSelectDialogState<V> extends State<MultiSelectDialog<V>> {
  final _selectedValues = Set<V>();
  List<String> selected = [];

  void initState() {
    super.initState();
    if (widget.initialSelectedValues != null) {
      _selectedValues.addAll(widget.initialSelectedValues);
    }
  }

  void _onItemCheckedChange(String itemValue, bool checked) {
    setState(() {
      if (checked) {
        selected.add(itemValue);
      } else {
        selected.remove(itemValue);
      }
    });
  }

  void _onCancelTap() {
    Navigator.pop(context);
  }

  void _onSubmitTap() {
    Navigator.pop(context, selected);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.white,
      title: Text(
        'Select Specialities',
        style: TextStyle(fontFamily: fontMontserrat),
      ),
      contentPadding: EdgeInsets.only(top: 12.0),
      content: SingleChildScrollView(
        child: Container(
          color: Colors.white,
          child: ListBody(
            children: widget.items.map(_buildItem).toList(),
          ),
        ),
      ),
      actions: <Widget>[
        FlatButton(
          child: Text(
            'CANCEL',
            style: TextStyle(fontFamily: fontMontserrat),
          ),
          onPressed: _onCancelTap,
        ),
        FlatButton(
          child: Text(
            'OK',
            style: TextStyle(fontFamily: fontMontserrat),
          ),
          onPressed: _onSubmitTap,
        )
      ],
    );
  }

  Widget _buildItem(MultiSelectDialogItem<V> item) {
    final checked = selected.contains(item.label);
    return CheckboxListTile(
      value: checked,
      title: Text(
        item.label,
        style: TextStyle(fontFamily: fontMontserrat),
      ),
      controlAffinity: ListTileControlAffinity.leading,
      onChanged: (checked) => _onItemCheckedChange(item.label, checked),
    );
  }
}
