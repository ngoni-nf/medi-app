import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/controllers/authController.dart';
import 'package:medivic/models/OtpModel.dart';
import 'package:medivic/models/SmsHeaderModel.dart';
import 'package:medivic/screens/doctorsAccountScreens/signupDoctor/form/signupDoctorForm.dart';
import 'package:medivic/screens/signup/form/signupForm.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/services/webservice.dart';
import 'package:pin_code_fields/pin_code_fields.dart';



class DoctorPinCodeVerificationScreen extends StatefulWidget {
  final String phoneNumber;
  final String OTP;
  final String verificationID;

  DoctorPinCodeVerificationScreen(this.phoneNumber,this.OTP,this.verificationID);

  @override
  _DoctorPinCodeVerificationScreenState createState() =>
      _DoctorPinCodeVerificationScreenState();
}

class _DoctorPinCodeVerificationScreenState extends State<DoctorPinCodeVerificationScreen> {
  var onTapRecognizer;

  TextEditingController textEditingController = TextEditingController();
  // ..text = "123456";

  StreamController<ErrorAnimationType> errorController;

  bool hasError = false;
  bool isLoad = false;
  String currentText = "";
  SmsHeader smsHeader;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    onTapRecognizer = TapGestureRecognizer()
      ..onTap = () {
        Navigator.pop(context);
      };
    errorController = StreamController<ErrorAnimationType>();
    super.initState();
    _fetchAccessToken();
  }

  @override
  void dispose() {
    errorController.close();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Colors.white,
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: Stack(
          children: [
            Container(
              margin: EdgeInsets.only(top: 80),
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              child: ListView(

                children: <Widget>[
                  Center(
                    child: SvgPicture.asset(

                      'lib/assets/svg/cardiogram.svg',
                      width: 200,
                      height: 200,
                    ),
                  ),
                  SizedBox(height: 30),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: Text(
                      'Phone Number Verification',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  /*Padding(
                    padding:
                    const EdgeInsets.symmetric(horizontal: 30.0, vertical: 8),
                    child: RichText(
                      text: TextSpan(
                          text: "Enter the code ",
                          children: [
                            TextSpan(
                                text: widget.phoneNumber,
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15)),
                          ],
                          style: TextStyle(color: Colors.black54, fontSize: 15)),
                      textAlign: TextAlign.center,
                    ),
                  ),*/
                  SizedBox(
                    height: 20,
                  ),
                  Form(
                    key: formKey,
                    child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 8.0, horizontal: 30),
                        child: PinCodeTextField(
                          length: 6,
                          obsecureText: false,
                          animationType: AnimationType.fade,
                          validator: (v) {
                            if (v.length < 3) {
                              return "Please enter proper OTP";
                            } else {
                              return null;
                            }
                          },
                          pinTheme: PinTheme(
                            shape: PinCodeFieldShape.box,
                            borderRadius: BorderRadius.circular(10),
                            inactiveColor:_theme.primaryColorLight.withOpacity(0.8) ,
                            disabledColor: _theme.primaryColorLight.withOpacity(0.8),
                            inactiveFillColor:_theme.primaryColorLight.withOpacity(0.8) ,
                            selectedFillColor: _theme.primaryColorLight.withOpacity(0.8),
                            fieldHeight: 45,
                            fieldWidth: 45,
                            activeFillColor:
                            hasError ? Colors.white : Colors.white,
                          ),
                          animationDuration: Duration(milliseconds: 300),
                          enableActiveFill: true,
                          errorAnimationController: errorController,
                          controller: textEditingController,
                          onCompleted: (v) {
                            print("Completed");
                          },
                          onChanged: (value) {
                            print(value);
                            setState(() {
                              currentText = value;
                            });
                          },
                          beforeTextPaste: (text) {
                            print("Allowing to paste $text");
                            //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                            //but you can show anything you want here, like your pop up saying wrong paste format or etc
                            return true;
                          },
                        )),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 30.0),
                    child: Text(
                      hasError ? " " : "",
                      style: TextStyle(
                          color: appBarColor,
                          fontSize: 12,
                          fontWeight: FontWeight.w400),
                    ),
                  ),


                  Container(
                    margin: EdgeInsets.only(top: 12),
                    child: InkWell(
                        onTap: () {
                          formKey.currentState.validate();
                          // conditions for validating
                          if (currentText.length != 6) {
                            errorController.add(ErrorAnimationType
                                .shake); // Triggering error shake animation
                            setState(() {
                              hasError = true;
                            });
                          } else {
                            setState(() {
                              hasError = false;
                              //check();
                              checkOtp(currentText);
                              /*scaffoldKey.currentState.showSnackBar(SnackBar(
                                content: Text("Aye!!"),
                                duration: Duration(seconds: 2),
                              ));*/
                            });
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(left:18.0,right: 18),
                          child: Container(
                              width: MediaQuery
                                  .of(context)
                                  .size
                                  .width - 200.0,
                              height: 50.0,
                              decoration: BoxDecoration(
                                  borderRadius:
                                  BorderRadius.circular(25.0),
                                  color:_theme.primaryColorLight.withOpacity(0.8)),
                              child: Center(
                                  child: Text('Submit',
                                      style: TextStyle(
                                          fontFamily: 'nunito',
                                          fontSize: 18.0,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white)))),
                        )),
                  ),
                  Center(
                    child: Container(
                      margin: EdgeInsets.only(top: 32),
                      child: InkWell(
                          onTap: () {
                            _sendOtp();
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(left:18.0,right: 18),
                            child: Container(
                                width: MediaQuery
                                    .of(context)
                                    .size
                                    .width - 200.0,
                                height: 50.0,
                                decoration: BoxDecoration(
                                    borderRadius:
                                    BorderRadius.circular(25.0),
                                    color: _theme.primaryColorLight.withOpacity(0.8)),
                                child: Center(
                                    child: Text('Resend',
                                        style: TextStyle(
                                            fontFamily: 'nunito',
                                            fontSize: 18.0,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white)))),
                          )),
                    ),
                  )

                ],
              ),
            ),
            Center(
              child: Visibility(
                visible: isLoad,
                child: Container(
                  alignment: Alignment.center,
                  child: Center(
                    child: CircularProgressIndicator(
                      valueColor: new AlwaysStoppedAnimation<Color>(Colors.black),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  checkOtp(String code)async {
    setState(() {
      isLoad=true;
    });
    if(int.parse(code)==SignupDoctorForm.codeOtp)
      {
        print("enter");
        await FirestoreService.updateOtpStatusDoctor("1", "");
        setState(() {
          isLoad=false;
        });
        AuthController.navigateToDoctorHome();
      }
    else{
      setState(() {
        isLoad=false;
      });
      Fluttertoast.showToast(msg: "OTP is invalid please try again");
    }
  }

  _fetchAccessToken() async {
    Webservice().loadGetwithHeader(getHeader).then(
          (model) => {setState(() {})},
    );
  }

  Resource<SmsHeader> get getHeader {
    return Resource(
        url: "https://rest.smsportal.com/v1/Authentication",
        parse: (response) {
          final result = json.decode(response.body);
          smsHeader= SmsHeader.fromJson(json.decode(response.body));
          print("" + ".......getSupplierLogin......." + smsHeader.token);

        });
  }

  _sendOtp() async {

    setState(() {
      isLoad=true;
    });
    var rnd = new math.Random();
    var next = rnd.nextDouble() * 1000000;
    while (next < 100000) {
      next *= 10;
    }
    print(next.toInt());
    SignupDoctorForm.codeOtp=next.toInt();
    Map<String, dynamic>  options1= {
      "Messages": [
        {
          "Content": "Your MediVic OTP is "+next.toInt().toString(),
          "Destination":SignupDoctorForm.phonenumber,
        }
      ]
    };
    Webservice().loadPostwithHeader(sendOtpUrl,options1,smsHeader.token).then(
          (model) => {setState(() {})},
    );
  }

  Resource<OtpModel> get sendOtpUrl {
    return Resource(
        url: "https://rest.smsportal.com/v1/bulkmessages",
        parse: (response) {
          final result = json.decode(response.body);
          print("" + ".......getSupplierLogin......." + result.toString());
          if(response.statusCode==200) {
            setState(() {
              isLoad=false;
            });
            Fluttertoast.showToast(msg: "Otp send successfully");
            // AuthController.navigateToOTPScreen();
          }
          else{
            setState(() {
              isLoad=false;
            });
            Fluttertoast.showToast(msg: "Something Went Wrong");
          }


        });
  }



}