import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:medivic/const.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/note.dart';
import 'package:medivic/services/api/firebaseStorageService.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/shared/authScreenWidgets/authSreenWidgets.dart';

class AddNote extends StatefulWidget {
  const AddNote({this.note});

  final Note note;

  @override
  _AddNoteState createState() => _AddNoteState();
}

class _AddNoteState extends State<AddNote> {
  File file, imageURI;
  bool _isLoading = false;
  Note note = Note();
  TextEditingController txtControllerNote = TextEditingController();
  final picker = ImagePicker();

  Future getImageFromCamera() async {
    final pickedFile = await picker.getImage(source: ImageSource.camera);
    setState(() {
      imageURI = File(pickedFile.path);
    });
  }

  @override
  void initState() {
    if (widget.note != null) {
      note = widget.note;
      txtControllerNote.text = note.note;
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          iconTheme: const IconThemeData(color: Colors.white),
          centerTitle: true,
          backgroundColor: appBarColor,
          title: const Text(
            'Add Note',
            style: styleAppbarTitle,
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                height: 100,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          'Scan \nSigned \nNote',
                          style: TextStyle(
                              color: Colors.black, fontFamily: fontMontserrat),
                        ),
                      ],
                    ),
                    const SizedBox(
                      width: 30,
                    ),
                    _buildImage(),
                  ],
                ),
              ),
              const SizedBox(
                height: 32,
              ),
              InkWell(
                onTap: () async {
                  file = await FilePicker.getFile();
                  if (file != null) {
                    setState(() {});
                  }
                },
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: 50,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(32),
                      color: Colors.grey[300]),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      _getFilePath(),
                      textAlign: TextAlign.start,
                      style: const TextStyle(
                          color: Colors.grey, fontFamily: fontMontserrat),
                    ),
                  ),
                ),
              ),
              Container(
                margin: const EdgeInsets.all(20),
                width: MediaQuery.of(context).size.width,
                height: 200,
                decoration: const BoxDecoration(
                    border: Border(
                  left: BorderSide(color: Colors.grey),
                  right: BorderSide(color: Colors.grey),
                  top: BorderSide(color: Colors.brown),
                  bottom: BorderSide(color: Colors.brown),
                )),
                child: TextFormField(
                  keyboardType: TextInputType.text,
                  maxLines: null,
                  controller: txtControllerNote,
                  style: const TextStyle(
                      color: Colors.black54, fontFamily: fontMontserrat),
                  decoration: const InputDecoration(
                    hintStyle: TextStyle(
                        color: Colors.black, fontFamily: fontMontserrat),
                    fillColor: Colors.white,
                    hintText: 'Notes',
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: Submit(
                  color: appBarColor,
                  lable: 'SAVE',
                  onPress: () {
                    _submit();
                  },
                  isLoading: _isLoading,
                ),
              ),
              // Padding(
              //   padding: const EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 10),
              //   child: SizedBox(
              //     width: MediaQuery.of(context).size.width,
              //     height: 40,
              //     child: RaisedButton(
              //       color: appBarColor,
              //       shape: RoundedRectangleBorder(
              //         borderRadius: BorderRadius.circular(30),
              //       ),
              //       onPressed: () {
              //         Navigator.of(context).push(MaterialPageRoute(
              //           builder: (context) => FindPharmacy(),
              //         ));
              //       },
              //       child: Text(
              //         'Send to pharmacy'.toUpperCase(),
              //         style: const TextStyle(color: Colors.white, fontFamily: fontMontserrat),
              //       ),
              //     ),
              //   ),
              // ),
            ],
          ),
        ),
      ),
    );
  }

  String _getFilePath() {
    if (file != null)
      return file.path.split('/').last;
    else if (note != null && note.fileUrl != null) return 'There is a file';

    return 'Select a file';
  }

  Widget _buildImage() {
    if (imageURI != null)
      return InkWell(
        onTap: () => getImageFromCamera(),
        child: Image.file(
          imageURI,
          width: 60,
          height: 60,
        ),
      );
    else if (note != null && note.imageUrl != null) {
      return CachedNetworkImage(
        imageUrl: note.imageUrl,
        width: 50,
        height: 50,
        placeholder: (context, url) => const Center(
          child: CircularProgressIndicator(),
        ),
      );
    } else
      return IconButton(
        icon: const Icon(
          Icons.camera_alt,
          color: Colors.grey,
          size: 60,
        ),
        onPressed: () async {
          getImageFromCamera();
        },
      );
  }

  void _submit() async {
    setState(() {
      _isLoading = true;
    });
    String imageUrl, fileUrl;
    if (file != null) {
      fileUrl = await FirebaseStorageService.uploadFile(file);
      note.fileUrl = fileUrl;
    }
    if (imageURI != null) {
      imageUrl = await FirebaseStorageService.uploadFile(imageURI);
      note.imageUrl = imageUrl;
    }

    note.note = txtControllerNote.text;
    note.updatedAt = DateTime.now();
    bool isAdded = await FirestoreService.addNote(
        LocatorService.doctorProvider().doctor.uid, note);

    if (isAdded) {
      Fluttertoast.showToast(msg: 'Successfully addedd');
      Navigator.pop(context, true);
    } else {
      Fluttertoast.showToast(msg: 'Something went wrong');
    }
  }

  Future<void> _confirmationDialog() async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          content: Container(
            width: MediaQuery.of(context).size.width * 0.4,
            height: MediaQuery.of(context).size.width * 0.4,
            child: Stack(
              children: [
                Center(
                  child: const Text('Successfully Save to the patient profile',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black, fontFamily: fontMontserrat)),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: RaisedButton(
                    color: appBarColor,
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text(
                      'OK',
                      style: TextStyle(
                          color: Colors.white, fontFamily: fontMontserrat),
                    ),
                  ),
                )
              ],
            ),
          ),
          // actions: <Widget>[
          //   FlatButton(
          //     child: const Text('OK'),
          //     onPressed: () {
          //       Navigator.of(context).pop();
          //     },
          //   ),
          // ],
        );
      },
    );
  }
}
