// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/authController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/SmsHeaderModel.dart';
import 'package:medivic/screens/home/main_screen.dart';
import 'package:medivic/screens/otp/phone_verification.dart';
import 'package:medivic/screens/signup/signup.dart';
import 'package:medivic/services/storage/localStorage.dart';
import 'package:medivic/services/storage/storageConstants.dart';
import 'package:medivic/shared/authScreenWidgets/authSreenWidgets.dart';
import 'package:medivic/shared/customInput.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginForm extends StatefulWidget {
  @override
  LoginFormState createState() => LoginFormState();
}

class LoginFormState extends State<LoginForm> {
  String email;
  String password;
  bool _isLoading = false;
  bool _isRemembered = false;
  String errorText = '';
  SmsHeader smsHeader;
  String phoneNumber;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController controllerEmail = TextEditingController();
  TextEditingController controllerPass = TextEditingController();

  Future<void> submit() async {
    if (AuthController.validateForm(_formKey)) {
      // Start the indicator
      setState(() => _isLoading = !_isLoading);

      // Authenticate
      try {
        final result = await AuthController.login(email, password);

        if (result == null) {
          setState(() => _isLoading = !_isLoading);
          return;
        }

        // If userId is not empty then set the userId in the provider
        if (result.uid.isNotEmpty) {
          // Get the user data
          final bool isDataAvailable =
              await LocatorService.userProvider().fetchUserData(result.uid);

          if (LocatorService.userProvider().user.isBlock) {
            Fluttertoast.showToast(msg: AppStrings.blockedMsg);
            errorText = AppStrings.blockedMsg;
            print('blocked call');
          } else if (isDataAvailable) {
            AuthController.setUserId(result.uid);
            await AuthController.saveCredentials(result.uid, email);
            SharedPreferences preferences =
                await SharedPreferences.getInstance();
            preferences.setString('email', result.email);
            // Setup push notification for the user.
            LocatorService.pushNotificationService().manageNotificationsAtAuth(
              userId: result.uid,
            );
            phoneNumber = LocatorService.userProvider().user.phoneNumber;
            String isOtp = LocatorService.userProvider().user.isOTP;

            if (isOtp == "1") {
              Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MainScreen(),
                  ),
                  (route) => false);
            } else {
              if (phoneNumber.isNotEmpty) {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => PhoneVerification(
                    isPatient: true,
                    isAuth: false,
                    phone: phoneNumber,
                  ),
                ));
              } else
                AuthController.navigateToHome();
            }
            LocalStorage.setString(
                LocalStorageConstants.REMEMBER, _isRemembered ? '1' : '0');
            LocalStorage.setString(LocalStorageConstants.EMAIL, email);
            LocalStorage.setString(LocalStorageConstants.PASS, password);
          } else {
            errorText =
                'Could not get the data for this email. Please try again';
          }
        } else {
          errorText = 'Could not find the account. Please try again';
        }
      } on PlatformException catch (e) {
        errorText = e.message.toString();
        // log(e.message, name: 'Error message: Login page');
        // log(e.code, name: 'Error code: Login page');
      } catch (e) {
        errorText = AppStrings.somethingWentWrong;
        // log(e, name: 'Error: Login Page');
      }

      // Stop the indicator
      setState(() => _isLoading = !_isLoading);
    }
  }

  void _prepareForm() async {
    final remember =
        await LocalStorage.getString(LocalStorageConstants.REMEMBER);
    final email = await LocalStorage.getString(LocalStorageConstants.EMAIL);
    final pass = await LocalStorage.getString(LocalStorageConstants.PASS);

    setState(() {
      _isRemembered = remember == '1';
      if (_isRemembered) {
        this.email = email;
        this.password = pass;
        controllerEmail.text = email;
        controllerPass.text = pass;
      }
    });
  }

  @override
  void initState() {
    super.initState();
    _prepareForm();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Form(
        key: _formKey,
        child: Column(
          children: <Widget>[
            CustomInput(
              controller: controllerEmail,
              placeholder: AppStrings.emailLabel,
              onChange: (val) => email = val,
              validator: AuthController.validateEmail,
              iconAsset: 'lib/assets/icons/form/email.png',
            ),
            CustomInput(
              controller: controllerPass,
              placeholder: AppStrings.passwordLabel,
              onChange: (val) => password = val,
              validator: (val) => AuthController.validatePassword(password),
              iconAsset: 'lib/assets/icons/form/password.png',
            ),
            Row(
              children: [
                Checkbox(
                  value: _isRemembered,
                  onChanged: (value) {
                    setState(() {
                      _isRemembered = value;
                    });
                  },
                ),
                const Text(
                  'Remember me',
                  style: TextStyle(fontFamily: fontMontserrat),
                ),
              ],
            ),
            Submit(
              color: appBarColor,
              onPress: () => submit(),
              isLoading: _isLoading,
              lable: AppStrings.login,
            ),
            ShowError(
              text: errorText,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const ForgotPassword(),
                const SizedBox(
                  width: 20,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Signup(),
                        ));
                  },
                  child: const Text(
                    'Sign Up',
                    style: TextStyle(
                        fontFamily: fontMontserrat,
                        color: appBarColor,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
