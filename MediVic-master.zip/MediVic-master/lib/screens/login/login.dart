// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/authController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/screens/home/main_screen.dart';
import 'package:medivic/screens/login/form/loginForm.dart';
import 'package:medivic/screens/otp/phone_verification.dart';
import 'package:medivic/screens/signup/signup.dart';
import 'package:medivic/shared/authScreenWidgets/authSreenWidgets.dart';
import 'package:medivic/shared/dividerWithText.dart';
import 'package:medivic/shared/socialButtons/socialButtonsContainer.dart';

class Login extends StatelessWidget {
  const Login({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SocialLoginLoadingOverlay(
        child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 30),
          physics: const BouncingScrollPhysics(),
          children: <Widget>[
            // const LoginMessageTop(),
            SizedBox(
              height: MediaQuery.of(context).size.height / 10,
            ),
            const Center(
              child: Text(
                AppStrings.login,
                style: TextStyle(
                  color: darkBlueColor,
                  fontSize: 30.0,
                  fontFamily: fontMontserrat,
                ),
              ),
            ),
            Center(
              child: SvgPicture.asset(
                'lib/assets/svg/cardiogram.svg',
                width: 200,
                height: 200,
              ),
            ),
            LoginForm(),
            const SizedBox(
              height: 10,
            ),
            const DividerWithText(
              text: AppStrings.or,
              textStyle: TextStyle(
                fontFamily: fontMontserrat,
              ),
            ),
            SocialButtonsContainer(
              isGoogleVisiable: true,
              isFbVisiable: false,
              isOtpVisiable: true,
              googleLable: AppStrings.loginWithGoogle,
              googleOnPress: () => handleGoogleSignIn(context),
              facebookLable: AppStrings.loginWithFacebook,
              facebookOnPress: () => AuthController.signInWithFacebook(),
              otpLable: AppStrings.loginWithOtp,
              otpOnPress: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => const PhoneVerification(
                  isPatient: true,
                  isAuth: true,
                ),
              )),
            ),
          ],
        ),
      ),
    );
  }
}

void handleGoogleSignIn(BuildContext context) async {
  final userInfo = await AuthController.signInWithGoogle();

  if (userInfo == null) {
    Fluttertoast.showToast(msg: 'Something went wrong');
    return;
  }
  // Change the loading status of the overlay.
  LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(true);

  if (userInfo.uid.isNotEmpty) {
    final bool isDataAvailable =
        await LocatorService.userProvider().fetchUserData(userInfo.uid);

    if (isDataAvailable) {
      final user = LocatorService.userProvider().user;
      if (user.isBlock) {
        Fluttertoast.showToast(msg: AppStrings.blockedMsg);
        LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(false);
        return;
      }
      LocatorService.userProvider().setUserId(userInfo.uid);
      LocatorService.pushNotificationService()
          .manageNotificationsAtAuth(userId: userInfo.uid);

      await AuthController.saveCredentials(userInfo.uid, userInfo.email);
      // Change the loading status of the overlay.
      LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(false);
      Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
            builder: (context) => MainScreen(),
          ),
          (route) => false);
    } else {
      LocatorService.uiAuthProvider().changeSocialLoginLoadingStatus(false);
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => Signup(
              uid: userInfo.uid,
              email: userInfo.email,
            ),
          ));
    }
  }
}

class Logo extends StatelessWidget {
  const Logo({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
        child: SvgPicture.asset(
      'lib/assets/svg/cardiogram.svg',
      width: 200,
      height: 200,
    ));
  }
}
