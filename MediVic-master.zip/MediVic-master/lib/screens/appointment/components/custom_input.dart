import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/themes/themeGuide.dart';

class AppTextInput extends StatelessWidget {
  const AppTextInput(
    this.value,
    this.hint,
    this.function, {
    Key key,
    this.keyboardType = TextInputType.text,
  }) : super(key: key);

  final String value, hint;
  final Function function;
  final TextInputType keyboardType;

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: ClipRRect(
        borderRadius: ThemeGuide.borderRadius,
        child: TextFormField(
          cursorColor: _theme.cursorColor,
          textInputAction: TextInputAction.done,
          maxLines: 1,
          textAlignVertical: TextAlignVertical.center,
          keyboardType: keyboardType,
          onChanged: (val) => function(val),
          initialValue: value,
          style: const TextStyle(
            color: Colors.black,
            fontSize: 18,
            fontFamily: fontMontserrat,
          ),
          decoration: InputDecoration(hintText: hint ?? ''),
        ),
      ),
    );
  }
}

class CustomInput extends StatelessWidget {
  const CustomInput(
    this.number,
    this.title,
    this.isRadio, {
    this.textValue = '',
    this.radioValue = false,
    this.functionForRadio,
    this.functionForTextField,
  });

  final int number;
  final String title, textValue;
  final bool isRadio, radioValue;
  final Function functionForRadio, functionForTextField;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          '$number.) $title',
          style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              fontFamily: fontMontserrat),
        ),
        Flexible(
            child: isRadio
                ? RadioInputYesNo(radioValue, functionForRadio)
                : Padding(
                    padding: const EdgeInsets.only(top: 6, bottom: 12),
                    child: TextFormField(
                      initialValue: textValue,
                      onChanged: (val) => functionForTextField(val),
                    ),
                  )),
      ],
    );
  }
}

class RadioInputYesNo extends StatefulWidget {
  const RadioInputYesNo(this.value, this.function);

  final bool value;
  final Function function;

  @override
  RadioInputYesNoState createState() => RadioInputYesNoState();
}

class RadioInputYesNoState extends State<RadioInputYesNo> {
  bool yes;

  @override
  void initState() {
    super.initState();
    yes = widget.value;
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Flexible(
          child: RadioListTile(
            title: const Text(
              'Yes',
              style: TextStyle(fontFamily: fontMontserrat),
            ),
            onChanged: (val) {
              setState(() => yes = true);
              widget.function(true);
            },
            value: true,
            groupValue: yes,
          ),
        ),
        Flexible(
          child: RadioListTile(
            title: const Text(
              'No',
              style: TextStyle(fontFamily: fontMontserrat),
            ),
            onChanged: (val) {
              setState(() => yes = false);
              widget.function(false);
            },
            value: false,
            groupValue: yes,
          ),
        ),
      ],
    );
  }
}

class RadioInput extends StatefulWidget {
  const RadioInput(this.self, this.function);

  final bool self;
  final Function function;

  @override
  RadioInputState createState() => RadioInputState();
}

class RadioInputState extends State<RadioInput> {
  bool self = true;

  @override
  void initState() {
    super.initState();
    self = widget.self;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: [
            Radio(
              onChanged: (val) => setValue(val),
              value: true,
              groupValue: self,
            ),
            Flexible(
              child: GestureDetector(
                onTap: () => setValue(true),
                child: const Text(
                  'I am booking for myself',
                  style: TextStyle(
                    fontFamily: fontMontserrat,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
          ],
        ),
        Row(
          children: [
            Radio(
              onChanged: (val) => setValue(val),
              value: false,
              groupValue: self,
            ),
            Flexible(
              child: GestureDetector(
                onTap: () => setValue(false),
                child: const Text(
                  'I am booking on behalf of someone else (Spouse/Child/Relative)',
                  style: TextStyle(
                    fontFamily: fontMontserrat,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  void setValue(bool val) {
    if (self != val) {
      setState(() => self = val);
      widget.function(val);
    }
  }
}
