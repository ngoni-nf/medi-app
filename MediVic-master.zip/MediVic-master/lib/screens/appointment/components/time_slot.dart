import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/models/slot.dart';

class TimeSlotContainer extends StatefulWidget {
  const TimeSlotContainer(this.slots, this.function, {Key key})
      : super(key: key);

  final List<Slot> slots;
  final Function function;

  @override
  _TimeSlotContainerState createState() => _TimeSlotContainerState();
}

class _TimeSlotContainerState extends State<TimeSlotContainer> {
  Slot selectedSlot;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: widget.slots == null || widget.slots.isEmpty
          ? const Center(
              child: Text(
              'No slot available',
              style: TextStyle(fontFamily: fontMontserrat),
            ))
          : Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  width: double.maxFinite,
                  color: appBarColor,
                  child: Center(
                    child: Text(
                      'Available slots (${widget.slots.where((element) => !element.booked).length})',
                      style: const TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontFamily: fontMontserrat,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Expanded(
                  child: SingleChildScrollView(
                    child: Wrap(
                      runSpacing: 6,
                      spacing: 6,
                      alignment: WrapAlignment.spaceBetween,
                      children: widget.slots
                          .map((e) => GestureDetector(
                                child: TimeSlot(e, e.equals(selectedSlot)),
                                onTap: () {
                                  if (!e.booked) {
                                    widget.function(e);
                                    setState(() => selectedSlot = e);
                                  }
                                },
                              ))
                          .toList(),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class TimeSlot extends StatelessWidget {
  const TimeSlot(this.slot, this.isSelected, {Key key}) : super(key: key);

  final Slot slot;
  final bool isSelected;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: Text(
        slot.getInterval(),
        style: TextStyle(
          fontFeatures: const [FontFeature.tabularFigures()],
          color: (slot.booked || isSelected) ? Colors.white : Colors.black,
        ),
      ),
      decoration: BoxDecoration(
          color: slot.booked
              ? Colors.red
              : isSelected ? appBarColor : Colors.white,
          border: Border.all(
              color: slot.booked
                  ? Colors.red
                  : isSelected ? appBarColor : Colors.grey),
          borderRadius: const BorderRadius.all(Radius.circular(4))),
    );
  }
}
