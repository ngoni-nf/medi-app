import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/extensions/date_extensions.dart';

class DateContainer extends StatelessWidget {
  const DateContainer(
    this.monthDays,
    this.selectedDate,
    this.function,
  );

  final List<DateTime> monthDays;
  final DateTime selectedDate;
  final Function function;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
          children: monthDays
              .map((e) => GestureDetector(
                    onTap: () => function(e),
                    child: DateBlock(e, e.isSameDay(selectedDate)),
                  ))
              .toList()),
    );
  }
}

class DateBlock extends StatelessWidget {
  const DateBlock(this.dateTime, this.isSelected);

  final DateTime dateTime;
  final bool isSelected;

  @override
  Widget build(BuildContext context) {
    final Color textColor = isSelected ? Colors.white : Colors.black;
    return Container(
      margin: const EdgeInsets.only(right: 4),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
      decoration: BoxDecoration(
        color: isSelected ? appBarColor : Colors.white,
        border: Border.all(color: isSelected ? appBarColor : Colors.grey),
        borderRadius: const BorderRadius.all(Radius.circular(8)),
      ),
      child: Column(
        children: [
          Text(
            dateTime.formatDayOfWeek(),
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: textColor,
            ),
          ),
          Text(
            dateTime.formatDayAndMonthShort(),
            style: TextStyle(color: textColor),
          ),
          const SizedBox(height: 2),
          Text(dateTime.getSubtitle(),
              style: TextStyle(fontSize: 12, color: textColor)),
        ],
      ),
    );
  }
}
