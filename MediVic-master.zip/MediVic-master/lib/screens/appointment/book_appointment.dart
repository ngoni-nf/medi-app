import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/extensions/date_extensions.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/models/slot.dart';
import 'package:medivic/screens/appointment/components/date_container.dart';
import 'package:medivic/screens/appointment/components/time_slot.dart';
import 'package:medivic/screens/appointment/self_diagnosis_report_screen.dart';
import 'package:medivic/shared/customButton.dart';
import 'package:medivic/utils/appointment_utils.dart';

class BookAppointmentScreen extends StatefulWidget {
  const BookAppointmentScreen(this.doctor);

  final Doctor doctor;

  @override
  _BookAppointmentScreenState createState() => _BookAppointmentScreenState();
}

class _BookAppointmentScreenState extends State<BookAppointmentScreen> {
  DateTime selectedDate = DateTime.now();
  List<DateTime> monthDays;
  Slot selectedSlot;
  List<Slot> slots;

  @override
  void initState() {
    super.initState();
    _setSelectedMonth(selectedDate.year, selectedDate.month);
    _getOnlineAppointmentsForDoctor();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(context),
      body: _buildBody(),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      title: const Text(
        AppStrings.bookAppointment,
        style: styleAppbarTitle,
      ),
      backgroundColor: appBarColor,
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: const Icon(Icons.arrow_back, color: Colors.white),
      ),
    );
  }

  Widget _buildBody() {
    return slots == null
        ? const Padding(
      padding: EdgeInsets.all(16),
      child: Center(
          child: CircularProgressIndicator(backgroundColor: appBarColor)),
    )
        : Padding(
      padding: const EdgeInsets.all(8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildMonthSelector(),
          const SizedBox(height: 8),
          DateContainer(monthDays, selectedDate, _setSelectedDate),
          const SizedBox(height: 12),
          _buildTimeSlotContainer(),
          const SizedBox(height: 12),
          _buildContinueButton(),
        ],
      ),
    );
  }

  Widget _buildTimeSlotContainer() {
    final DateTime current = DateTime.now();
    final List<Slot> slotsForDay = slots
        .where((element) => element.date.isSameDay(selectedDate))
        .where((element) => element.getStartDateTime().isAfter(current))
        .toList();
    slotsForDay
        .sort((a, b) => a.getStartDateTime().compareTo(b.getStartDateTime()));
    return TimeSlotContainer(
      slotsForDay,
      _setSelectedSlot,
    );
  }

  Widget _buildContinueButton() {
    return AppButton(
      text: 'Continue',
      onPressed: () {
        if (selectedSlot == null)
          Fluttertoast.showToast(msg: 'Please select time slot.');
        else
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => SelfDiagnosisReportScreen(
                  widget.doctor,
                  selectedSlot,
                )),
          );
      },
      fontSize: 20,
      padding: 16,
    );
  }

  void _setSelectedDate(value) => setState(() => selectedDate = value);

  void _setSelectedSlot(value) => selectedSlot = value;

  Widget _buildMonthSelector() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton(
            icon: Icon(
              Icons.arrow_back_ios,
              color: _selectionIsFutureMonth()
                  ? Colors.black
                  : Colors.grey.withOpacity(0.5),
            ),
            onPressed: () =>
                _setSelectedMonth(selectedDate.year, selectedDate.month - 1)),
        const SizedBox(width: 12),
        Column(
          children: [
            Text(
              selectedDate.formatMonthName(),
              style: const TextStyle(fontSize: 18, fontFamily: fontMontserrat),
            ),
            Text(
              '${selectedDate.year}',
              style: const TextStyle(fontSize: 12, fontFamily: fontMontserrat),
            ),
          ],
        ),
        const SizedBox(width: 12),
        IconButton(
            icon: const Icon(Icons.arrow_forward_ios),
            onPressed: () =>
                _setSelectedMonth(selectedDate.year, selectedDate.month + 1)),
      ],
    );
  }

  bool _selectionIsFutureMonth() {
    final DateTime today = DateTime.now();
    return (selectedDate.year > today.year) ||
        ((selectedDate.year == today.year) && selectedDate.month > today.month);
  }

  void _setSelectedMonth(int year, int month) {
    if (month > 12) {
      year = year + 1;
      month = 1;
    } else if (month < 1) {
      year = year - 1;
      month = 12;
    }
    setState(() {
      monthDays = AppointmentUtils.getMonthDays(year, month);
      selectedDate = monthDays[0];
    });
  }

  Future<void> _getOnlineAppointmentsForDoctor() async {
    final Query query = Firestore.instance
        .collection(Slot.COLLECTION_NAME)
        .where('doctorId', isEqualTo: widget.doctor.uid);
    final List<DocumentSnapshot> documentSnapshots =
        (await query.getDocuments()).documents;
    setState(() => slots = Slot.parseList(documentSnapshots));
  }
}
