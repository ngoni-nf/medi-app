import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/extensions/date_extensions.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/models/slot.dart';
import 'package:medivic/shared/customButton.dart';

class AppointmentSummaryScreen extends StatelessWidget {
  const AppointmentSummaryScreen(
    this.doctor,
    this.slot,
  );

  final Doctor doctor;
  final Slot slot;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(context),
      body: _buildBody(context),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      title: const Text(
        'Appointment Summary',
        style: styleAppbarTitle,
      ),
      backgroundColor: appBarColor,
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: const Icon(Icons.arrow_back, color: Colors.white),
      ),
    );
  }

  Widget _buildBody(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: ListView(
              children: [
                const Padding(
                  padding: EdgeInsets.only(top: 16, bottom: 8),
                  child: Text(
                    'This is the summary of your requested booking. To confirm the appointment, please proceed with payment.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16, fontFamily: fontMontserrat),
                  ),
                ),
                _listTile('Date', slot.date.formatFullDate()),
                _listTile('Time', slot.getInterval()),
                _listTile('Doctor', doctor.name),
                _listTile('Fee', '${Config.CURRENCY} ${doctor.fee}'),
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Should you proceed with payment and make cancellation within 48 hours before your consultation is due to begin, it is NON-REFUNDABLE.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16, fontFamily: fontMontserrat),
                  ),
                ),
              ],
            ),
          ),
          AppButton(
            text: 'Proceed To Payment',
            fontSize: 20,
            padding: 16,
            onPressed: () => _proceedToPayment(context),
          )
        ],
      ),
    );
  }

  void _proceedToPayment(BuildContext context) {
    LocatorService.consultationProvider().setDoctor = doctor;
    LocatorService.consultationProvider().setAmount = doctor.fee;
    LocatorService.consultationProvider().setTitle =
        '${doctor.name}, ${slot.date.formatFullDate()} ${slot.getInterval()}';
    LocatorService.consultationProvider().setSlot = slot;
    NavigationController.navigator.pushNamed(Routes.paymentWebview);
  }

  Widget _listTile(String title, String subtitle) {
    return ListTile(
      title: Text(
        subtitle,
        style: const TextStyle(fontFamily: fontMontserrat),
      ),
      subtitle: Text(
        title,
        style: const TextStyle(fontFamily: fontMontserrat),
      ),
    );
  }
}
