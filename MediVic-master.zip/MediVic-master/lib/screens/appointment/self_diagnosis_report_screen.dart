import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/models/slot.dart';
import 'package:medivic/models/userModel.dart';
import 'package:medivic/screens/appointment/components/custom_input.dart';
import 'package:medivic/shared/customButton.dart';

import 'appointment_summary_screen.dart';

class SelfDiagnosisReportScreen extends StatefulWidget {
  const SelfDiagnosisReportScreen(
    this.doctor,
    this.appointmentSlot,
  );

  final Doctor doctor;
  final Slot appointmentSlot;

  @override
  _SelfDiagnosisReportScreenState createState() =>
      _SelfDiagnosisReportScreenState();
}

class _SelfDiagnosisReportScreenState extends State<SelfDiagnosisReportScreen> {
  bool isBookingForSelf = true, completeSelfDiagnosisReport = false;
  String fullName,
      rsaIdentityNumber,
      contactNumber,
      purposeOfVisit,
      emailAddress,
      officeHomeNumber;
  bool runningOnFever = false,
      haveDryCough = false,
      haveSevereBodyPain = false,
      feelVeryTired = false,
      haveDiarrhea = false,
      lackOfTasteOrSmell = false,
      acuteAbdominalPain = false,
      savingData = false;
  String bodyTemperature, pulseRate;

  @override
  void initState() {
    super.initState();
    final User user = LocatorService.userProvider().user;
    if (user != null) {
      fullName = user.name;
      contactNumber = user.phoneNumber;
      emailAddress = user.email;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(context),
      body: _buildBody(),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      title: const Text(
        'Self Diagnosis Report',
        style: styleAppbarTitle,
      ),
      backgroundColor: appBarColor,
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: const Icon(Icons.arrow_back, color: Colors.white),
      ),
    );
  }

  Widget _buildBody() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: ListView(
        children: [
          RadioInput(
            isBookingForSelf,
            (val) => setState(() => isBookingForSelf = val),
          ),
          const SizedBox(height: 20),
          const Text(
            'Basic Details',
            style: TextStyle(fontFamily: fontMontserrat),
          ),
          AppTextInput(
            fullName,
            'Full Name',
            (val) => setState(() => fullName = val),
          ),
          AppTextInput(
            rsaIdentityNumber,
            'RSA Identity Number',
            (val) => setState(() => rsaIdentityNumber = val),
          ),
          AppTextInput(
            contactNumber,
            'Contact Number',
            (val) => setState(() => contactNumber = val),
            keyboardType: TextInputType.phone,
          ),
          AppTextInput(
            purposeOfVisit,
            'Purpose Of Visit',
            (val) => setState(() => purposeOfVisit = val),
          ),
          AppTextInput(
            emailAddress,
            'Email Address',
            (val) => setState(() => emailAddress = val),
            keyboardType: TextInputType.emailAddress,
          ),
          AppTextInput(
            officeHomeNumber,
            'Office/Home no.',
            (val) => setState(() => officeHomeNumber = val),
          ),
          const SizedBox(height: 16),
          const Text('OPTIONAL:',
              style: TextStyle(
                fontFamily: fontMontserrat,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              )),
          const SizedBox(height: 16),
          Row(
            children: [
              Checkbox(
                value: completeSelfDiagnosisReport,
                onChanged: (val) =>
                    setState(() => completeSelfDiagnosisReport = val),
              ),
              Flexible(
                child: GestureDetector(
                  onTap: () => setState(() => completeSelfDiagnosisReport =
                      !completeSelfDiagnosisReport),
                  child: const Text(
                      'I would like to save time and complete the self diagnosis report now.',
                      style: TextStyle(
                        fontFamily: fontMontserrat,
                        fontSize: 16,
                      )),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildSelfDiagnosisForm(),
          _buildContinueButton(),
        ],
      ),
    );
  }

  Widget _buildSelfDiagnosisForm() {
    if (!completeSelfDiagnosisReport) {
      return Container();
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Self Diagnosis Report',
          style: TextStyle(fontFamily: fontMontserrat),
        ),
        const SizedBox(height: 8),
        CustomInput(
          1,
          'Are you running on fever?',
          true,
          radioValue: runningOnFever,
          functionForRadio: (val) => setState(() => runningOnFever = val),
        ),
        CustomInput(
          2,
          'Enter your body temperature',
          false,
          textValue: bodyTemperature,
          functionForTextField: (val) => setState(() => bodyTemperature = val),
        ),
        CustomInput(
          3,
          'Enter your pulse rate',
          false,
          textValue: pulseRate,
          functionForTextField: (val) => setState(() => pulseRate = val),
        ),
        CustomInput(
          4,
          'Do you have dry cough?',
          true,
          radioValue: haveDryCough,
          functionForRadio: (val) => setState(() => haveDryCough = val),
        ),
        CustomInput(
          5,
          'Do you have severe body pain?',
          true,
          radioValue: haveSevereBodyPain,
          functionForRadio: (val) => setState(() => haveSevereBodyPain = val),
        ),
        CustomInput(
          6,
          'Do you feel very tired?',
          true,
          radioValue: feelVeryTired,
          functionForRadio: (val) => setState(() => feelVeryTired = val),
        ),
        CustomInput(
          7,
          'Do you have diarrhea?',
          true,
          radioValue: haveDiarrhea,
          functionForRadio: (val) => setState(() => haveDiarrhea = val),
        ),
        CustomInput(
          8,
          'Do you feel lack of taste or smell?',
          true,
          radioValue: lackOfTasteOrSmell,
          functionForRadio: (val) => setState(() => lackOfTasteOrSmell = val),
        ),
        CustomInput(
          9,
          'Do you feel acute abdominal pain?',
          true,
          radioValue: acuteAbdominalPain,
          functionForRadio: (val) => setState(() => acuteAbdominalPain = val),
        ),
      ],
    );
  }

  Widget _buildContinueButton() {
    return Container(
      margin: const EdgeInsets.only(top: 24, bottom: 12),
      child: ProgressButton(
        'Continue',
        () => _saveSelfDiagnosisReport(),
        savingData,
        'Saving Data',
      ),
    );
  }

  void _saveSelfDiagnosisReport() {
    final report = {
      'bookingForSelf': isBookingForSelf,
      'fullName': fullName,
      'rsaIdentifyNumber': rsaIdentityNumber,
      'contactNumber': contactNumber,
      'purposeOfVisit': purposeOfVisit,
      'emailAddress': emailAddress,
      'officeHomeNumber': officeHomeNumber,
      'completeSelfDiagnosisReport': completeSelfDiagnosisReport,
      'runningOnFever': runningOnFever,
      'bodyTemperature': bodyTemperature,
      'pulseRate': pulseRate,
      'dryCough': haveDryCough,
      'severeBodyPain': haveSevereBodyPain,
      'veryTired': feelVeryTired,
      'diarrhea': haveDiarrhea,
      'lackOfTasteOrSmell': lackOfTasteOrSmell,
      'acuteAbdominalPain': acuteAbdominalPain,
    };
    setState(() => savingData = true);
    Firestore.instance.collection('selfDiagnosisReports').add(report).then(
      (value) {
        LocatorService.consultationProvider().selfDiagnosisReportDocumentId =
            value.documentID;
        setState(() => savingData = false);
        _navigateToAppointmentSummaryScreen();
      },
    ).catchError((err) => setState(() => savingData = false));
  }

  void _navigateToAppointmentSummaryScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AppointmentSummaryScreen(
          widget.doctor,
          widget.appointmentSlot,
        ),
      ),
    );
  }
}
