import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/extensions/date_extensions.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/appointment.dart';
import 'package:medivic/models/appointment_status.dart';
import 'package:medivic/models/notification.dart';
import 'package:medivic/models/slot.dart';
import 'package:medivic/screens/call/agora/video_call.dart';
import 'package:medivic/screens/home/drawer_patient.dart';
import 'package:medivic/screens/notification/notification.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/shared/customButton.dart';
import 'package:medivic/shared/rating_dialog.dart';

class PatientAppointmentListScreen extends StatefulWidget {
  const PatientAppointmentListScreen({Key key}) : super(key: key);

  @override
  _PatientAppointmentListScreenState createState() => _PatientAppointmentListScreenState();
}

class _PatientAppointmentListScreenState extends State<PatientAppointmentListScreen> {
  bool loading = false;
  List<Appointment> appointments = [];

  @override
  void initState() {
    super.initState();
    _fetchOnlineAppointments();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        floatingActionButton: _buildFloatingActionButton(),
        appBar: _buildAppBar(context),
        body: _buildBody(context),
        endDrawer: DrawerPatient(),
      ),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      iconTheme: const IconThemeData(color: Colors.white),
      title: const Text(
        AppStrings.appointmentsTitle,
        style: styleAppbarTitle,
      ),
      backgroundColor: appBarColor,
      leading: IconButton(
        icon: const Icon(Icons.notifications, color: Colors.white, size: 30.0),
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => NotificationScreen(),
              ));
        },
      ),
    );
  }

  FloatingActionButton _buildFloatingActionButton() {
    return FloatingActionButton(
      backgroundColor: darkBlueColor,
      child: const Icon(Icons.add, size: 32.0),
      onPressed: () => NavigationController.navigator.pushNamed(Routes.doctorsList),
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.all(8),
      child: TabBar(
        isScrollable: true,
        unselectedLabelColor: Colors.black,
        indicatorSize: TabBarIndicatorSize.label,
        indicator: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          color: darkBlueColor,
        ),
        tabs: [
          _buildTab(AppStrings.notifications),
          _buildTab(AppStrings.previousTab),
          _buildTab(AppStrings.scheduledTab),
        ],
      ),
      decoration: BoxDecoration(
          color: Colors.transparent,
          border: Border.all(color: Colors.grey.withOpacity(0.2), width: 2),
          borderRadius: const BorderRadius.all(Radius.circular(28))),
    );
  }

  Tab _buildTab(String text) {
    return Tab(
      child: Container(
        padding: const EdgeInsets.only(left: 10, right: 10),
        child: Align(
          alignment: Alignment.center,
          child: Text(
            text,
            style: const TextStyle(fontFamily: fontMontserrat, fontSize: 12),
          ),
        ),
      ),
    );
  }

  TabBarView _buildTabBarView() {
    return TabBarView(
      children: [
        _buildNotification(),
        _buildAppointmentList(_filterAppointmentsByStatus(true), 1),
        _buildAppointmentList(_filterAppointmentsByStatus(false), 2),
      ],
    );
  }

  Widget _buildBody(BuildContext context) {
    return Column(
      children: [
        _buildTabBar(),
        Expanded(
          child: loading ? _buildProgressWidget() : (appointments.isEmpty ? _buildNoAppointmentsLabel(0) : _buildTabBarView()),
        ),
      ],
    );
  }

  Widget _buildAppointmentList(List<Appointment> appointments, int selectedTabIndex) {
    return appointments.isNotEmpty
        ? ListView.builder(
            itemCount: appointments.length,
            itemBuilder: (context, index) => _buildAppointmentListItem(context, appointments[index], selectedTabIndex))
        : _buildNoAppointmentsLabel(selectedTabIndex);
  }

  void _rating(Appointment appointment) async {
    bool isAllowed = await showDialog(
        context: context,
        builder: (context) => AlertDialog(
              backgroundColor: Colors.white,
              title: const Text(
                'Confirmation',
                style: TextStyle(fontFamily: fontMontserrat),
              ),
              content: Text(
                'Do you want to rate ${appointment.doctorName}?',
                style: const TextStyle(fontFamily: fontMontserrat),
              ),
              actions: [
                FlatButton(
                  onPressed: () {
                    Navigator.pop(context, true);
                  },
                  child: const Text(
                    'YES',
                    style: TextStyle(fontFamily: fontMontserrat),
                  ),
                ),
                FlatButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text(
                    'NO',
                    style: TextStyle(fontFamily: fontMontserrat),
                  ),
                ),
              ],
            ));
    if (isAllowed != null && isAllowed) {
      bool isRated = false;
      await FirestoreService.getRating(LocatorService.userProvider().user.uid, appointment.doctorId)
          .then((value) {
            if (value != null) isRated = true;
          })
          .timeout(const Duration(seconds: 30))
          .catchError((error) {});
      if (!isRated) {
        await showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => RatingDialog(
            doctorId: appointment.doctorId,
          ),
        );
      } else {
        Fluttertoast.showToast(msg: 'You have already rated this doctor');
      }
    }
  }

  Widget _buildAppointmentListItem(BuildContext context, Appointment appointment, int selectedTabIndex) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: InkWell(
          onTap: () {
            if (selectedTabIndex == 1) _rating(appointment);
          },
          child: Column(
            children: [
              Row(
                children: [
                  ClipOval(
                    child: CachedNetworkImage(
                      imageUrl: appointment.doctorImageUrl ?? 'https://via.placeholder.com/100',
                      width: 64,
                      height: 64,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        appointment.doctorName,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, fontFamily: fontMontserrat),
                      ),
                      Text(
                        'Date : ${appointment.date.formatFullDate()}',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                          fontFamily: fontMontserrat,
                        ),
                      ),
                      Text(
                        'Time : ${appointment.getInterval()}',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                          fontFamily: fontMontserrat,
                        ),
                      ),
                      _buildControls(context, appointment),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNotification() {
    final String userId = LocatorService.userProvider().user?.uid ?? LocatorService.doctorProvider().doctor.uid;
    final bool isPatient = LocatorService.userProvider().user != null;
    return StreamBuilder<QuerySnapshot>(
        stream: Firestore.instance
            .collection('notifications')
            .where('userId', isEqualTo: userId)
            .where('isPatient', isEqualTo: isPatient)
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          final List<InAppNotification> notifications = InAppNotification.parseList(snapshot);
          return notifications.isNotEmpty ? _buildListView(notifications) : _buildNoNotificationsLabel();
        });
  }

  Widget _buildListView(List<InAppNotification> notifications) {
    return ListView.builder(
        itemCount: notifications.length,
        itemBuilder: (context, index) => NotificationContainer(
              notifications[index],
              isClickable: false,
            ));
  }

  Widget _buildNoNotificationsLabel() {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Text(
          'You currently have no new notifications.',
          style: TextStyle(fontFamily: fontMontserrat),
        ),
      ),
    );
  }

  Widget _buildNoAppointmentsLabel(int selectedTabIndex) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Text(
          'You have no ${selectedTabIndex == 1 ? 'completed' : 'upcoming'}  sessions',
          style: const TextStyle(
            color: Colors.grey,
            fontFamily: fontMontserrat,
          ),
        ),
      ),
    );
  }

  Widget _buildControls(BuildContext context, Appointment appointment) {
    final List<Widget> controls = [];
    if (!appointment.sessionEnded()) {
      controls.add(AppButton(
        text: 'Join',
        // onPressed: () => VonageVideoCall.start(context, appointment),
        onPressed: () => VideoCallScreen.start(context, appointment),
        bgColor: appBarColor,
        fontSize: 10,
      ));
    }
    if (appointment.isCancellable()) {
      controls.add(AppButton(
        text: 'Cancel',
        onPressed: () {
          showCancelConfirmation(context, appointment).then(
            (value) async {
              if (value != null && value) {
                _cancelAppointment(appointment);
              }
            },
          );
        },
        bgColor: Colors.red,
        fontSize: 10,
      ));
    }
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      direction: Axis.horizontal,
      children: controls,
    );
  }

  Future<bool> showCancelConfirmation(
    BuildContext context,
    Appointment appointment,
  ) {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          title: const Text('Cancel Appointment'),
          content: Text('Would you like to cancel appointment with ${appointment.doctorName}?'),
          actions: [
            FlatButton(
              child: const Text('Cancel Appointment'),
              onPressed: () => Navigator.of(context).pop(true),
            ),
            FlatButton(
              child: const Text('Close'),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        );
      },
    );
  }

  Widget _buildProgressWidget() {
    return const Center(child: CircularProgressIndicator(backgroundColor: appBarColor));
  }

  Future<void> _fetchOnlineAppointments() async {
    if (mounted) {
      setState(() => loading = true);
    }

    final QuerySnapshot querySnapshot = await Firestore.instance
        .collection(Appointment.COLLECTION_NAME)
        .where('userId', isEqualTo: LocatorService.userProvider().user.uid)
        .getDocuments();
    if (mounted) {
      setState(() {
        loading = false;
        appointments = Appointment.parseList(querySnapshot.documents);
      });
    }
  }

  List<Appointment> _filterAppointmentsByStatus(bool past) {
    return appointments.where((element) => (past == element.sessionEnded()) && element.status != AppointmentStatus.CANCELLED).toList();
  }

  Future<void> _cancelAppointment(Appointment appointment) async {
    setState(() => loading = true);
    try {
      await Firestore.instance.collection(Appointment.COLLECTION_NAME).document(appointment.id).updateData({
        'status': AppointmentStatus.CANCELLED,
        'cancelledByPatient': true,
      });
      await Firestore.instance.collection(Slot.COLLECTION_NAME).document(appointment.slotId).updateData({'booked': false});
      _fetchOnlineAppointments();
    } catch (e) {
      setState(() => loading = false);
      Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
    }
  }
}
