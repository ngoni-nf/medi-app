// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/addressModel.dart';
import 'package:medivic/models/mAddress.dart';
import 'package:medivic/models/userModel.dart';
import 'package:medivic/screens/accountInfo/myDocuments.dart';
import 'package:medivic/screens/gooogleMap/googleMap.dart';
import 'package:medivic/services/api/firebaseStorageService.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/services/imageService/imageService.dart';
import 'package:medivic/shared/authScreenWidgets/authSreenWidgets.dart';
import 'package:medivic/shared/widgets/customTextField.dart';
import 'package:medivic/themes/themeGuide.dart';

class EditProfile extends StatelessWidget {
  const EditProfile({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        title: const Text(
          AppStrings.editProfile,
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
      ),
      body: const Padding(
        padding: ThemeGuide.padding20,
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: EditProfileForm(),
        ),
      ),
    );
  }
}

class EditProfileForm extends StatefulWidget {
  const EditProfileForm({Key key}) : super(key: key);

  @override
  _EditProfileFormState createState() => _EditProfileFormState();
}

class _EditProfileFormState extends State<EditProfileForm> {
  User user = LocatorService.userProvider().user;

  String dob =
      DateFormat('dd/MM/yyyy').format(LocatorService.userProvider().user.dob);

  final dateFormat = DateFormat('dd/MM/yyyy');

  final GlobalKey _formKey = GlobalKey<FormState>();
  bool isLoading = false;

  DateTime selectedDate = DateTime(2000, 1);

  TextEditingController controllerAge = TextEditingController();

  MAddress mAddress;

  final dateMaskFormatter = MaskTextInputFormatter(
    mask: '##-##-####',
    filter: {
      '#': RegExp(r'[0-9]'),
    },
  );

  final gendreDropdownList = [
    const DropdownMenuItem(
        child: Text(
          'Male',
          style: TextStyle(fontFamily: fontMontserrat),
        ),
        value: 'Male'),
    const DropdownMenuItem(
        child: Text(
          'Female',
          style: TextStyle(fontFamily: fontMontserrat),
        ),
        value: 'Female'),
    const DropdownMenuItem(
        child: Text(
          'Prefer Not To Say',
          style: TextStyle(fontFamily: fontMontserrat),
        ),
        value: 'Prefer Not To Say'),
  ];

  @override
  void initState() {
    super.initState();
    controllerAge.text = user.age;
    if (dob != null && dob.isNotEmpty) selectedDate = dateFormat.parse(dob);
  }

  void _showDatePicker() async {
    DateTime d = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(1940, 1),
      lastDate: DateTime.now().subtract(const Duration(days: 365 * 16)),
      builder: (BuildContext context, Widget child) {
        return Theme(
          data: ThemeData.light().copyWith(
              //OK/Cancel button text color
              primaryColor: appBarColor, //Head background
              accentColor: appBarColor //selection color
              //dialogBackgroundColor: Colors.white,//Background color
              ),
          child: child,
        );
      },
    );
    if (d != null)
      setState(() {
        selectedDate = d;
        dob = dateFormat.format(selectedDate);
        Duration duration = DateTime.now().difference(selectedDate);
        user.age = (duration.inDays / 365).floor().toString();
        controllerAge.text = user.age;
      });
  }

  Future<void> _pickAddressFromMap(BuildContext context) async {
    mAddress = await Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => const GoogleMapScreen(
        isLock: false,
      ),
    ));

    if (mAddress != null)
      setState(() => user.address = PatientAddress.fromPickNew(
          mAddress.address, mAddress.lat, mAddress.lng));
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Form(
        key: _formKey,
        child: Column(
          children: <Widget>[
            PhotoUpdate(),
            CustomTextField(
              data: user.name,
              lableText: AppStrings.firstNameLabel,
              iconData: Icons.perm_identity,
              validator: validateName,
              onChange: (value) => user.name = value,
            ),

            // TextFormField(
            //   keyboardType: TextInputType.phone,
            // ),
            CustomTextField(
              data: user.phoneNumber,
              isEnable: false,
              lableText: AppStrings.phoneNumber,
              iconData: Icons.call,
              keyboardType: TextInputType.phone,
              onChange: (val) => user.phoneNumber = val,
            ),
            InkWell(
              onTap: () {
                _showDatePicker();
              },
              child: Container(
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.only(top: 10),
                width: double.maxFinite,
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(10)),
                  color: Colors.grey[200],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Date of Birth',
                      style: TextStyle(
                          fontFamily: fontMontserrat,
                          color: Colors.grey,
                          fontSize: 12),
                    ),
                    const SizedBox(
                      height: 2,
                    ),
                    Text(
                      dob ?? 'Date of Birth',
                      style: const TextStyle(
                          fontFamily: fontMontserrat, fontSize: 16),
                    ),
                  ],
                ),
              ),
            ),
            CustomTextField(
              controller: controllerAge,
              lableText: AppStrings.age,
              iconData: Icons.perm_contact_calendar,
              keyboardType: TextInputType.number,
              validator: validateAge,
              onChange: (val) => user.age = val,
              inputFormatters: [WhitelistingTextInputFormatter.digitsOnly],
            ),
            CustomTextField(
              data: user.id,
              lableText: AppStrings.nationalIdNumberLabel,
              iconData: Icons.edit,
              keyboardType: TextInputType.number,
              // validator: validateNationalID,
              onChange: (val) => user.id = val,
            ),
            const SizedBox(height: 10),
            GestureDetector(
              child: Container(
                  width: double.maxFinite,
                  padding:
                      const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.1),
                    borderRadius: const BorderRadius.all(Radius.circular(6)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Location',
                        style: TextStyle(
                            fontFamily: fontMontserrat,
                            fontSize: 12,
                            color: Colors.grey),
                      ),
                      const SizedBox(height: 2),
                      if (user.address != null &&
                          user.address.address != null &&
                          user.address.address.isNotEmpty)
                        Text(
                          user.address.address,
                          style: const TextStyle(
                              color: Colors.black,
                              fontSize: 16,
                              fontFamily: fontMontserrat),
                        )
                      else
                        const Text(
                          'Pick Location',
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 16,
                              fontFamily: fontMontserrat),
                        )
                    ],
                  )),
              onTap: () => _pickAddressFromMap(context),
            ),
            const SizedBox(height: 10),
            Container(
              width: double.maxFinite,
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
              decoration: BoxDecoration(
                color: Colors.grey.withOpacity(0.1),
                borderRadius: const BorderRadius.all(Radius.circular(6)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Gender',
                    style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                        fontFamily: fontMontserrat),
                  ),
                  DropdownButtonFormField(
                    value: user.gender != null && user.gender.isNotEmpty
                        ? user.gender
                        : 'Male',
                    items: gendreDropdownList,
                    onChanged: setGenderValue,
                  ),
                ],
              ),
            ),

            const SizedBox(
              height: 10,
            ),
            CustomTextField(
              data: user.nextOfKinName,
              lableText: AppStrings.nextOfKin,
              iconData: Icons.edit,
              keyboardType: TextInputType.text,
              // validator: validateNationalID,
              onChange: (val) => user.nextOfKinName = val,
            ),
            const SizedBox(height: 10),
            CustomTextField(
              data: user.nextOfKinRelationship,
              lableText: AppStrings.nextOfKinRelation,
              iconData: Icons.edit,
              keyboardType: TextInputType.text,
              // validator: validateNationalID,
              onChange: (val) => user.nextOfKinRelationship = val,
            ),
            const SizedBox(height: 20),
            Container(
              height: 40,
              width: double.maxFinite,
              child: RaisedButton(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30)),
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MyDocuments(),
                    )),
                child: const Text(
                  'My Documents',
                  style: TextStyle(
                      fontFamily: fontMontserrat,
                      color: Colors.white,
                      fontSize: 18),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Container(
              height: 100,
              child: Center(
                child: Submit(
                  color: appBarColor,
                  onPress: () => saveChanges(),
                  isLoading: isLoading,
                  lable: AppStrings.save,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Save the changes to the firestore, when the update is complete, sava the changes
  /// in the local storage as well.
  Future<void> saveChanges() async {
    if (validateForm(_formKey)) {
      setState(() {
        isLoading = true;
      });
      await FirestoreService.updateUserData(user.toJson());
      LocatorService.userProvider().updateUserData(user);
      setState(() {
        isLoading = false;
      });
      NavigationController.navigator.pop();
    }
  }

  static bool validateForm(GlobalKey<FormState> formKey) {
    if (formKey.currentState.validate()) {
      return true;
    } else {
      return false;
    }
  }

  String validateName(val) {
    if (val.toString().length < 3) {
      return AppStrings.errorShortName;
    }
    return null;
  }

  String validateAge(val) {
    if (val == null || val == '') {
      return null;
    }
    if (int.parse(val) > 100) {
      return AppStrings.errorAgeInvalid;
    }
    return null;
  }

  String validateNationalID(val) {
    if (val == null || val == '') {
      return AppStrings.nationalIdInvalid;
    }
    return null;
  }

  String validatePhoneNumber(val) {
    if (val == null || val == '') {
      return null;
    }
    if (val.toString().length > 13 || val.toString().length < 7) {
      return AppStrings.errorNumberInvalid;
    }
    if (!val.toString().contains("+27")) {
      return AppStrings.invalidatePhonestartEmpty;
    } else {
      return null;
    }
  }

  String validateDob(val) {
    if (val == null || val == '') {
      return null;
    }

    if (dob.isNotEmpty && dob.toString().length == 10) {
      return null;
    }

    final date = dateMaskFormatter.getUnmaskedText();
    if (date.toString().length != 8) {
      return AppStrings.errorInvalidDob;
    } else {
      return null;
    }
  }

  void setGenderValue(String val) {
    setState(() {
      user.gender = val;
    });
  }
}

///
/// ## `Description`
///
/// PhotoUpdate handler
///
class PhotoUpdate extends StatefulWidget {
  @override
  _PhotoUpdateState createState() => _PhotoUpdateState();
}

class _PhotoUpdateState extends State<PhotoUpdate> {
  bool isLoading = false;
  String url = LocatorService.userProvider().user.imageUrl;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 120,
      height: 120,
      child: Stack(
        children: <Widget>[
          InkWell(
            onTap: () {
              uploadPhoto();
            },
            child: CachedNetworkImage(
              imageUrl: url,
              placeholder: (context, url) => const Center(
                child: CircularProgressIndicator(
                  backgroundColor: appBarColor,
                ),
              ),
              imageBuilder: (context, imageProvider) => Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image:
                      DecorationImage(image: imageProvider, fit: BoxFit.fill),
                ),
              ),
            ),
          ),
          if (isLoading)
            const Center(
              child: CircularProgressIndicator(
                backgroundColor: appBarColor,
              ),
            ),
        ],
      ),
    );
  }

  Future<void> uploadPhoto() async {
    // Wait to get the file path.
    final imageFile = await ImageService.getImage();

    // If the file value is not null proceed
    if (imageFile != null) {
      setState(() {
        isLoading = true;
      });

      // get the user id
      final userId = LocatorService.userProvider().user.uid;

      if (userId != null && userId != '') {
        // start uploading
        final newUrl = await FirebaseStorageService.uploadFile(
          imageFile,
          fileName: userId,
        );

        // check for upload status
        if (newUrl != null) {
          // update the database
          await FirestoreService.updateImageUrl(newUrl);
          LocatorService.userProvider().updateImage(newUrl);

          setState(() {
            url = newUrl;
            isLoading = false;
          });
        } else {
          setState(() {
            isLoading = false;
          });
        }
      } else {
        setState(() {
          isLoading = false;
        });
      }
    }
  }
}
