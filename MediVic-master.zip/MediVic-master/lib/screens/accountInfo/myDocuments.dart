import 'package:advance_pdf_viewer/advance_pdf_viewer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:medivic/const.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/documentModel.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/shared/dialogAddDocument.dart';
import 'package:medivic/utils/utils.dart';

class MyDocuments extends StatefulWidget {
  @override
  _ViewPrescriptionState createState() => _ViewPrescriptionState();
}

class _ViewPrescriptionState extends State<MyDocuments> {
  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  List<Document> documents = [];
  bool isLoading = false;
  PickedFile pickedFile;
  bool isDoctorVisibility = false;

  @override
  void initState() {
    super.initState();
    isDoctorVisibility = LocatorService.userProvider().user.docsVisibility;
    getDocuments();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: appBarColor,
        title: const Text(
          'My Documents',
          style: styleAppbarTitle,
        ),
      ),
      body: buildBody(),
      floatingActionButton: FloatingActionButton(
        backgroundColor: darkBlueColor,
        onPressed: () async {
          bool isAdded = await showDialog(
            context: context,
            builder: (context) => DialogAddDocument(),
          );
          if (isAdded != null && isAdded) {
            getDocuments();
          }
        },
        child: Icon(Icons.add),
      ),
    );
  }

  Widget buildBody() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Row(
            children: [
              const Text(
                'Practitioner visibility ',
                style: TextStyle(fontFamily: fontMontserrat),
              ),
              Switch(
                value: isDoctorVisibility,
                onChanged: (value) {
                  setState(() {
                    isDoctorVisibility = value;
                  });
                  FirestoreService.documentsVisibility(LocatorService.userProvider().user.uid, isDoctorVisibility);
                },
              ),
            ],
          ),
          if (documents.isNotEmpty)
            Expanded(
              child: ListView.builder(
                itemCount: documents.length,
                itemBuilder: (context, index) {
                  Document document = documents[index];
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: InkWell(
                        onTap: () async {
                          if (document.fileUrl.contains('png') || document.fileUrl.contains('jpeg') || document.fileUrl.contains('jpg')) {
                            final bytes = await Utils.imageDownload(document.fileUrl);
                            print('byte: $bytes');
                            _scaffoldKey.currentState.showSnackBar(SnackBar(
                              backgroundColor: Colors.white,
                              content: Image.memory(
                                bytes,
                                fit: BoxFit.fill,
                              ),
                            ));
                          } else {
                            if (document.fileUrl.contains('pdf')) {
                              PDFDocument doc = await PDFDocument.fromURL(document.fileUrl);
                              _scaffoldKey.currentState.showSnackBar(SnackBar(
                                backgroundColor: Colors.white,
                                duration: Duration(minutes: 1),
                                content: PDFViewer(document: doc),
                              ));
                            }
                          }
                        },
                        child: Row(
                          children: [
                            if (document.fileUrl.contains('png') || document.fileUrl.contains('jpg') || document.fileUrl.contains('jpeg'))
                              CachedNetworkImage(
                                imageUrl: document.fileUrl,
                                width: 50,
                                height: 50,
                                placeholder: (context, url) => Image.asset('lib/assets/images/img_not_available.jpeg'),
                              )
                            else
                              Image.asset(
                                'lib/assets/images/pdf.png',
                                width: 50,
                              ),
                            const SizedBox(
                              width: 10,
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    document.fileName,
                                    style: const TextStyle(fontFamily: fontMontserrat),
                                  ),
                                  Text(
                                    'Date: ${Utils.getDateStr(document.createdAt)}',
                                    style: const TextStyle(fontFamily: fontMontserrat, color: Colors.grey, fontSize: 10),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: const Icon(
                                Icons.remove_circle_outline,
                                color: Colors.red,
                              ),
                              onPressed: () {
                                _confirmationDialog(document);
                              },
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            )
          else
            const Center(
              child: Text(
                'No documents uploaded yet!',
                style: TextStyle(fontFamily: fontMontserrat),
              ),
            ),
          if (isLoading)
            const Center(
                child: CircularProgressIndicator(
              backgroundColor: appBarColor,
            )),
        ],
      ),
    );
  }

  Future<void> _confirmationDialog(Document document) async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          content: SingleChildScrollView(
            child: Center(
              child: Text(
                'Do you really want to delete ${document.fileName}',
                textAlign: TextAlign.center,
              ),
            ),
          ),
          actions: <Widget>[
            FlatButton(
              child: const Text('No'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            FlatButton(
              child: const Text('Yes'),
              onPressed: () {
                Navigator.of(context).pop();
                _deleteDocument(document);
              },
            ),
          ],
        );
      },
    );
  }

  void _deleteDocument(Document document) async {
    final result = await FirestoreService.deleteDocument(LocatorService.userProvider().user.uid, document);
    if (result) {
      Fluttertoast.showToast(msg: 'File deleted successfully');
      setState(() {
        documents.remove(document);
      });
    }
  }

  void getDocuments() async {
    setState(() {
      isLoading = true;
    });
    documents = await FirestoreService.getDocuments(LocatorService.userProvider().user.uid);
    if (documents != null) {
      setState(() {
        isLoading = false;
      });
    }
  }
}
