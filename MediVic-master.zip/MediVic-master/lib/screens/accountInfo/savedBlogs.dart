// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/providers/savedBlogsProvider.dart';
import 'package:medivic/providers/widgets/viewStateSelector.dart';
import 'package:medivic/screens/blogs/blogScreen.dart';
import 'package:provider/provider.dart';

class SavedBlogs extends StatelessWidget {
  const SavedBlogs({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        title: const Text(
          AppStrings.savedBlogs,
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
      ),
      body: ChangeNotifierProvider.value(
        value: LocatorService.savedBlogsProvider(),
        child: ViewStateSelector<SavedBlogsProvider>(
          getData: () => locator<SavedBlogsProvider>().fetchData(),
          child: Selector<SavedBlogsProvider, List>(
            selector: (context, d) => d.blogsList,
            builder: (context, list, _) {
              return ListView.builder(
                itemCount: list.length,
                itemBuilder: (context, i) {
                  return GestureDetector(
                    onTap: () => NavigationController.navigator.pushNamed(
                      Routes.blogPost,
                      arguments: BlogPostArguments(blog: list[i]),
                    ),
                    child: BlogListItem(
                      blog: list[i],
                    ),
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
