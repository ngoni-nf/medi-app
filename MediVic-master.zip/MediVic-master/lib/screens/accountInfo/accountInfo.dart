// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/providers/userProvider.dart';
import 'package:medivic/routes/router.gr.dart';
import 'package:medivic/screens/appointment/patient_appointments.dart';
import 'package:medivic/screens/home/drawer_patient.dart';
import 'package:medivic/screens/notification/notification.dart';
import 'package:provider/provider.dart';

///
/// ## `Description`
///
/// Screen to render Account info of the user.
/// Will work well when used with `username` or `id`
/// for the network request.
///
class AccountInfo extends StatefulWidget {
  const AccountInfo({Key key}) : super(key: key);

  @override
  _AccountInfoState createState() => _AccountInfoState();
}

class _AccountInfoState extends State<AccountInfo> {
  @override
  Widget build(BuildContext context) {
    final GlobalKey<ScaffoldState> _drawerKey = GlobalKey();
    return Scaffold(
      key: _drawerKey,
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        leading: IconButton(
          icon: Image.asset('assets/notification.png', height: 24),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => NotificationScreen()),
          ),
        ),
        title: const Text(
          AppStrings.accountInfo,
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
        actions: [
          IconButton(
            icon: const Icon(
              Icons.menu,
              size: 28,
              color: Colors.white,
            ),
            onPressed: () => _drawerKey.currentState.openEndDrawer(),
          ),
        ],
      ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        color: Colors.white,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Center(
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ClipOval(
                        child: CachedNetworkImage(
                            placeholder: (context, url) => const Center(
                                  child: CircularProgressIndicator(
                                    backgroundColor: appBarColor,
                                  ),
                                ),
                            fit: BoxFit.cover,
                            width: 230,
                            height: 230,
                            imageUrl: context.watch<UserProvider>().user.imageUrl),
                      ),
                    ),
                    Text(
                      context.watch<UserProvider>().user.name,
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 20.0, fontFamily: fontMontserrat),
                    ),
                    Text(
                      context.watch<UserProvider>().user.email,
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14.0, color: Colors.black38, fontFamily: fontMontserrat),
                    ),
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 20, bottom: 10),
                child: Divider(
                  color: Colors.black12,
                  height: 2.0,
                  thickness: 1.5,
                  indent: 20,
                  endIndent: 20,
                ),
              ),
              buildListTile(
                title: AppStrings.editProfile,
                onTap: () => NavigationController.navigator.pushNamed(Routes.editProfile),
              ),
              buildListTile(
                  title: 'My Sessions',
                  // onTap: () => NavigationController.navigator
                  //     .pushNamed(Routes.appointments),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const PatientAppointmentListScreen()))),
              buildListTile(
                title: AppStrings.medicineCourse,
                onTap: () => NavigationController.navigator.pushNamed(Routes.medicineCourse),
              ),
              // buildListTile(
              //   title: AppStrings.savedBlogs,
              //   onTap: () => NavigationController.navigator.pushNamed(Routes.savedBlogs),
              // ),
            ],
          ),
        ),
      ),
      endDrawer: DrawerPatient(),
    );
  }

  ///
  /// ## `Description`
  ///
  /// Function that returns the list tile for the various options
  /// provided to the user.
  ///
  ListTile buildListTile({@required String title, Function onTap}) {
    return ListTile(
      onTap: () => onTap(),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      trailing: const Icon(
        Icons.arrow_forward_ios,
        size: 16,
        color: Colors.black,
      ),
      title: Text(
        title ?? '',
        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w500, fontFamily: fontMontserrat),
      ),
    );
  }
}
