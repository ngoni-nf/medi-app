// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:flutter/material.dart';
import 'package:google_map_location_picker/google_map_location_picker.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/addressModel.dart';
import 'package:medivic/models/specialityModel.dart';
import 'package:medivic/models/userModel.dart';
import 'package:medivic/screens/gooogleMap/googleMap.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/shared/customButton.dart';
import 'package:medivic/utils/common_utils.dart';

class DoctorSearchFilterContainer extends StatefulWidget {
  @override
  _DoctorSearchFilterContainerState createState() =>
      _DoctorSearchFilterContainerState();
}

class _DoctorSearchFilterContainerState
    extends State<DoctorSearchFilterContainer> {
  int radius;
  String speciality;

  @override
  void initState() {
    super.initState();
    radius = LocatorService.searchProvider().radius;
    speciality = LocatorService.searchProvider().speciality;
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _theme.backgroundColor,
        borderRadius: const BorderRadius.only(
          topRight: Radius.circular(16),
          topLeft: Radius.circular(16),
        ),
      ),
      child: ListView(
        children: <Widget>[
          Center(
            child: Padding(
              padding: const EdgeInsets.all(4),
              child: Text(
                AppStrings.filterPractitioners,
                style: _theme.textTheme.headline6,
              ),
            ),
          ),
          const Divider(),
          Align(
            child: FlatButton(
                color: appBarColor,
                onPressed: () => _resetFilter(),
                child: const Text(
                  'CLEAR',
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: fontMontserrat,
                  ),
                )),
            alignment: Alignment.centerRight,
          ),
          RadiusPicker(radius, _setPickedRadius),
          const SizedBox(height: 4),
          SpecialityPicker(speciality, _setSelectedSpeciality),
          const SizedBox(height: 16),
          AppButton(text: 'Apply', onPressed: () => _applyFilter()),
        ],
      ),
    );
  }

  void _resetFilter() {
    setState(() {
      radius = Config.DOCTOR_FILTER_DEFAULT_RADIUS;
      speciality = null;
    });
    LocatorService.searchProvider().resetDoctorFilter();
  }

  void _applyFilter() {
    LocatorService.searchProvider().setRadius = radius;
    LocatorService.searchProvider().setSpeciality = speciality;
    Navigator.of(context).pop();
  }

  void _setPickedRadius(value) => radius = value;

  void _setSelectedSpeciality(value) => speciality = value;
}

class SpecialityPicker extends StatefulWidget {
  const SpecialityPicker(this.speciality, this.function);

  final String speciality;
  final Function function;

  @override
  _SpecialityPickerState createState() => _SpecialityPickerState(speciality);
}

class _SpecialityPickerState extends State<SpecialityPicker> {
  _SpecialityPickerState(this.speciality);

  String speciality;
  List<String> specialities = [];

  @override
  void initState() {
    super.initState();
    specialities = Speciality.getSpecialities().map((e) => e['name']).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.2),
        borderRadius: const BorderRadius.all(Radius.circular(32)),
      ),
      padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 24),
      child: DropdownButton<String>(
        isExpanded: true,
        value: speciality,
        icon: const Icon(
          Icons.arrow_drop_down,
          color: Colors.black,
        ),
        iconSize: 32,
        elevation: 16,
        hint: const Text('Speciality'),
        underline: Container(),
        onChanged: (String newValue) {
          widget.function(newValue);
          setState(() => speciality = newValue);
        },
        items: specialities
            .map((String value) => _buildDDMenuItem(value))
            .toList(),
      ),
    );
  }

  DropdownMenuItem<String> _buildDDMenuItem(String value) {
    return DropdownMenuItem<String>(
      value: value,
      child: Text(value),
    );
  }

  @override
  void didUpdateWidget(covariant SpecialityPicker oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.speciality != speciality) {
      setState(() => speciality = oldWidget.speciality);
    }
  }
}

class RadiusPicker extends StatefulWidget {
  const RadiusPicker(this.radius, this.function);

  final int radius;
  final Function function;

  @override
  _RadiusPickerState createState() => _RadiusPickerState(radius);
}

class _RadiusPickerState extends State<RadiusPicker> {
  _RadiusPickerState(this.radius);

  int radius;
  PatientAddress address =
      LocatorService.userProvider().user.address ?? PatientAddress.empty();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text(
              'Radius',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Text(
              ' ($radius KM)',
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Slider(
          min: Config.DOCTOR_FILTER_MIN_RADIUS.toDouble(),
          max: Config.DOCTOR_FILTER_MAX_RADIUS.toDouble(),
          divisions:
              Config.DOCTOR_FILTER_MAX_RADIUS - Config.DOCTOR_FILTER_MIN_RADIUS,
          value: radius.toDouble(),
          onChanged: (double val) {
            widget.function(val.round());
            setState(() => radius = val.round());
          },
          activeColor: appBarColor,
          inactiveColor: Colors.grey,
        ),
        const SizedBox(height: 6),
        const Text('Your Address', style: TextStyle(fontSize: 12)),
        Row(
          children: [
            Expanded(child: Text(address?.address ?? '')),
            FlatButton(
              color: appBarColor,
              onPressed: () async {
                final mAddress =
                    await Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => const GoogleMapScreen(
                    isLock: false,
                  ),
                ));

                // final LocationResult locationResult =
                //     await CommonUtils.openLocationPicker(context);
                final User user = LocatorService.userProvider().user;
                setState(() {
                  address = PatientAddress.fromPickNew(
                      mAddress.address, mAddress.lat, mAddress.lng);
                  // address = PatientAddress.fromPick(locationResult);
                });
                user.address = address;
                await FirestoreService.updateUserData(user.toJson());
                LocatorService.userProvider().updateAddress(address);
              },
              child: const Text(
                'CHANGE',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: fontMontserrat,
                ),
              ),
            )
          ],
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  @override
  void didUpdateWidget(covariant RadiusPicker oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.radius != radius) {
      setState(() => radius = oldWidget.radius);
    }
  }
}
