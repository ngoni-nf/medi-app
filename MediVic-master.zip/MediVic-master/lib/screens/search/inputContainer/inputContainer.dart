// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:flutter/material.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/uiController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/screens/search/filterContainer/docorSeachFilterContainer.dart';
import 'package:medivic/shared/animatedButton.dart';
import 'package:medivic/themes/themeGuide.dart';

class InputContainer extends StatefulWidget {
  const InputContainer({this.showFilterAtStart = false});

  final bool showFilterAtStart;

  @override
  _InputContainerState createState() => _InputContainerState();
}

class _InputContainerState extends State<InputContainer> {
  @override
  void initState() {
    super.initState();
    if (widget.showFilterAtStart) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _showFilter(context));
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Expanded(
          child: ClipRRect(
            borderRadius: ThemeGuide.borderRadius,
            child: TextFormField(
              initialValue: LocatorService.searchProvider().searchTerm,
              decoration: InputDecoration(
                hintText: AppStrings.search,
                hintStyle: _theme.textTheme.bodyText2.copyWith(
                  color: _theme.disabledColor,
                ),
              ),
              onEditingComplete: () {
                FocusScope.of(context).unfocus();
                LocatorService.searchProvider().notifyLoading();
              },
              onChanged: (val) =>
                  LocatorService.searchProvider().setSearchTerm = val,
            ),
          ),
        ),
        const SizedBox(width: 6),
        AnimButton(
          onTap: () => _showFilter(context),
          child: Container(
            padding: const EdgeInsets.all(12),
            child: const Icon(Icons.filter_list, color: Colors.white),
            decoration: BoxDecoration(
              color: _theme.disabledColor.withOpacity(0.2),
              borderRadius: ThemeGuide.borderRadius,
            ),
          ),
        ),
      ],
    );
  }

  void _showFilter(BuildContext context) {
    FocusScope.of(context).unfocus();
    UiController.modalBottomSheet(
      context,
      child: DoctorSearchFilterContainer(),
    );
  }
}
