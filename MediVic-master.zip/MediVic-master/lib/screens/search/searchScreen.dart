// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/screens/search/inputContainer/inputContainer.dart';
import 'package:medivic/screens/search/searchList/searchList.dart';
import 'package:provider/provider.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({
    this.showFilterAtStart = false,
    Key key,
  }) : super(key: key);

  final bool showFilterAtStart;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: InputContainer(
          showFilterAtStart: showFilterAtStart,
        ),
        backgroundColor: appBarColor,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: const Icon(Icons.arrow_back, color: Colors.white),
        ),
      ),
      body: ChangeNotifierProvider.value(
        value: LocatorService.searchProvider(),
        child: SearchList(),
      ),
    );
  }
}
