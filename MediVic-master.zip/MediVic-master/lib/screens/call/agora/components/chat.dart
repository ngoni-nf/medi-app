import 'package:bubble/bubble.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/models/appointment.dart';
import 'package:medivic/models/message.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen(
    this.appointment,
    this.sender,
    this.isPatient,
  );

  final Appointment appointment;
  final int sender;
  final bool isPatient;

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _textEditingController = TextEditingController();
  bool sending = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          _buildChatTitle(),
          const Divider(height: 0),
          _buildChatListView(),
          _buildMessageInput(),
        ],
      ),
    );
  }

  Widget _buildChatTitle() {
    final String name = widget.isPatient
        ? widget.appointment.doctorName
        : widget.appointment.userName;
    return Container(
      padding: const EdgeInsets.all(12),
      child: Text(
        name,
        style: const TextStyle(
            fontFamily: fontMontserrat,
            fontSize: 18,
            fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildChatListView() {
    return Expanded(
      child: StreamBuilder<QuerySnapshot>(
          stream: Firestore.instance
              .collection('messages')
              .where('userId', isEqualTo: widget.appointment.userId)
              .where('doctorId', isEqualTo: widget.appointment.doctorId)
              .orderBy('createdAt', descending: true)
              .snapshots(),
          builder: (context, snapshot) {
            final List<Message> messages = Message.parseList(snapshot);
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: ListView.builder(
                  reverse: true,
                  shrinkWrap: true,
                  itemCount: messages.length,
                  itemBuilder: (context, index) =>
                      _buildChatListItem(messages[index])),
            );
          }),
    );
  }

  Widget _buildMessageInput() {
    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        margin: const EdgeInsets.all(4),
        child: TextField(
          style: const TextStyle(
            color: appBarColor,
            fontSize: 16,
          ),
          controller: _textEditingController,
          decoration: InputDecoration(
            suffixIcon: IconButton(
              icon: Icon(
                Icons.send,
                color: sending ? Colors.grey : appBarColor,
              ),
              onPressed: () => _sendMessage(),
            ),
            border: const OutlineInputBorder(
              borderSide: BorderSide(color: appBarColor, width: 0.5),
            ),
            hintText: 'Type your message...',
            hintStyle: const TextStyle(
              color: greyColor,
              fontSize: 16,
            ),
          ),
        ),
      ),
    );
  }

  void _sendMessage() {
    if (!sending && _textEditingController.text.isNotEmpty) {
      setState(() => sending = true);
      Firestore.instance.collection('messages').add(_createMessage()).then(
        (value) {
          setState(() => sending = false);
          _textEditingController.clear();
        },
      ).catchError((err) => setState(() => sending = false));
    }
  }

  Map<String, dynamic> _createMessage() {
    return Message(
      _textEditingController.text.trim(),
      widget.appointment.userId,
      widget.appointment.doctorId,
      widget.sender,
      DateTime.now().millisecondsSinceEpoch,
    ).toJson();
  }

  Widget _buildChatListItem(Message message) {
    final bool isSender = widget.sender == message.sender;
    return Container(
      margin: const EdgeInsets.only(top: 8, bottom: 4, right: 6, left: 6),
      child: Column(
        crossAxisAlignment:
            isSender ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 6, right: 6),
            child: Text(
              message.getDateTime(),
              style: const TextStyle(
                fontSize: 12,
                fontFamily: fontMontserrat,
                color: Colors.grey,
              ),
            ),
          ),
          Bubble(
            alignment: isSender ? Alignment.topRight : Alignment.topLeft,
            color: isSender ? appBarColor : Colors.grey.shade300,
            child: Text(
              message.text,
              style: TextStyle(
                fontFamily: fontMontserrat,
                color: isSender ? Colors.white : Colors.black,
              ),
              textAlign: isSender ? TextAlign.right : TextAlign.left,
            ),
          ),
        ],
      ),
    );
  }
}
