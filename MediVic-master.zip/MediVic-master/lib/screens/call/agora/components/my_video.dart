import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/material.dart';

class MyVideo extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _MyVideoState();
  }
}

class _MyVideoState extends State<MyVideo> {
  double xPosition = 16;
  double yPosition = 100;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: yPosition,
      right: xPosition,
      child: GestureDetector(
        onPanUpdate: (tapInfo) {
          setState(() {
            xPosition -= tapInfo.delta.dx;
            yPosition -= tapInfo.delta.dy;
          });
        },
        child: _buildMyVideo(),
      ),
    );
  }

  Widget _buildMyVideo() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Container(
          width: 96,
          height: 136,
          child: AgoraRenderWidget(
            0,
            local: true,
            preview: true,
          )),
    );
  }
}
