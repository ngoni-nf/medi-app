import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/appointment.dart';

class AppointmentTimer extends StatefulWidget {
  const AppointmentTimer(this.appointment, this.function);

  final Appointment appointment;
  final Function function;

  @override
  _AppointmentTimerState createState() => _AppointmentTimerState();
}

class _AppointmentTimerState extends State<AppointmentTimer> {
  Timer timer;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(
      const Duration(seconds: 5),
      (Timer t) => setState(() {}),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Duration timeToEnd =
        widget.appointment.getEndDateTime().difference(DateTime.now());
    if (timeToEnd.inSeconds <= 0) {
      appointmentEnded();
    } else if (timeToEnd <= Config.NOTIFY_BEFORE_APPOINTMENT_END) {
      final notificationMessage =
          'Please note that the call will terminate in ${timeToEnd.inSeconds} seconds.';
      return Container(
        margin: const EdgeInsets.only(top: kToolbarHeight, left: 4, right: 4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4),
          color: Colors.red,
        ),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        child: Text(
          notificationMessage,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontFamily: fontMontserrat,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      );
    }
    return Container();
  }

  void appointmentEnded() {
    timer?.cancel();
    SchedulerBinding.instance.addPostFrameCallback((_) {
      if (LocatorService.userProvider().user != null) {
        _showSessionEndedDialogForPatient();
      } else {
        widget.function();
      }
    });
  }

  Future<void> _showSessionEndedDialogForPatient() async {
    await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: AlertDialog(
              backgroundColor: Colors.white,
              content: const Text(AppStrings.sessionEnded),
              actions: <Widget>[
                FlatButton(
                  child: const Text('OK'),
                  onPressed: () => _navigateToHome(),
                )
              ],
            ),
          );
        });
  }

  void _navigateToHome() {
    NavigationController.navigator.pushNamedAndRemoveUntil(
      Routes.home,
      ModalRoute.withName(Routes.home),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }
}
