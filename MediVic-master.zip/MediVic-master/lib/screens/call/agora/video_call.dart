// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:async';

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/appointment.dart';
import 'package:medivic/models/appointment_status.dart';
import 'package:medivic/screens/call/agora/components/chat.dart';
import 'package:medivic/screens/call/agora/components/my_video.dart';
import 'package:medivic/screens/call/agora/components/timer.dart';
import 'package:medivic/screens/call/sessionConfirmation/session_confirmation.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/shared/rating_dialog.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:wakelock/wakelock.dart';

class VideoCallScreen extends StatefulWidget {
  const VideoCallScreen({
    Key key,
    this.channelName,
    this.isPatient,
    this.appointment,
  }) : super(key: key);

  final String channelName;
  final bool isPatient;
  final Appointment appointment;

  @override
  VideoCallScreenState createState() => VideoCallScreenState(isPatient);

  static Future<void> start(
    BuildContext context,
    Appointment appointment,
  ) async {
    if (appointment.status == AppointmentStatus.CANCELLED) {
      showInfoDialog(context, AppStrings.sessionCancelled);
    } else if (appointment.sessionEnded()) {
      showInfoDialog(context, AppStrings.sessionEnded);
    } else if (appointment.sessionNotStarted()) {
      showInfoDialog(context, AppStrings.sessionNotStarted);
    } else {
      final Map<PermissionGroup, PermissionStatus> status = await PermissionHandler().requestPermissions(
        [
          PermissionGroup.camera,
          PermissionGroup.microphone,
        ],
      );

      final bool allowed = status.entries.map((e) => e.value).where((element) => element == PermissionStatus.granted).length == status.length;

      if (allowed) {
        LocatorService.inActivityTimer().setActivity(false);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => VideoCallScreen(
              channelName: appointment.getVideoChannelId(),
              appointment: appointment,
              isPatient: LocatorService.userProvider().user != null,
            ),
          ),
        );
      }
    }
  }

  static Future<void> showInfoDialog(BuildContext context, String message) async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.white,
        content: Text(message),
        actions: [
          FlatButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}

class VideoCallScreenState extends State<VideoCallScreen> {
  VideoCallScreenState(this.showWaitingScreen);

  final _users = <int>[];
  final _infoStrings = <String>[];
  bool muted = false;
  bool showWaitingScreen;

  @override
  void initState() {
    super.initState();
    Wakelock.enable();
    initialize();
    setUserJoined();
  }

  void setUserJoined() {
    final data = {LocatorService.doctorProvider().doctor == null ? 'patientJoined' : 'doctorJoined': true};
    Firestore.instance.collection(Appointment.COLLECTION_NAME).document(widget.appointment.id).updateData(data);
  }

  Future<void> initialize() async {
    if (Config.AGORA_APP_ID.isEmpty) {
      setState(() {
        _infoStrings.add(
          'AGORA_APP_ID missing, please provide your AGORA_APP_ID in lib -> constants -> config.dart',
        );
        _infoStrings.add('Agora Engine is not starting');
        _print();
      });
      return;
    }

    await _initAgoraRtcEngine();
    _addAgoraEventHandlers();
    await AgoraRtcEngine.enableWebSdkInteroperability(true);
    await AgoraRtcEngine.setParameters(
        '''{\'che.video.lowBitRateStreamParameter\':{\'width\':320,\'height\':180,\'frameRate\':15,\'bitRate\':140}}''');
    await AgoraRtcEngine.joinChannel(null, widget.channelName, null, 0);
  }

  Future<void> _initAgoraRtcEngine() async {
    await AgoraRtcEngine.create(Config.AGORA_APP_ID);
    await AgoraRtcEngine.enableVideo();
  }

  void _addAgoraEventHandlers() {
    AgoraRtcEngine.onError = (dynamic code) {
      setState(() {
        final info = 'onError: $code';
        _infoStrings.add(info);
        _print();
      });
    };

    AgoraRtcEngine.onJoinChannelSuccess = (
      String channel,
      int uid,
      int elapsed,
    ) {
      setState(() {
        final info = 'onJoinChannel: $channel, uid: $uid';
        _infoStrings.add(info);
        _print();
      });
    };

    AgoraRtcEngine.onLeaveChannel = () {
      setState(() {
        _infoStrings.add('onLeaveChannel');
        _users.clear();
        _print();
      });
    };

    AgoraRtcEngine.onUserJoined = (int uid, int elapsed) {
      setState(() {
        final info = 'userJoined: $uid';
        _infoStrings.add(info);
        _users.add(uid);
        showWaitingScreen = false;
        _print();
      });
    };

    AgoraRtcEngine.onUserOffline = (int uid, int reason) {
      setState(() {
        final info = 'userOffline: $uid';
        _infoStrings.add(info);
        _users.remove(uid);
        _print();
      });
    };

    AgoraRtcEngine.onFirstRemoteVideoFrame = (
      int uid,
      int width,
      int height,
      int elapsed,
    ) {
      setState(() {
        final info = 'firstRemoteVideo: $uid ${width}x $height';
        _infoStrings.add(info);
        _print();
      });
    };
  }

  void _showChatScreen() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.75,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(12),
            topRight: Radius.circular(12),
          ),
        ),
        child: ChatScreen(
          widget.appointment,
          widget.isPatient ? 1 : 0,
          widget.isPatient,
        ),
      ),
    );
  }

  void _onToggleMute() {
    setState(() => muted = !muted);
    AgoraRtcEngine.muteLocalAudioStream(muted);
  }

  void _onSwitchCamera() => AgoraRtcEngine.switchCamera();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: WillPopScope(
        onWillPop: () => _showExitConfirmationDialog(context),
        child: Scaffold(
          backgroundColor: Colors.black,
          appBar: _buildAppBar(context),
          body: _shouldShowWaitingScreen() ? _buildWaitingScreen() : _buildVideoBody(),
          extendBodyBehindAppBar: !_shouldShowWaitingScreen(),
          resizeToAvoidBottomPadding: false,
        ),
      ),
    );
  }

  Widget _buildVideoBody() {
    return Stack(
      children: [
        _buildParticipantVideoView(),
        _buildToolbar(),
        AppointmentTimer(widget.appointment, _endCall),
        MyVideo(),
      ],
    );
  }

  Widget _buildParticipantVideoView() {
    final String imageUrl = widget.isPatient ? widget.appointment.doctorImageUrl : widget.appointment.userImageUrl;
    return _users.isEmpty
        ? imageUrl == null
            ? Container(
                color: Colors.black,
                child: const Center(
                  child: Icon(
                    Icons.person,
                    color: Colors.white,
                  ),
                ),
              )
            : Center(
                child: CachedNetworkImage(imageUrl: imageUrl),
              )
        : AgoraRenderWidget(_users.first);
  }

  Widget _buildToolbar() {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            RawMaterialButton(
              onPressed: () => _showExitConfirmationDialog(context),
              child: const Icon(
                Icons.call_end,
                color: Colors.white,
                size: 36,
              ),
              shape: const CircleBorder(),
              elevation: 2.0,
              fillColor: Colors.redAccent,
              padding: const EdgeInsets.all(15.0),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                RawMaterialButton(
                  onPressed: _onToggleMute,
                  child: Icon(
                    muted ? Icons.mic_off : Icons.mic,
                    color: muted ? Colors.white : darkBlueColor,
                    size: 20,
                  ),
                  shape: const CircleBorder(),
                  elevation: 2.0,
                  fillColor: muted ? darkBlueColor : Colors.white,
                  padding: const EdgeInsets.all(12.0),
                ),
                RawMaterialButton(
                  onPressed: () => _showChatScreen(),
                  child: const Icon(
                    Icons.message,
                    color: darkBlueColor,
                    size: 20,
                  ),
                  shape: const CircleBorder(),
                  elevation: 2.0,
                  fillColor: Colors.white,
                  padding: const EdgeInsets.all(12.0),
                ),
                RawMaterialButton(
                  onPressed: _onSwitchCamera,
                  child: const Icon(
                    Icons.switch_camera,
                    color: darkBlueColor,
                    size: 20.0,
                  ),
                  shape: const CircleBorder(),
                  elevation: 2.0,
                  fillColor: Colors.white,
                  padding: const EdgeInsets.all(12.0),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<bool> _showExitConfirmationDialog(BuildContext context) {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          backgroundColor: Colors.white,
          title: const Text(
            AppStrings.endCallText,
            textAlign: TextAlign.center,
          ),
          titleTextStyle: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
          actions: [
            FlatButton(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              color: Colors.red,
              child: const Text(
                AppStrings.yesUpperCase,
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
              onPressed: () {
                Navigator.of(context).pop();
                _endCall();
              },
            ),
            FlatButton(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              color: darkBlueColor,
              child: const Text(
                AppStrings.noUpperCase,
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
              onPressed: () => Navigator.of(context).pop(false),
            )
          ],
        );
      },
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      iconTheme: const IconThemeData(color: Colors.white),
      title: Text(
        _shouldShowWaitingScreen() ? AppStrings.waitingRoom : '',
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w400,
          fontFamily: fontMontserrat,
        ),
      ),
      backgroundColor: _shouldShowWaitingScreen() ? appBarColor : Colors.transparent,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: Colors.white, size: 30.0),
        onPressed: () => _showExitConfirmationDialog(context),
      ),
      centerTitle: true,
    );
  }

  void _print() => print('AGORA LOG ${_infoStrings.toString()}');

  bool _shouldShowWaitingScreen() {
    return showWaitingScreen && _users.isEmpty;
  }

  Widget _buildWaitingScreen() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      color: Colors.white,
      child: Column(
        children: [
          const Expanded(
            flex: 1,
            child: Center(
              child: Text(
                AppStrings.waitingRoomMessage,
                style: TextStyle(
                  fontFamily: fontMontserrat,
                  fontSize: 18,
                ),
              ),
            ),
          ),
          Expanded(
              flex: 1,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(24),
                    child: Container(
                      decoration: BoxDecoration(border: Border.all(width: 3)),
                      child: CachedNetworkImage(
                        width: 88,
                        height: 88,
                        imageUrl: LocatorService.userProvider().user.imageUrl,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Container(
                    color: Colors.grey,
                    width: 2,
                    height: 136,
                  ),
                  const SizedBox(width: 16),
                  Text(
                    LocatorService.userProvider().user.name,
                    style: const TextStyle(
                      fontFamily: fontMontserrat,
                      fontSize: 20,
                    ),
                  )
                ],
              ))
        ],
      ),
    );
  }

  Future<void> _doctorRating() async {
    String prevComment;
    double prevRating = 0;
    await FirestoreService.getRating(LocatorService.userProvider().user.uid, widget.appointment.doctorId)
        .then((value) {
          prevRating = value['rating'];
          prevComment = value['comment'];
        })
        .timeout(const Duration(seconds: 30))
        .catchError((error) {});

    if (prevRating != null && prevRating == 0)
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => RatingDialog(
          doctorId: widget.appointment.doctorId,
          comment: prevComment,
          rating: prevRating,
        ),
      );
    _navigateToHome();
  }

  void _endCall() {
    if (LocatorService.doctorProvider().doctor != null) {
      SessionConfirmation.showSessionConfirmationDialog(
        context,
        widget.appointment.id,
        widget.appointment.sessionConfirmed,
        false,
      );
    } else {
      _doctorRating();
    }
  }

  void _navigateToHome() {
    NavigationController.navigator.pushNamedAndRemoveUntil(
      Routes.home,
      ModalRoute.withName(Routes.home),
    );
  }

  @override
  void dispose() {
    // clear users
    _users.clear();
    // destroy sdk
    AgoraRtcEngine.leaveChannel();
    AgoraRtcEngine.destroy();

    // Disable the wake lock
    Wakelock.disable();
    LocatorService.inActivityTimer().setActivity(true);
    super.dispose();
  }
}
