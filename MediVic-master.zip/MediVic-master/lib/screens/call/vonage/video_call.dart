import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/appointment.dart';
import 'package:medivic/models/appointment_status.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/shared/rating_dialog.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:medivic/screens/call/sessionConfirmation/session_confirmation.dart';

class VonageVideoCall {
  static const platform = MethodChannel('com.centrax.medivic');

  static Future<void> start(
    BuildContext context,
    Appointment appointment,
  ) async {
    if (appointment.status == AppointmentStatus.CANCELLED) {
      showInfoDialog(context, AppStrings.sessionCancelled);
    } else if (appointment.sessionEnded()) {
      showInfoDialog(context, AppStrings.sessionEnded);
    } else if (appointment.sessionNotStarted()) {
      showInfoDialog(context, AppStrings.sessionNotStarted);
    } else {
      final Map<PermissionGroup, PermissionStatus> status =
          await PermissionHandler().requestPermissions(
        [
          PermissionGroup.camera,
          PermissionGroup.microphone,
        ],
      );

      final bool allowed = status.entries
              .map((e) => e.value)
              .where((element) => element == PermissionStatus.granted)
              .length ==
          status.length;

      if (allowed) {
        setUserJoined(appointment.id);
        final Map<String, dynamic> data = {
          'appointmentId': appointment.id,
          'isPatient': LocatorService.userProvider().user != null,
          'doctorId': appointment.doctorId,
          'patientId': appointment.userId,
          'doctorImageUrl': appointment.doctorImageUrl,
          'patientImageUrl': appointment.userImageUrl,
          'doctorName': appointment.doctorName,
          'patientName': appointment.userName,
          'endTime': appointment.getEndDateTime().millisecondsSinceEpoch,
        };
        await platform.invokeMethod(
          'startVideoCall',
          data,
        );

        if (LocatorService.doctorProvider().doctor != null) {
          SessionConfirmation.showSessionConfirmationDialog(
            context,
            appointment.id,
            appointment.sessionConfirmed,
            false,
          );
        } else {
          _doctorRating(context, appointment.doctorId);
        }
      }
    }
  }

  static void setUserJoined(String appointmentId) {
    final data = {
      LocatorService.doctorProvider().doctor == null
          ? 'patientJoined'
          : 'doctorJoined': true
    };
    Firestore.instance
        .collection(Appointment.COLLECTION_NAME)
        .document(appointmentId)
        .updateData(data);
  }

  static Future<void> _doctorRating(
    BuildContext context,
    String doctorId,
  ) async {
    String prevComment;
    double prevRating = 0;
    await FirestoreService.getRating(
      LocatorService.userProvider().user.uid,
      doctorId,
    )
        .then((value) {
          prevRating = value['rating'];
          prevComment = value['comment'];
        })
        .timeout(const Duration(seconds: 30))
        .catchError(
          (error) {},
        );

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => RatingDialog(
        doctorId: doctorId,
        comment: prevComment,
        rating: prevRating,
      ),
    );
    navigateToHome();
  }

  static Future<void> showInfoDialog(
      BuildContext context, String message) async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.white,
        content: Text(message),
        actions: [
          FlatButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  static void navigateToHome() {
    NavigationController.navigator.pushNamedAndRemoveUntil(
      Routes.home,
      ModalRoute.withName(Routes.home),
    );
  }
}
