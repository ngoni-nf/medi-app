import 'package:flutter/material.dart';
import 'package:medivic/const.dart';

class SessionConfirmationCheckBox extends StatefulWidget {
  const SessionConfirmationCheckBox(
    this.text,
    this.checked,
    this.onCheckChanged,
  );

  final String text;
  final bool checked;
  final Function onCheckChanged;

  @override
  _SessionConfirmationCheckBoxState createState() =>
      _SessionConfirmationCheckBoxState();
}

class _SessionConfirmationCheckBoxState
    extends State<SessionConfirmationCheckBox> {
  bool checked = false;

  @override
  void initState() {
    super.initState();
    checked = widget.checked;
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Checkbox(
          value: checked,
          onChanged: (val) => _onCheckChanged(val),
        ),
        Flexible(
          child: GestureDetector(
            onTap: () => _onCheckChanged(!checked),
            child: Text(widget.text,
                style: const TextStyle(fontFamily: fontMontserrat)),
          ),
        ),
      ],
    );
  }

  void _onCheckChanged(bool val) {
    setState(() => checked = val);
    widget.onCheckChanged(val);
  }
}
