import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/models/appointment.dart';
import 'package:medivic/models/appointment_status.dart';
import 'package:medivic/screens/call/sessionConfirmation/check_box.dart';
import 'package:medivic/shared/customButton.dart';

class SessionConfirmation extends StatefulWidget {
  const SessionConfirmation(
    this.appointmentId,
    this.sessionConfirmed,
    this.fromCompletedSessions,
  );

  final String appointmentId;
  final bool sessionConfirmed;
  final bool fromCompletedSessions;

  @override
  _SessionConfirmationState createState() => _SessionConfirmationState();

  static Future<bool> showSessionConfirmationDialog(
    BuildContext context,
    final String appointmentId,
    final bool sessionConfirmed,
    bool fromCompletedSessions,
  ) async {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async => false,
            child: AlertDialog(
              contentPadding: const EdgeInsets.all(0),
              backgroundColor: Colors.white,
              content: SessionConfirmation(
                appointmentId,
                sessionConfirmed,
                fromCompletedSessions,
              ),
            ),
          );
        });
  }
}

class _SessionConfirmationState extends State<SessionConfirmation> {
  bool consultedPatient, diagnosedPatient;
  bool savingData = false;

  @override
  void initState() {
    super.initState();
    consultedPatient = widget.sessionConfirmed;
    diagnosedPatient = widget.sessionConfirmed;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            color: appBarColor,
            child: const Text(
              AppStrings.sessionConfirmationTitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: fontMontserrat,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              AppStrings.sessionConfirmationMessage,
              textAlign: TextAlign.center,
              style: TextStyle(fontFamily: fontMontserrat),
            ),
          ),
          SessionConfirmationCheckBox(
            AppStrings.sessionConfirmationConsultedPatient,
            consultedPatient,
            (val) => setState(() => consultedPatient = val),
          ),
          SessionConfirmationCheckBox(
            AppStrings.sessionConfirmationDiagnosedPatient,
            diagnosedPatient,
            (val) => setState(() => diagnosedPatient = val),
          ),
          Container(
            margin: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: ProgressButton(
                    'Submit',
                    _canSubmitChanges()
                        ? () => _saveSessionConfirmationData(true)
                        : null,
                    savingData,
                    '',
                    fontSize: 14,
                    padding: 10,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: AppButton(
                    text: 'Complete Later',
                    onPressed: () => widget.fromCompletedSessions
                        ? _closeSessionConfirmation(false)
                        : _saveSessionConfirmationData(false),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  bool _canSubmitChanges() {
    return consultedPatient && diagnosedPatient;
  }

  void _saveSessionConfirmationData(bool confirmed) {
    setState(() => savingData = true);
    final Map<String, dynamic> data = {'status': AppointmentStatus.COMPLETED};
    if (confirmed) {
      data['sessionConfirmed'] = confirmed;
    }
    Firestore.instance
        .collection(Appointment.COLLECTION_NAME)
        .document(widget.appointmentId)
        .updateData(data)
        .then((value) => _closeSessionConfirmation(confirmed))
        .catchError(
      (err) {
        setState(() => savingData = false);
        Fluttertoast.showToast(msg: AppStrings.somethingWentWrong);
      },
    );
  }

  void _closeSessionConfirmation(bool confirmed) {
    if (widget.fromCompletedSessions) {
      Navigator.of(context).pop(confirmed);
    } else {
      NavigationController.navigator.pushNamedAndRemoveUntil(
        Routes.homeDoctor,
        ModalRoute.withName(Routes.homeDoctor),
      );
    }
  }
}
