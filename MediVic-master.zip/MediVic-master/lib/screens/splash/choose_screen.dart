import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_gifimage/flutter_gifimage.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/navigationController.dart';

class Choose extends StatefulWidget {
  const Choose({Key key}) : super(key: key);

  @override
  _ChooseState createState() => _ChooseState();
}

class _ChooseState extends State<Choose> with SingleTickerProviderStateMixin {
  // AnimationController _animationController;
  // Animation _animation;
  GifController controller;

  @override
  void initState() {
    super.initState();
    // Controller that controls the animation.
    controller = GifController(vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.repeat(min: 0, max: 20, period: Duration(milliseconds: 1000));
    });
    // _animationController = AnimationController(
    //     vsync: this, duration: Duration(milliseconds: 1200));
    // _animation = Tween(begin: 0.8, end: 1.0).animate(CurvedAnimation(
    //     curve: Curves.bounceOut, parent: _animationController));
    //
    // _animationController.addStatusListener((AnimationStatus status) {
    //   if (status == AnimationStatus.completed) {
    //     _animationController.reverse();
    //   }else  if (status == AnimationStatus.reverse) {
    //     _animationController.forward();
    //   }
    // });

    // _animationController.forward();
  }

  @override
  void dispose() {
    // Very Important to dispose the controller for optimization.
    // _animationController?.dispose();
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          GifImage(
            controller: controller,
            height: 100,
            width: 100,
            image: AssetImage(
              'lib/assets/images/medi_vic_final_animated.gif',
            ),
          ),
          // Image.asset(
          //   'lib/assets/images/medi_vic_final_animated.gif',
          //   width: 100,
          //   height: 100,
          // ),
          SizedBox(
            height: 40,
          ),
          InkWell(
            onTap: () {
              NavigationController.navigator.pushNamed(Routes.login);
            },
            child: CircleAvatar(
              radius: 80,
              backgroundColor: appBarColor,
              child: Text(
                AppStrings.patient,
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: fontMontserrat,
                    fontSize: 20),
              ),
            ),
          ),
          SizedBox(
            height: 40,
          ),
          InkWell(
            onTap: () {
              NavigationController.navigator.pushNamed(
                Routes.loginDoctor,
              );
            },
            child: CircleAvatar(
              radius: 80,
              backgroundColor: darkBlueColor,
              child: Text(
                AppStrings.doctor,
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: fontMontserrat,
                    fontSize: 20),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
