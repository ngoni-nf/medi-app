// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/userModel.dart';
import 'package:medivic/services/storage/localStorage.dart';
import 'package:medivic/services/storage/storageConstants.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  AnimationController _controller;
  Animation _animation, _textAimation;

  // Auth variables
  FAuthUser _user;
  String _accountType;
  bool _isUserLoggedIn = false,
      _isDocAvailable = false,
      _isUserDocAvailable = false,
      _initialInstall = false;
  String isOtp = "0";

  @override
  void initState() {
    super.initState();
    // Controller that controls the animation.
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    // Type of animation to perform for `Logo`
    _animation = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.2, 1.0, curve: Curves.elasticOut),
    );

    // Animation for the text => `Name of the application`
    _textAimation = Tween(
      begin: 0.0,
      end: 1.0,
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.6, 1.0, curve: Curves.easeInOut),
      ),
    );

    // Listen to animation completion
    _controller.addStatusListener(handler);

    // Starts the animation
    _controller.forward();
  }

  @override
  void dispose() {
    // Very Important to dispose the controller for optimization.
    _controller.removeStatusListener(handler);
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.white,
        width: MediaQuery.of(context).size.width,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            ScaleTransition(
              scale: _animation,
              child: Image.asset(
                'lib/assets/images/app_icon.png',
                width: 300,
                height: 300,
              ),
            ),
            const SizedBox(
              height: 50,
            ),
            FadeTransition(
              opacity: _textAimation,
              child: const Text(
                Config.SPLASH_SCREEN_HEADING,
                style: TextStyle(
                    color: darkBlueColor,
                    fontSize: 36,
                    fontFamily: fontMontserrat,
                    fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            const CircularProgressIndicator(
              backgroundColor: appBarColor,
            ),
          ],
        ),
      ),
    );
  }

  /// Check the user logged in status simultaneously as the animation
  /// runs. Main function is to set the flags for controlled navigation
  /// after splash screen animation ends.
  Future<void> checkUserStatus() async {
    log('Checking user status', name: 'Splash Screen');
    _user = await LocatorService.authService().currentUser();

    _isUserLoggedIn = _user != null || false;

    // check the account type
    _accountType =
        await LocalStorage.getString(LocalStorageConstants.ACCOUNT_TYPE);

    // initial install go to onboarding.
    if (_isUserLoggedIn) {
      if (_accountType == LocalStorageConstants.DOCTOR_ACCOUNT_TYPE) {
        _isDocAvailable =
            await LocatorService.doctorProvider().fetchDoctorData(_user.uid);
        final doctor = LocatorService.doctorProvider().doctor;
        if (doctor != null) {
          isOtp = doctor.isOTP ?? '0';
          _isDocAvailable =
              isOtp == '1' && doctor.isActive == 1 && !doctor.isBlock;
        }
      } else {
        _isUserDocAvailable =
            await LocatorService.userProvider().fetchUserData(_user.uid);
        final user = LocatorService.userProvider().user;
        if (user != null) {
          isOtp = user.isOTP ?? '0';
          _isUserDocAvailable = isOtp == '1' && !user.isBlock;
        }
      }
    } else {
      final initial =
          await LocalStorage.getString(LocalStorageConstants.INITIAL_INSTALL);
      _initialInstall = initial == null || false;
    }
  }

  /// Listen for animation changes
  Future<void> handler(AnimationStatus status) async {
    if (status == AnimationStatus.completed) {
      log('Animation complete', name: 'Splash screen');
      await checkUserStatus();

      if (_isDocAvailable) {
        NavigationController.navigator.pushReplacementNamed(Routes.homeDoctor);

        return;
      }

      if (_isUserDocAvailable) {
        NavigationController.navigator.pushReplacementNamed(Routes.home);
        return;
      }

      if (_initialInstall) {
        NavigationController.navigator.pushReplacementNamed(Routes.onBoarding);
        return;
      } else {
        NavigationController.navigator.pushReplacementNamed(Routes.choose);
        return;
      }
    }
  }
}
