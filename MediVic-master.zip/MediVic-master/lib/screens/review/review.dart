// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/controllers/uiController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/providers/consultationProvider.dart';
import 'package:medivic/shared/widgets/categoryOptionsModal.dart';
import 'package:medivic/shared/widgets/formatOptionsModal.dart';
import 'package:provider/provider.dart';

class Review extends StatelessWidget {
  const Review({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final ThemeData _theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.white,
        ),
        title: const Text(
          AppStrings.review,
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SizedBox.expand(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    AppStrings.illness,
                    style: _theme.textTheme.bodyText2,
                  ),
                  Row(
                    children: <Widget>[
                      ChangeNotifierProvider<ConsultationProvider>.value(
                        value: LocatorService.consultationProvider(),
                        child: Selector<ConsultationProvider, String>(
                          selector: (context, d) => d.title,
                          builder: (context, title, _) {
                            return Text(
                              title,
                              style: _theme.textTheme.headline5,
                            );
                          },
                        ),
                      ),
                      const Spacer(),
                      OutlineButton(
                        highlightColor: Colors.transparent,
                        splashColor: Colors.blue.withAlpha(50),
                        highlightedBorderColor: darkBlueColor,
                        child: const Text(AppStrings.change),
                        onPressed: () => UiController.showModal(
                          context,
                          CategoryOptionsModal(),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    AppStrings.consultFormat,
                    style: _theme.textTheme.bodyText2,
                  ),
                  Row(
                    children: <Widget>[
                      ChangeNotifierProvider<ConsultationProvider>.value(
                        value: LocatorService.consultationProvider(),
                        child: Selector<ConsultationProvider, String>(
                          selector: (context, d) => d.formatTypeString,
                          builder: (context, formatType, _) {
                            return Text(
                              formatType,
                              style: _theme.textTheme.headline5,
                            );
                          },
                        ),
                      ),
                      const Spacer(),
                      OutlineButton(
                        highlightColor: Colors.transparent,
                        splashColor: Colors.blue.withAlpha(50),
                        highlightedBorderColor: darkBlueColor,
                        child: const Text(AppStrings.change),
                        onPressed: () => UiController.showModal(
                          context,
                          const FormatOptionsModal(),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        Config.CURRENCY + ' ' + LocatorService.consultationProvider().amount,
                        style: _theme.textTheme.headline4.copyWith(
                          color: Colors.black,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        AppStrings.paymentMessage,
                        style: _theme.textTheme.bodyText2.copyWith(
                          color: Colors.black54,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: CupertinoButton.filled(
                        child: Text(
                          AppStrings.proceedToPay,
                          style: _theme.textTheme.button.copyWith(color: Colors.white),
                        ),
                        onPressed: () => NavigationController.navigator.popAndPushNamed(Routes.paymentWebview),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
