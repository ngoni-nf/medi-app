// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/controllers/uiController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/shared/widgets/illnessOptionsModal.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

///
/// ## `Description`
///
/// Widget that returns the main list of categories displayed
/// to the user to select from.
/// Returns a horizontal list of illness with SVG assets in card
/// format.
///
///
///


class CategoryOptions extends StatefulWidget {


  const CategoryOptions({Key key}) : super(key: key);
  List<Map<String, String>> get choiceList => const <Map<String, String>>[
    {'heading': 'COVID 19', 'svgUrl': 'lib/assets/svg/covid19.svg'},
    {'heading': 'JOINTS AND BONES', 'svgUrl': 'lib/assets/svg/joints.svg'},
        {'heading': 'WOMENS HEALTH', 'svgUrl': 'lib/assets/svg/women.svg'},
        {'heading': 'URINARY TRACT HEALTH', 'svgUrl': 'lib/assets/svg/urinary.svg'},
        {'heading': 'SKIN', 'svgUrl': 'lib/assets/svg/skin.svg'},
        {'heading': 'SEX SPECIALIST', 'svgUrl': 'lib/assets/svg/sex.svg'},
        {'heading': 'PHYSIOTHERAPIST', 'svgUrl': 'lib/assets/svg/psy.svg'},
        {'heading': 'DIET AND FITNESS', 'svgUrl': 'lib/assets/svg/diet.svg'},
        {'heading': 'MENTAL HEALTH', 'svgUrl': 'lib/assets/svg/mental.svg'},
        {'heading': 'LUNG HEALTH', 'svgUrl': 'lib/assets/svg/lung.svg'},
        {'heading': 'KIDNEYS', 'svgUrl': 'lib/assets/svg/kidney.svg'},
        {'heading': 'HOMEOPATHICS', 'svgUrl': 'lib/assets/svg/homeo.svg'},
        {'heading': 'HIV/AIDS', 'svgUrl': 'lib/assets/svg/aids.svg'},
        {'heading': 'DIGESTIVE', 'svgUrl': 'lib/assets/svg/digestive.svg'},
        {'heading': 'HEART', 'svgUrl': 'lib/assets/svg/heart.svg'},
        {'heading': 'EYE HEALTH', 'svgUrl': 'lib/assets/svg/eye.svg'},
        {'heading': 'EAR NOSE AND THROAT', 'svgUrl': 'lib/assets/svg/ent.svg'},
        {'heading': 'DIABETES', 'svgUrl': 'lib/assets/svg/diab.svg'},
        {'heading': 'DENTAL HEALTH', 'svgUrl': 'lib/assets/svg/dental.svg'},
        {'heading': 'CHILD CARE', 'svgUrl': 'lib/assets/svg/child.svg'},
        {'heading': 'CANCER', 'svgUrl': 'lib/assets/svg/cancer.svg'},
        {'heading': 'NERVES', 'svgUrl': 'lib/assets/svg/nerves.svg'}

      ];
  List<Color> get colorList => const <Color>[
    Color(0xff04097f),
      Color(0xff04097f),
      Color(0xff04097f),
      Color(0xff04097f),
    /*Color(0xaa02a401),
      Color(0xaa02a401),
      Color(0xaa02a401),
      Color(0xaa02a401),*/
      /*Color(0xaaE090C9),++
        Color(0xaaFBBA7B),
        Color(0xaaF59482),
        Color(0xaaE090C9),*/
      ];
  @override
  _CategoryOptionsState createState() => _CategoryOptionsState();
}

class _CategoryOptionsState extends State<CategoryOptions> {
  int _colorIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Align(
          alignment: Alignment.centerRight,
          child: FlatButton(
            color: appBarColor,
            onPressed: () {
              LocatorService.illnessOptionsProvider().setRouteTo = () {
                NavigationController.navigator.pushNamed(Routes.support);
              };
              UiController.showModal(context, IllnessOptionsModal());
            },
            child: const Text(AppStrings.seeAll),
          ),
        ),
        Container(
          height: 300,
          padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 20),
          child: ListView.builder(
            itemCount: widget.choiceList.length,
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemBuilder: (BuildContext context, int index) {
              if (index % 3 == 0 || index == 3) {
                _colorIndex = 0;
              }
              final Widget item = buildChoiceContainer(
                heading: widget.choiceList[index]['heading'],
                backgroundColor: widget.colorList[_colorIndex],
                svgUrl: widget.choiceList[index]['svgUrl'],
                onPress: () {
                  LocatorService.consultationProvider().setTitle =
                      widget.choiceList[index]['heading'];

                  NavigationController.navigator.pushNamed(
                    Routes.support,
                    arguments: SupportArguments(
                      category: widget.choiceList[index]['heading'],
                      assetUrl: widget.choiceList[index]['svgUrl'],
                    ),
                  );
                },
              );
              _colorIndex += 1;
              return item;
            },
          ),
        ),
      ],
    );
  }

  ///
  /// ## `Description`
  ///
  /// Function which returns a widget that takes care of the touch event and
  /// serves as the item layout for the list.
  ///
  GestureDetector buildChoiceContainer({
    String heading,
    Color backgroundColor,
    String svgUrl,
    Function onPress,
  }) {
    return GestureDetector(
      onTap: onPress,
      child: Container(
        width: 180,
        margin: const EdgeInsets.all(5),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: backgroundColor,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 8, horizontal: 15),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  heading ?? ' ',
                  style: const TextStyle(
                    fontSize: 18,
                    color: Colors.black,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            Expanded(
              child: Container(
                width: 180,
                padding:
                    const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: SvgPicture.asset(
                  svgUrl,
                  fit: BoxFit.contain,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
