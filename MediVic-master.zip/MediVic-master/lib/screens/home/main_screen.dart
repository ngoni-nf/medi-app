import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/screens/accountInfo/accountInfo.dart';
import 'package:medivic/screens/appointment/patient_appointments.dart';
import 'package:medivic/screens/home/home.dart';
import 'package:medivic/screens/more/load_html_screen.dart';
import 'package:medivic/themes/themeGuide.dart';

import '../../const.dart';

class MainScreen extends StatefulWidget {
  MainScreen({Key key}) : super(key: key);

  @override
  State<MainScreen> createState() => new MainScreenState();
}

class MainScreenState extends State<MainScreen> {
  GlobalKey bottomNavigationKey = GlobalKey();
  PageController _tabController;
  bool userAuth = false;
  ScrollController scrollController;
  bool dialVisible = true;

  @override
  void initState() {
    super.initState();

    _tabController = new PageController();

    scrollController = ScrollController()
      ..addListener(() {
        setDialVisible(scrollController.position.userScrollDirection ==
            ScrollDirection.forward);
      });
  }

  int _selectedIndex = 0;
  static const TextStyle optionStyle =
      TextStyle(fontSize: 30, fontWeight: FontWeight.bold);

  void setDialVisible(bool value) {
    setState(() {
      dialVisible = value;
    });
  }

  int currentIndex = 0;

  Widget buildBody() {
    return ListView.builder(
      controller: scrollController,
      itemCount: 30,
      itemBuilder: (ctx, i) => ListTile(title: Text('Item $i')),
    );
  }

  BottomNavigationBarItem customBarItem(String title, String assetImg) {
    return BottomNavigationBarItem(
      icon: Padding(
        padding: const EdgeInsets.all(5.0),
        child: Image.asset(
          assetImg,
          height: 20,
        ),
      ),
      title: Text(
        title,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        return showDialog(
            context: context,
            builder: (BuildContext context) => _buildAlertDialog());
      },
      child: Scaffold(
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          currentIndex: _selectedIndex,
          // this will be set when a new tab is tapped
          onTap: (index) => setState(() {
            _selectedIndex = index;
            print(index);
            _tabController.animateToPage(
              index,
              duration: const Duration(milliseconds: 300),
              curve: Curves.ease,
            );
          }),
          selectedItemColor: darkBlueColor,
          selectedLabelStyle: const TextStyle(
            color: darkBlueColor,
          ),
          items: [
            customBarItem('Home', 'assets/home.png'),
            customBarItem('Sessions', 'assets/cal.png'),
            // customBarItem('Newsfeed', 'assets/newsfeed.png'),
            customBarItem('Profile', "assets/profile-icon.png"),
            customBarItem('FAQs', 'assets/faq.png'),
          ],
        ),
        body: PageView(
          physics: NeverScrollableScrollPhysics(),
          controller: _tabController,
          children: [
            Home(),
            PatientAppointmentListScreen(),
            // NewsFeed(isPatient: true,),
            AccountInfo(),
            LoadHTML(
              field: 'faq',
              title: 'FAQs',
            )
          ],
        ),
      ),
    );
  }

  AlertDialog _buildAlertDialog() {
    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      backgroundColor: Colors.white,
      title: const Text(
        AppStrings.exitQues,
        textAlign: TextAlign.center,
        style: TextStyle(fontFamily: fontMontserrat),
      ),
      titleTextStyle: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          color: Colors.black,
          fontFamily: fontMontserrat),
      actions: <Widget>[
        FlatButton(
          shape: const RoundedRectangleBorder(
            borderRadius: ThemeGuide.borderRadius10,
          ),
          color: appBarColor,
          child: const Text(
            AppStrings.yesUpperCase,
            style: TextStyle(
                fontSize: 16, color: Colors.white, fontFamily: fontMontserrat),
          ),
          onPressed: () {
            Navigator.of(context).pop(true);
          },
        ),
        FlatButton(
          shape: const RoundedRectangleBorder(
            borderRadius: ThemeGuide.borderRadius10,
          ),
          color: darkBlueColor,
          child: const Text(
            AppStrings.noUpperCase,
            style: TextStyle(
                fontSize: 16, color: Colors.white, fontFamily: fontMontserrat),
          ),
          onPressed: () {
            Navigator.of(context).pop(false);
          },
        )
      ],
    );
  }
}
