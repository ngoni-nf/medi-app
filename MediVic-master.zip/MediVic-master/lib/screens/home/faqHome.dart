import 'package:flutter/material.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_html/style.dart';
import 'package:medivic/const.dart';

class FaqHome extends StatefulWidget {
  FaqHome({Key key}) : super(key: key);

  @override
  _FaqHomeState createState() => _FaqHomeState();
}

class _FaqHomeState extends State<FaqHome> {
  String htmlData = '<p>Please wait</p>';
  bool _isLoading = true;

  void _getHtmlData() async {
    htmlData = await FirestoreService.getHTMLData('faq');
    setState(() {
      _isLoading = false;
    });
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          backgroundColor: appBarColor,
        ),
      );
    } else {
      return SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Html(
            data: htmlData ?? '',
            style: {
              'body': Style(
                fontFamily: fontMontserrat,
              ),
            },
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return _buildBody();
  }
}
