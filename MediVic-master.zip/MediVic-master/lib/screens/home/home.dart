// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:after_layout/after_layout.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/specialityModel.dart';
import 'package:medivic/screens/doctorList/doctorList.dart';
import 'package:medivic/screens/home/drawer_patient.dart';
import 'package:medivic/screens/notification/notification.dart';
import 'package:medivic/screens/search/searchScreen.dart';
import 'package:medivic/themes/themeGuide.dart';

///
/// ## `Description`
///
/// Home widget which is the main widget.
/// Returns the main interactive elements of the app at one place.
/// The app will ask for a surety check before exiting the application
/// which is handled by `WillPopScope` of the scaffold.
///
class Home extends StatefulWidget {
  const Home({Key key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> with AfterLayoutMixin<Home> {
  List<Map<String, String>> menus = [];

  int index = 0;
  final GlobalKey<ScaffoldState> _drawerKey = GlobalKey();

  @override
  void afterFirstLayout(BuildContext context) {}

  @override
  void initState() {
    super.initState();
    LocatorService.inActivityTimer().resetTimer();
    menus = Speciality.getSpecialities();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _drawerKey,
      appBar: _buildAppBar(),
      body: _buildBody(),
      endDrawer: DrawerPatient(),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: appBarColor,
      iconTheme: const IconThemeData(color: Colors.white),
      title: Text(
        'Welcome ' + LocatorService.userProvider().user.name,
        style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w400,
            fontFamily: fontMontserrat),
        maxLines: 2,
        textAlign: TextAlign.center,
      ),
      titleSpacing: -10,
      actions: _buildActions(context),
      leading: IconButton(
        icon: Image.asset('assets/notification.png', height: 24),
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => NotificationScreen()),
        ),
      ),
    );
  }

  List<Widget> _buildActions(BuildContext context) {
    return [
      IconButton(
        icon: Image.asset('assets/filter.png', height: 23),
        onPressed: () => _navigateToSearchScreen(true),
      ),
      IconButton(
        icon: const Icon(Icons.menu, size: 28),
        onPressed: () => _drawerKey.currentState.openEndDrawer(),
      ),
    ];
  }

  Widget _buildBody() {
    return Container(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Container(
              height: 88,
              padding: const EdgeInsets.all(12),
              child: TextField(
                decoration: const InputDecoration(
                  contentPadding: EdgeInsets.symmetric(horizontal: 24),
                  hintText:
                      'Search medical practitioner by name, speciality, location',
                  filled: true,
                  hintStyle:
                      TextStyle(fontSize: 14, fontFamily: fontMontserrat),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(24)),
                  ),
                ),
                onChanged: (val) {
                  LocatorService.searchProvider().setSearchTerm = val.trim();
                },
                onEditingComplete: () {
                  FocusScope.of(context).unfocus();
                  _navigateToSearchScreen(false);
                },
              ),
            ),
            Container(
              child: StaggeredGridView.count(
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                shrinkWrap: true,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
                children: List.generate(
                  24,
                  (index) {
                    return InkWell(
                      onTap: () => _navigateToDoctorList(menus[index]['name']),
                      child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          // border: Border.all(width: 1, color: Colors.green),
                          image: const DecorationImage(
                            image: AssetImage(
                                'lib/assets/images/icon-background.png'),
                            fit: BoxFit.fill,
                          ),
                          borderRadius: BorderRadius.circular(16.0),
                        ),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              flex: 2,
                              child: Image.asset(
                                menus[index]['icon'],
                              ),
                            ),
                            const SizedBox(width: 5),
                            Expanded(
                              flex: 3,
                              child: Text(
                                menus[index]['name'],
                                style: const TextStyle(
                                    color: Colors.black54,
                                    fontSize: 11,
                                    fontFamily: fontMontserrat,
                                    fontWeight: FontWeight.bold),
                              ),
                            )
                          ],
                        ),

                        // color: Colors.red,
                      ),
                    );
                  },
                ),
                staggeredTiles: List.generate(
                  24,
                  (index) {
                    return const StaggeredTile.extent(1, 65.0);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _navigateToSearchScreen(bool showFilterAtStart) {
    LocatorService.searchProvider().resetDoctorFilter();
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) =>
              SearchScreen(showFilterAtStart: showFilterAtStart)),
    );
  }

  AlertDialog _buildAlertDialog() {
    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      backgroundColor: Colors.white,
      title: const Text(
        AppStrings.exitQues,
        textAlign: TextAlign.center,
        style: TextStyle(fontFamily: fontMontserrat),
      ),
      titleTextStyle: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          color: Colors.black,
          fontFamily: fontMontserrat),
      actions: <Widget>[
        FlatButton(
          shape: const RoundedRectangleBorder(
            borderRadius: ThemeGuide.borderRadius10,
          ),
          color: Colors.red,
          child: const Text(
            AppStrings.yesUpperCase,
            style: TextStyle(
                fontSize: 16, color: Colors.white, fontFamily: fontMontserrat),
          ),
          onPressed: () {
            Navigator.of(context).pop(true);
          },
        ),
        FlatButton(
          shape: const RoundedRectangleBorder(
            borderRadius: ThemeGuide.borderRadius10,
          ),
          color: darkBlueColor,
          child: const Text(
            AppStrings.noUpperCase,
            style: TextStyle(
                fontSize: 16, color: Colors.white, fontFamily: fontMontserrat),
          ),
          onPressed: () {
            Navigator.of(context).pop(false);
          },
        )
      ],
    );
  }

  void _navigateToDoctorList(String speciality) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => DoctorsList(speciality: speciality)),
    );
  }
}
