import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/screens/doctorsAccountScreens/appointments/doctor_appointments.dart';
import 'package:medivic/screens/doctorsAccountScreens/earnings/earnings.dart';
import 'package:medivic/screens/doctorsAccountScreens/homeDoctor/homeDoctor.dart';
import 'package:medivic/screens/doctorsAccountScreens/homeDoctor/profile.dart';
import 'package:medivic/screens/doctorsAccountScreens/schedulePlanning/schedule_planning.dart';
import 'package:medivic/themes/themeGuide.dart';

class MainScreenDoctor extends StatefulWidget {
  const MainScreenDoctor({Key key}) : super(key: key);

  @override
  _MainScreenDoctorState createState() => _MainScreenDoctorState();
}

class _MainScreenDoctorState extends State<MainScreenDoctor> {
  int selectedIndex = 0;
  PageController tabController;

  @override
  void initState() {
    super.initState();
    tabController = PageController();
  }

  AlertDialog _buildAlertDialog() {
    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      backgroundColor: Colors.white,
      title: const Text(
        AppStrings.exitQues,
        textAlign: TextAlign.center,
        style: TextStyle(fontFamily: fontMontserrat),
      ),
      titleTextStyle: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          color: Colors.black,
          fontFamily: fontMontserrat),
      actions: <Widget>[
        FlatButton(
          shape: const RoundedRectangleBorder(
            borderRadius: ThemeGuide.borderRadius10,
          ),
          color: appBarColor,
          child: const Text(
            AppStrings.yesUpperCase,
            style: TextStyle(
                fontSize: 16, color: Colors.white, fontFamily: fontMontserrat),
          ),
          onPressed: () {
            Navigator.of(context).pop(true);
          },
        ),
        FlatButton(
          shape: const RoundedRectangleBorder(
            borderRadius: ThemeGuide.borderRadius10,
          ),
          color: darkBlueColor,
          child: const Text(
            AppStrings.noUpperCase,
            style: TextStyle(
                fontSize: 16, color: Colors.white, fontFamily: fontMontserrat),
          ),
          onPressed: () {
            Navigator.of(context).pop(false);
          },
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: WillPopScope(
        onWillPop: () {
          return showDialog(
              context: context,
              builder: (BuildContext context) => _buildAlertDialog());
        },
        child: PageView(
          physics: const NeverScrollableScrollPhysics(),
          controller: tabController,
          onPageChanged: onTabChanged,
          children: [
            const HomeDoctor(),
            SchedulePlanningScreen(),
            // const DoctorAppointmentListScreen(),
            EarningsScreen(),
            const DoctorProfileScreen(),
          ],
        ),
      ),
      bottomNavigationBar: bottomBar(),
    );
  }

  BottomNavigationBarItem customBarItem(String title, String assetImg) {
    return BottomNavigationBarItem(
      icon: Padding(
        padding: const EdgeInsets.all(5.0),
        child: Image.asset(assetImg, height: 20),
      ),
      title: Text(title),
    );
  }

  Widget bottomBar() {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      currentIndex: selectedIndex,
      selectedItemColor: Colors.blue[300],
      items: [
        customBarItem('Sessions', 'assets/home.png'),
        customBarItem('Schedule', 'assets/schedule-icon.png'),
        // customBarItem('Sessions', 'assets/cal.png'),
        customBarItem('Earnings', 'assets/earning.png'),
        customBarItem('Profile', 'assets/profile-icon.png'),
      ],
      onTap: (index) {
        setState(() {
          selectedIndex = index;
          tabController.animateToPage(
            index,
            duration: const Duration(milliseconds: 300),
            curve: Curves.ease,
          );
        });
      },
    );
  }

  void onTabChanged(int tabIndex) {}
}
