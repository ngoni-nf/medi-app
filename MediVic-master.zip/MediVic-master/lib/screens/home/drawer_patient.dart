import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/controllers/authController.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/screens/accountInfo/medicineCourse.dart';
import 'package:medivic/screens/accountInfo/myDocuments.dart';
import 'package:medivic/screens/appointment/patient_appointments.dart';
import 'package:medivic/screens/doctorsAccountScreens/prescription/view_prescription_patient.dart';
import 'package:medivic/screens/more/contact_us.dart';
import 'package:medivic/screens/more/load_html_screen.dart';
import 'package:medivic/screens/splash/choose_screen.dart';
import 'package:medivic/shared/webViewScreen.dart';

class DrawerPatient extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: Padding(
            padding: const EdgeInsets.only(top: 0.0),
            child: Scrollbar(
                child: ListView(
              scrollDirection: Axis.vertical,
              children: <Widget>[
                Container(
                  height: 100,
                  color: appBarColor,
                  child: Stack(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            ClipOval(
                              child: CachedNetworkImage(
                                  placeholder: (context, url) => const Center(
                                        child: CircularProgressIndicator(
                                          backgroundColor: appBarColor,
                                        ),
                                      ),
                                  fit: BoxFit.cover,
                                  width: 60,
                                  height: 60,
                                  imageUrl: LocatorService.userProvider()
                                      .user
                                      .imageUrl),
                            ),
                            Expanded(
                              child: Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 12),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Text(
                                        LocatorService.userProvider()
                                                .user
                                                ?.name ??
                                            LocatorService.doctorProvider()
                                                .doctor
                                                ?.name ??
                                            '',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 14,
                                            fontFamily: fontMontserrat)),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                menu('My Prescriptions', 'prescription.png', () {
                  Navigator.of(context).pop();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) =>
                              ViewPrescriptionPatient()));
                }),
                menu('My Appointments', 'appointment.png', () {
                  Navigator.of(context).pop();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) =>
                              PatientAppointmentListScreen()));
                }),
                menu('My Documents', 'document.png', () {
                  Navigator.of(context).pop();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) => MyDocuments()));
                }),
                menu('About Us', 'info.png', () {
                  Navigator.of(context).pop();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) => LoadHTML(
                                title: 'About Us',
                                field: 'about',
                              )));
                }),
                menu('Contact Us', 'contact.png', () {
                  Navigator.of(context).pop();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) => ContactsUs(
                                isPatient: true,
                              )));
                }),
                menu('Privacy Policy', 'privacy.png', () {
                  Navigator.of(context).pop();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) => LoadHTML(
                                title: 'Privacy Policy',
                                field: 'policy',
                              )));
                }),
                menu('Standard Terms & Conditions', 'terms-and-conditions.png',
                    () {
                  Navigator.of(context).pop();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) => LoadHTML(
                                title: 'Standard Terms & Conditions',
                                field: 'terms',
                              )));
                }),
                menu('Consult Terms & Conditions', 'terms-and-conditions.png',
                    () {
                  Navigator.of(context).pop();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) => LoadHTML(
                                title: 'Consult Terms & Conditions',
                                field: 'terms2',
                              )));
                }),
                menu('FAQs', 'faq.png', () {
                  Navigator.of(context).pop();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) => LoadHTML(
                                title: 'FAQs',
                                field: 'faq',
                              )));
                }),
                menu('Logout', 'logout.png', () async {
                  Navigator.of(context).pop();
                  await AuthController.logout();
                  Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (BuildContext context) => Choose(),
                      ),
                      (route) => false);
                }),
              ],
            ))));
  }

  Widget menu(String title, String assetIconName, Function onTapFunc) {
    return ListTile(
      onTap: () {
        onTapFunc();
      },
      leading: Image.asset(
        'lib/assets/icons/$assetIconName',
        width: 25,
      ),
      title: Text(
        title,
        style:
            const TextStyle(color: darkBlueColor, fontFamily: fontMontserrat),
      ),
    );
  }
}
