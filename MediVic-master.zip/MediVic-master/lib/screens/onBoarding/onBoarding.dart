
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/controllers/navigationController.dart';
import 'package:medivic/screens/splash/choose_screen.dart';
import 'package:medivic/services/storage/localStorage.dart';
import 'package:medivic/services/storage/storageConstants.dart';
import 'package:medivic/themes/theme.dart';
import 'package:medivic/themes/themeGuide.dart';

class OnBoarding extends StatefulWidget {
  const OnBoarding({Key key}) : super(key: key);

  @override
  _OnBoardingState createState() => _OnBoardingState();
}

class _OnBoardingState extends State<OnBoarding> with SingleTickerProviderStateMixin {
  AnimationController _controller;
  Animation _animation;
  bool isDone = false;

  @override
  void initState() {
    super.initState();

    // Controller that controls the animation.
    _controller = AnimationController(duration: const Duration(milliseconds: 500), vsync: this);

    // Type of animation to perform for `Logo`
    _animation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutBack,
    );
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  static const PageDecoration _decoration = PageDecoration(
    bodyTextStyle: TextStyle(fontWeight: FontWeight.w500, fontSize: 14.0, color: Colors.black38, fontFamily: fontMontserrat),
  );

  static List<PageViewModel> listPagesViewModel = [
    PageViewModel(
      titleWidget: const Text(
        AppStrings.title1,
        style: TextStyle(color: Colors.black, fontFamily: fontMontserrat, fontSize: 18, fontWeight: FontWeight.bold),
      ),
      body: AppStrings.desc1,
      image: _buildImage('lib/assets/svg/icon1.svg'),
      decoration: _decoration,
    ),
    /*
    PageViewModel(
      title: AppStrings.title2,
      body: AppStrings.desc2,
      image: _buildImage('lib/assets/svg/icon2.svg'),
      decoration: _decoration,
    ),*/
    PageViewModel(
      titleWidget: const Text(
        AppStrings.title3,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: Colors.black,
          fontFamily: fontMontserrat,
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      body: AppStrings.desc3,
      image: _buildImage('lib/assets/svg/icon3.svg'),
      decoration: _decoration,
    ),
    PageViewModel(
      titleWidget: const Text(
        AppStrings.title4,
        style: TextStyle(color: Colors.black, fontFamily: fontMontserrat, fontSize: 18, fontWeight: FontWeight.bold),
      ),
      body: AppStrings.desc4,
      image: _buildImage('lib/assets/svg/cardiogram.svg'),
      decoration: _decoration,
    ),
  ];

  static Widget _buildImage(String assetUrl) {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(20.0),
        decoration: const BoxDecoration(
          borderRadius: ThemeGuide.borderRadius10,
        ),
        child: SvgPicture.asset(
          assetUrl,
          height: 200,
          width: 200,
          fit: BoxFit.contain,
        ),
      ),
    );
  }

  static Widget _buildButton({
    @required String title,
    Function onPress,
    Color color,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: CupertinoButton(
        color: color ?? LightTheme.mRed,
        onPressed: () {
          onPress();
        },
        child: Center(
          child: Text(
            title,
            style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w500, fontFamily: fontMontserrat),
          ),
        ),
      ),
    );
  }

  Future<void> updateInitialInstall() async {
    if (isDone) {
      await LocalStorage.setString(LocalStorageConstants.INITIAL_INSTALL, 'false');
    }
  }

  static void _goToLogin(BuildContext context) {

   NavigationController.navigator.pushReplacementNamed(Routes.choose);
  }

  static void _goToSignUp() {
    NavigationController.navigator.pushReplacementNamed(Routes.signup);
  }

  Future<void> onDone() async {
    setState(() {
      isDone = true;
    });
    // Update the initial install flag
    await updateInitialInstall();
  }

  @override
  Widget build(BuildContext context) {
    return IntroductionScreen(
      showNextButton: true,
      pages: listPagesViewModel,
      onDone: () {
        isDone=true;
        updateInitialInstall();
        _goToLogin(context);
      },
      showSkipButton: true,
      skip: const Text(
        'Skip',
        style: TextStyle(fontFamily: fontMontserrat),
      ),
      next: const Text(
        'Next',
        style: TextStyle(fontFamily: fontMontserrat),
      ),
      done: const Text(
        'Done',
        style: TextStyle(fontWeight: FontWeight.w600, fontFamily: fontMontserrat),
      ),
      dotsDecorator: DotsDecorator(
        size: const Size.square(10.0),
        activeSize: const Size(20.0, 10.0),
        activeColor: LightTheme.mBlue,
        color: Colors.black12,
        spacing: const EdgeInsets.symmetric(horizontal: 3.0),
        activeShape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25.0),
        ),
      ),
    );
  }
}
