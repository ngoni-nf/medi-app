import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:medivic/const.dart';
import 'package:medivic/screens/more/profile_screen.dart';
import 'package:medivic/utils/hex_color.dart';

class MyAppointments extends StatefulWidget {
  @override
  _MyAppointmentsState createState() => _MyAppointmentsState();
}

class _MyAppointmentsState extends State<MyAppointments> {
  int selected = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const IconButton(
            icon: Icon(
              Icons.search,
              color: Colors.white,
              size: 30,
            ),
            onPressed: null),
        title: const Text(
          'My Appointments',
          style: styleAppbarTitle,
        ),
        actions: [
          IconButton(
              icon: Image.asset(
                'assets/notification.png',
                height: 25,
              ),
              onPressed: () {})
        ],
        backgroundColor: appBarColor,
      ),
      body: Container(
        child: Column(
          children: [
            selectionSide(),
            SizedBox(
              height: 10,
            ),
            Expanded(child: listView())
          ],
        ),
      ),
    );
  }

  Widget selectionSide() {
    return Center(
      child: Container(
        margin: const EdgeInsets.only(top: 20),
        height: 45,
        width: MediaQuery.of(context).size.width * 0.85,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(32),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.3),
              spreadRadius: 5,
              blurRadius: 7,
              offset: Offset(0, 3), // changes position of shadow
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              flex: 1,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(32),
                child: Container(
                  height: 45,
                  child: RaisedButton(
                    onPressed: () {
                      setState(() {
                        selected = 0;
                      });
                    },
                    color: selected == 0 ? darkBlueColor : Colors.white,
                    child: Text(
                      "Current",
                      style: TextStyle(
                          color: selected == 0 ? Colors.white : Colors.grey,  fontFamily: fontMontserrat),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              flex: 1,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(32),
                child: Container(
                  height: 45,
                  child: RaisedButton(
                    onPressed: () {
                      setState(() {
                        selected = 1;
                      });
                    },
                    color: selected == 1 ? darkBlueColor : Colors.white,
                    child: Text(
                      "Scheduled",
                      style: TextStyle(
                          color: selected == 1 ? Colors.white : Colors.grey,  fontFamily: fontMontserrat),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              flex: 1,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(32),
                child: Container(
                  height: 45,
                  child: RaisedButton(
                    onPressed: () {
                      setState(() {
                        selected = 2;
                      });
                    },
                    color: selected == 2 ? darkBlueColor : Colors.white,
                    child: Text(
                      "Payments",
                      style: TextStyle(
                          color: selected == 2 ? Colors.white : Colors.grey,  fontFamily: fontMontserrat),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget listView() {
    return ListView.builder(
      shrinkWrap: true,
      itemCount: 5,
      itemBuilder: (context, index) {
        return InkWell(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (BuildContext context) => ProfileScreen()));
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            height: 120,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: Offset(0, 3), // changes position of shadow
                ),
              ],
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundImage: AssetImage("assets/user.png"),
                ),
                SizedBox(
                  width: 20,
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Mathew marieson",style: TextStyle(  fontFamily: fontMontserrat),),
                    SizedBox(
                      height: 8,
                    ),
                    RatingBar(
                      initialRating: 5,
                      minRating: 1,
                      direction: Axis.horizontal,
                      allowHalfRating: false,
                      itemCount: 5,
                      ignoreGestures: true,
                      itemSize: 15,
                      itemBuilder: (context, _) => Icon(
                        Icons.star,
                        color: Colors.amber,
                      ),
                      onRatingUpdate: (rating) {
                        print(rating);
                      },
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      "Date: 19 May 2020",
                      style: TextStyle(color: Colors.grey, fontSize: 12,  fontFamily: fontMontserrat),
                    ),
                    Text(
                      "Time: 10 AM",
                      style: TextStyle(color: Colors.grey, fontSize: 12,  fontFamily: fontMontserrat),
                    ),
                  ],
                )
              ],
            ),
          ),
        );
      },
    );
  }
}
