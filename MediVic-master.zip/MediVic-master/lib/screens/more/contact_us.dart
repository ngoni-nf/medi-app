import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/screens/doctorsAccountScreens/homeDoctor/drawerDoctor.dart';
import 'package:medivic/screens/home/drawer_patient.dart';
import 'package:medivic/services/api/firestoreService.dart';

import '../../const.dart';

class ContactsUs extends StatefulWidget {
  final bool isPatient;

  const ContactsUs({Key key, this.isPatient}) : super(key: key);

  @override
  _PrivacyPolicyState createState() => _PrivacyPolicyState();
}

class _PrivacyPolicyState extends State<ContactsUs> {
  TextEditingController controllerMsg = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text('Contact Us', style: styleAppbarTitle),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
          color: Colors.white,
        ),
        backgroundColor: appBarColor,
      ),
      endDrawer: widget.isPatient ? DrawerPatient() : DrawerDoctor(),
      body: Padding(
        padding: const EdgeInsets.all(25.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: controllerMsg,
                maxLines: 6,
                textAlign: TextAlign.left,
                keyboardType: TextInputType.multiline,
                decoration: InputDecoration(
                  hintText: 'Write message',
                  hintStyle: const TextStyle(fontSize: 18),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: const BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                    ),
                  ),
                  filled: true,
                  contentPadding: const EdgeInsets.all(16),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.8,
                child: RaisedButton(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                  child: const Text(
                    'Send',
                    style: TextStyle(color: Colors.white, fontFamily: fontMontserrat),
                  ),
                  onPressed: () => _sendToAdmin(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _sendToAdmin() async {
    String msg=controllerMsg.text;
    if(msg.isEmpty){
      Fluttertoast.showToast(msg: 'Something went wrong!');
      return;
    }
    String userId = widget.isPatient ? LocatorService.userProvider().user.uid : LocatorService.doctorProvider().doctor.uid;
    final result = await FirestoreService.saveToContactUs(userId, controllerMsg.text);
    if (result) {
      Fluttertoast.showToast(msg: 'Your query is sent to admin successfully');
      controllerMsg.text = '';
    } else
      Fluttertoast.showToast(msg: 'Something went wrong!');
  }

  Widget inputField(String hint, bool isNumber) {
    return TextField(
      textAlign: TextAlign.left,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(fontSize: 18, fontFamily: fontMontserrat),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: const BorderSide(
            width: 0,
            style: BorderStyle.none,
          ),
        ),
        filled: true,
        contentPadding: const EdgeInsets.all(16),
      ),
    );
  }
}
