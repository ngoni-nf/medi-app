import 'package:flutter/material.dart';

import '../../const.dart';

class TermsConditions extends StatefulWidget {
  @override
  _PrivacyPolicyState createState() => _PrivacyPolicyState();
}

class _PrivacyPolicyState extends State<TermsConditions> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Terms & Conditions', style: styleAppbarTitle),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
          color: Colors.white,
        ),
        backgroundColor: appBarColor,
      ),
      body: Container(
        padding: const EdgeInsets.all(25),
        child: SingleChildScrollView(
          child: Text(
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras ut accumsan nibh, at condimentum dui. Etiam ac sem odio. "
              "Ut eu dapibus augue. Aliquam sed laoreet erat, nec laoreet ligula. Duis mattis cursus turpis, tempor tristique nunc blandit id. Maecenas nibh nulla, finibus eget elementum condimentum, viverra at elit. Suspendisse tellus magna, suscipit eget fringilla quis, accumsan sed orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer sed luctus augue, eu mollis elit. Aenean sed vulputate ante, et hendrerit libero.\nSuspendisse nec justo feugiat tellus convallis vestibulum. Sed at erat vitae eros malesuada dictum eu at urna. Aliquam vitae dolor nisi. Aenean eget justo sed mi porta lobortis ac et libero. Mauris a mauris nibh. Donec auctor non velit ut placerat. In libero magna, egestas non eros in, lobortis dictum urna. Maecenas eget eros mattis, fermentum odio quis, bibendum neque. "
              "Nullam quis lorem a sapien congue porta. Pellentesque a ullamcorper turpis. Fusce purus lorem, porttitor nec ornare nec, mattis a nisi.Suspendisse nec justo feugiat tellus convallis vestibulum. Sed at erat vitae eros malesuada dictum eu at urna. Aliquam vitae dolor nisi. Aenean eget justo sed mi porta lobortis ac et libero. Mauris a mauris nibh. Donec auctor non velit ut placerat. In libero magna, egestas non eros in, lobortis dictum urna. Maecenas eget eros mattis, fermentum odio quis, bibendum neque. Nullam quis lorem a sapien congue porta. Pellentesque a ullamcorper turpis. Fusce purus lorem, porttitor nec ornare nec, mattis a nisi.",
              style: TextStyle(color: Colors.black, fontSize: 18)),
        ),
      ),
    );
  }
}
