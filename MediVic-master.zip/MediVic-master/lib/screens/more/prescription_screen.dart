import 'package:flutter/material.dart';
import 'package:medivic/const.dart';

class PrescriptionScreen extends StatefulWidget {
  PrescriptionScreen({Key key}) : super(key: key);

  @override
  _PrescriptionScreenState createState() => _PrescriptionScreenState();
}

class _PrescriptionScreenState extends State<PrescriptionScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Prescription',
          style: styleAppbarTitle,
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
          color: Colors.white,
        ),
        backgroundColor: appBarColor,
      ),
      body: Container(
        color: Colors.white,
        padding: const EdgeInsets.all(4.0),
        child: ListView(children: [
          MoreContainer("Dr. John Watson"),
        ]),
      ),
    );
  }
}

class MoreContainer extends StatelessWidget {
  final String containerText;

  MoreContainer(this.containerText);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(0.0),
      child: Container(
        margin: EdgeInsets.all(10),
        height: 80.0,
        child: ClipRRect(
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(15),
            bottomRight: Radius.circular(15),
          ),
          child: Row(
            children: [
              Container(
                width: 15.0,
                decoration: const BoxDecoration(
                  color: Color(0xffccccccc),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),
                    bottomLeft: Radius.circular(15),
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  height: 80,
                  decoration: BoxDecoration(
                    border: Border.all(color: Color(0xffcccccc)),
                    color: Colors.white,
                    boxShadow: [
                      new BoxShadow(
                        color: Color(0xffcccccc),
                        blurRadius: 6.0,
                        offset: Offset(1.0, 5.0),
                        spreadRadius: 0.5,
                      ),
                    ],
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(15),
                      bottomRight: Radius.circular(15),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(30, 16, 16, 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              containerText,
                              style: TextStyle(fontSize: 18, fontFamily: 'Montserrat', fontWeight: FontWeight.w400),
                            ),
                            Text(
                              "10 Mins ago",
                              style: TextStyle(fontSize: 14, color: Colors.grey, fontFamily: 'Montserrat', fontWeight: FontWeight.w400),
                            ),
                          ],
                        ),
                        IconButton(
                          icon: Icon(
                            Icons.arrow_forward,
                            color: Color(0xffcccccc),
                          ),
                          onPressed: () {},
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
