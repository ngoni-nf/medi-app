import 'package:flutter/material.dart';

import '../../const.dart';

class History extends StatefulWidget {
  @override
  _PrivacyPolicyState createState() => _PrivacyPolicyState();
}

class _PrivacyPolicyState extends State<History> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('History', style: styleAppbarTitle),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
          color: Colors.white,
        ),
        backgroundColor: appBarColor,
      ),
      body: history(),
    );
  }

  bool _isSelectPayment = false;

  Widget history() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            margin: const EdgeInsets.all(20),
            height: 45,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(32),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.3),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: Offset(0, 3), // changes position of shadow
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  flex: 1,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(32),
                    child: Container(
                      height: 45,
                      child: RaisedButton(
                        onPressed: () {
                          setState(() {
                            _isSelectPayment = false;
                          });
                        },
                        color: _isSelectPayment ? Colors.white : darkBlueColor,
                        child: Text(
                          "Consultations",
                          style: TextStyle(color: _isSelectPayment ? Colors.grey : Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(32),
                    child: Container(
                      height: 45,
                      child: RaisedButton(
                        onPressed: () {
                          setState(() {
                            _isSelectPayment = true;
                          });
                        },
                        color: _isSelectPayment ? darkBlueColor : Colors.white,
                        child: Text(
                          "Payments",
                          style: TextStyle(color: _isSelectPayment ? Colors.white : Colors.grey),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: 3,
              itemBuilder: (context, index) {
                return Container(
                  margin: const EdgeInsets.all(10),
                  height: 60,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      const ClipRRect(
                        borderRadius: BorderRadius.only(topLeft: Radius.circular(16), bottomLeft: Radius.circular(16)),
                        child: SizedBox(
                          child: ColoredBox(color: Colors.grey),
                          width: 16,
                          height: 60,
                        ),
                      ),
                      const SizedBox(
                        width: 16,
                      ),
                      const Expanded(
                        flex: 3,
                        child: Text(
                          "You have received a payment of R60 from kelvin joe on 13 July 2020",
                          style: TextStyle(fontSize: 10, color: Colors.black38),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "R 60",
                            style: TextStyle(color: appBarColor, fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                          Text(
                            "20 July 2020",
                            style: TextStyle(fontSize: 10, color: Colors.black38),
                          )
                        ],
                      ),
                      const SizedBox(
                        width: 16,
                      )
                    ],
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
