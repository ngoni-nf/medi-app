import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_html/style.dart';
import 'package:medivic/const.dart';
import 'package:medivic/services/api/firestoreService.dart';

class LoadHTML extends StatefulWidget {
  final String field;
  final String title;

  LoadHTML({Key key, this.field, this.title}) : super(key: key);

  @override
  _LoadHTMLState createState() => _LoadHTMLState();
}

class _LoadHTMLState extends State<LoadHTML> {
  String htmlData = '<p>Please wait</p>';
  bool _isLoading = true;

  void _getHtmlData() async {
    htmlData = await FirestoreService.getHTMLData(widget.field);
    setState(() {
      _isLoading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    _getHtmlData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          widget.title,
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          backgroundColor: appBarColor,
        ),
      );
    } else {
      return SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Html(
            data: htmlData ?? '',
            style: {
              'body': Style(
                fontFamily: fontMontserrat,
              ),
            },
          ),
        ),
      );
    }
  }
}
