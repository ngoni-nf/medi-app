import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:medivic/const.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Profile',
          style: styleAppbarTitle,
        ),
        backgroundColor: appBarColor,
        actions: [
          IconButton(
            icon: const Icon(
              Icons.video_call,
              color: Colors.white,
            ),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(
              Icons.call,
              color: Colors.white,
            ),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(
              Icons.chat_bubble,
              color: Colors.white,
            ),
            onPressed: () {},
          )
        ],
      ),
      body: Container(
        color: Colors.grey[300],
        child: Column(
          children: [
            header(),
            Container(
              color: Colors.white,
              height: 40,
              child: Row(
                children: [
                  SizedBox(
                    width: 20,
                  ),
                  Expanded(
                      child: Text(
                    "Full Name",
                    style: TextStyle(
                      color: Colors.grey,
                    ),
                  )),
                  Expanded(child: Text("Kevin Zine"))
                ],
              ),
            ),
            Container(
              height: 40,
              child: Row(
                children: [
                  SizedBox(
                    width: 20,
                  ),
                  Expanded(
                      child: Text(
                    "Speciality",
                    style: TextStyle(
                      color: Colors.grey,
                    ),
                  )),
                  Expanded(child: Text("Skin Specialist"))
                ],
              ),
            ),
            Container(
              color: Colors.white,
              height: 40,
              child: Row(
                children: [
                  SizedBox(
                    width: 20,
                  ),
                  Expanded(
                      child: Text(
                    "Consultation Fee",
                    style: TextStyle(
                      color: Colors.grey,
                    ),
                  )),
                  Expanded(child: Text("R 60"))
                ],
              ),
            ),
            Container(
              height: 40,
              child: Row(
                children: [
                  SizedBox(
                    width: 20,
                  ),
                  Expanded(
                      child: Text(
                    "Age",
                    style: TextStyle(
                      color: Colors.grey,
                    ),
                  )),
                  Expanded(child: Text("30"))
                ],
              ),
            ),
            Container(
              color: Colors.white,
              height: 40,
              child: Row(
                children: [
                  SizedBox(
                    width: 20,
                  ),
                  Expanded(
                    child: Text(
                      "Availability",
                      style: TextStyle(
                        color: Colors.grey,
                      ),
                    ),
                  ),
                  Expanded(child: Text("Mon-Fri"))
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget header() {
    return Container(
      color: Colors.grey[300],
      height: MediaQuery
          .of(context)
          .size
          .height * 0.46,
      child: Column(
        children: [
          Container(
            color: Colors.grey[300],
            height: MediaQuery
                .of(context)
                .size
                .height * 0.35,
            child: Stack(
              children: [
                CachedNetworkImage(
                  imageUrl:
                  "https://images.unsplash.com/photo-1586882829491-b81178aa622e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2850&q=80",
                  width: MediaQuery
                      .of(context)
                      .size
                      .width,
                  height: MediaQuery
                      .of(context)
                      .size
                      .height * 0.3,
                  fit: BoxFit.cover,
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: CircleAvatar(
                    radius: 60,
                    backgroundColor: Colors.white,
                    child: CircleAvatar(
                      radius: 55,
                      backgroundImage: AssetImage("assets/girl.png"),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              "Dr. marie Watson",
              style: TextStyle(color: Colors.black, fontSize: 18),
            ),
          ),
          RatingBar(
            initialRating: 5,
            minRating: 1,
            direction: Axis.horizontal,
            allowHalfRating: true,
            itemCount: 5,
            itemSize: 20,
            glow: false,
            itemBuilder: (context, _) =>
                Icon(
                  Icons.star,
                  color: Colors.amber[800],
                ),
            onRatingUpdate: (rating) {
              print(rating);
            },
          )
        ],
      ),
    );
  }
}
