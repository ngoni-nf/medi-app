import 'package:flutter/material.dart';

import '../../const.dart';

class Blogs extends StatefulWidget {
  @override
  _PrivacyPolicyState createState() => _PrivacyPolicyState();
}

class _PrivacyPolicyState extends State<Blogs> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        title: Text('Blogs', style: styleAppbarTitle),
        backgroundColor: appBarColor,
      ),
      body: ListView.builder(
          itemCount: 10,
          itemBuilder: (BuildContext context, int index) {
            return Padding(
              padding: const EdgeInsets.all(25.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        maxRadius: 30,
                        backgroundImage: AssetImage("assets/user.png"),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Dr. marie Watson",
                            style: TextStyle(color: Colors.black, fontSize: 16),
                          ),
                          Text(
                            "3:23 AM",
                            style: TextStyle(color: Colors.black38),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras ut accumsan nibh, at condimentum dui. Etiam ac sem odio. Ut eu dapibus augue. Aliquam sed laoreet erat, nec laoreet ligula. Duis mattis cursus turpis, tempor tristique nunc blandit id. Maecenas nibh nulla, finibus eget elementum condimentum, viverra at elit. Suspendisse tellus magna, suscipit eget fringilla quis",
                    style: TextStyle(color: Colors.black38),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Image.asset(
                    "assets/teeth.png",
                    height: 80,
                  ),
                ],
              ),
            );
          }),
    );
  }
}
