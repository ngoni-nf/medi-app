import 'package:flutter/material.dart';
import 'package:medivic/screens/doctorsAccountScreens/homeDoctor/drawerDoctor.dart';
import 'package:medivic/screens/home/drawer_patient.dart';
import 'package:medivic/screens/notification/notification.dart';

import '../../const.dart';

class NewsFeed extends StatefulWidget {
  final bool isPatient;

  const NewsFeed({Key key, this.isPatient}) : super(key: key);
  @override
  _PrivacyPolicyState createState() => _PrivacyPolicyState();
}

class _PrivacyPolicyState extends State<NewsFeed> {
  final GlobalKey<ScaffoldState> _drawerKey = GlobalKey();
  List<String> title = [
    'Mandatory COVID-19 Tests',
    'COVID-19 Clinical Trials Progress',
    'UCT breakthrough in Diabetes research',
  ];
  List<String> date = [
    '01/09/2020',
    '27/08/2020',
    '25/08/2020',
  ];
  List<String> time = [
    '09:15 AM',
    '10:07 AM',
    '07:01 AM',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _drawerKey,
      appBar: AppBar(
        title: const Text('News Feed', style: styleAppbarTitle),
        backgroundColor: appBarColor,
        leading: IconButton(
          icon: Image.asset('assets/notification.png', height: 24),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => NotificationScreen()),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.menu,
              size: 28,
              color: Colors.white,
            ),
            onPressed: () => _drawerKey.currentState.openEndDrawer(),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ListView.separated(
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                                image: const DecorationImage(
                                  image: ExactAssetImage(
                                      "lib/assets/images/newspaper.png"),
                                ),
                                border: Border.all(color: Colors.black),
                                borderRadius: BorderRadius.circular(10)),
                          ),
//                          ClipRRect(borderRadius: BorderRadius.circular(10),child: Image.asset("assets/user.png"),),
                          const SizedBox(
                            width: 10,
                          ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  title[index],
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 16,
                                      fontFamily: fontMontserrat),
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Health News Journal",
                                      style: TextStyle(
                                          color: Colors.black38,
                                          fontSize: 12,
                                          fontFamily: fontMontserrat),
                                    ),
                                    Column(
                                      children: [
                                        Text(
                                          date[index],
                                          style: TextStyle(
                                              color: Colors.black38,
                                              fontSize: 12,
                                              fontFamily: fontMontserrat),
                                        ),
                                        Text(
                                          time[index],
                                          style: TextStyle(
                                              color: Colors.black38,
                                              fontSize: 12,
                                              fontFamily: fontMontserrat),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                  separatorBuilder: (context, index) => Divider(
                        height: 2,
                      ),
                  itemCount: 3),
            ),
          ],
        ),
      ),
      endDrawer:  widget.isPatient ? DrawerPatient() : DrawerDoctor(),
    );
  }
}
