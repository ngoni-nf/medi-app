import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geocoder/geocoder.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:medivic/const.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/models/mAddress.dart';

class GoogleMapScreen extends StatefulWidget {
  final double lat, lng;
  final bool isLock;

  const GoogleMapScreen({Key key, this.lat, this.lng, this.isLock})
      : super(key: key);

  @override
  _GoogleMapScreenState createState() => _GoogleMapScreenState();
}

class _GoogleMapScreenState extends State<GoogleMapScreen> {
  final Geolocator geolocator = Geolocator()..forceAndroidLocationManager;

  String _currentAddress = '';
  final Completer<GoogleMapController> _controller = Completer();
  double latitude;
  double longitude;
  LatLng latLan;
  Location location;
  LocationData myLocation;
  bool _serviceEnabled;
  PermissionStatus _permissionGranted;

  var coordinates;
  static CameraPosition _currentPlace = const CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );

  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
  MarkerId selectedMarker;

  _initMethod() async {
    await getUserLocation(false);
    latitude = myLocation.latitude;
    longitude = myLocation.longitude;
    marker(latLan);
    _currentPlace = CameraPosition(
      target: latLan,
      zoom: 14.4746,
    );
    _goToCurrentLocation();
    setState(() {});
  }

  Future getUserLocation(bool isFromMarker) async {
    String error;
    location = Location();

    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }

    try {
      myLocation = await location.getLocation();
    } on PlatformException catch (e) {
      if (e.code == 'PERMISSION_DENIED') {
        error = 'please grant permission';
        print(error);
      }
      if (e.code == 'PERMISSION_DENIED_NEVER_ASK') {
        error = 'permission denied- please enable it from app settings';
        print(error);
      }
      myLocation = null;
    }
    if (widget.isLock) {
      latLan = LatLng(widget.lat, widget.lng);
      coordinates = Coordinates(widget.lat, widget.lng);
    } else {
      latLan = LatLng(myLocation.latitude, myLocation.longitude);
      if (!isFromMarker) {
        latitude = myLocation.latitude;
        longitude = myLocation.longitude;
      }

      coordinates = Coordinates(latitude, longitude);
    }

    var addresses = await Geocoder.google(Config.GOOGLE_MAP_API_KEY)
        .findAddressesFromCoordinates(coordinates);
    var first = addresses.first;
    print(
        'address: ${first.locality}, aa:${first.adminArea}, sl:${first.subLocality}, sa:${first.subAdminArea}, al${first.addressLine}, fn: ${first.featureName}, tf${first.thoroughfare}, stf:${first.subThoroughfare}');

    setState(() {
      _currentAddress = '${first.addressLine} ';
    });
  }

  marker(LatLng point) {
    const String markerIdVal = 'marker_id_';
    final MarkerId markerId = MarkerId(markerIdVal);
    setState(() {
      markers[markerId] = Marker(
        markerId: MarkerId(point.toString()),
        position: point,
        // infoWindow: InfoWindow(
        //   title: 'lat:$latitude / lan:$longitude',
        // ),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        onTap: () {
          print('Tapped');
        },
        // ignore: avoid_bool_literals_in_conditional_expressions
        draggable: widget.isLock ? false : true,
        onDragEnd: (value) {
          // ignore: always_put_control_body_on_new_line
          latitude = value.latitude;
          longitude = value.longitude;
          getUserLocation(true);
          setState(() {});
        },
      );
    });
  }

  @override
  void initState() {
    super.initState();
    _initMethod();
  }

  Future<void> _goToCurrentLocation() async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(_currentPlace));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            GoogleMap(
              // mapType: MapType.normal,
              myLocationButtonEnabled: true,
              zoomControlsEnabled: false,
              myLocationEnabled: true,
              initialCameraPosition: _currentPlace,
              onMapCreated: (GoogleMapController controller) {
                _controller.complete(controller);
              },
              onTap: (argument) {
                // _add();
              },
              markers: Set<Marker>.of(markers.values),
              gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{
                Factory<OneSequenceGestureRecognizer>(
                  () => EagerGestureRecognizer(),
                ),
              },
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Visibility(
                visible: _currentAddress.isNotEmpty,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    if (!widget.isLock)
                      RaisedButton(
                        child: const Text(
                          'Pick',
                          style: TextStyle(
                              fontFamily: fontMontserrat, color: Colors.white),
                        ),
                        color: appBarColor,
                        onPressed: () {
                          final patientAddress = MAddress(
                              address: _currentAddress,
                              lat: latitude,
                              lng: longitude);
                          Navigator.pop(context, patientAddress);
                        },
                      ),
                    Container(
                        margin: EdgeInsets.all(10),
                        color: Colors.white,
                        padding: EdgeInsets.all(6),
                        width: MediaQuery.of(context).size.width,
                        height: 60,
                        child: Center(child: Text(_currentAddress))),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
