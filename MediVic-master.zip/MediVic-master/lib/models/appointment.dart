import 'package:medivic/constants/config.dart';
import 'package:medivic/extensions/date_extensions.dart';
import 'package:medivic/models/appointment_status.dart';
import 'package:medivic/services/api/firestoreService.dart';

class Appointment {
  Appointment(this.slotId,
      this.userId,
      this.userName,
      this.userImageUrl,
      this.doctorId,
      this.doctorName,
      this.doctorImageUrl,
      this.date,
      this.startTime,
      this.endTime,
      this.selfDiagnosisReportId,
      this.title,
      this.createdAt, {
        this.id = '',
        this.type = APPOINTMENT_TYPE,
        this.status = AppointmentStatus.UPCOMING,
        this.sessionConfirmed = false,
      });

  factory Appointment.fromJson(Map<String, dynamic> json) {
    return Appointment(
      json['slotId'],
      json['userId'],
      json['userName'],
      json['userImageUrl'],
      json['doctorId'],
      json['doctorName'],
      json['doctorImageUrl'],
      DateExtension.parseFullDate(json['date']),
      json['startTime'],
      json['endTime'],
      json['selfDiagnosisReportId'],
      json['title'],
      json['createdAt'],
      id: json['docId'],
      status: json['status'],
      type: json['type'],
      sessionConfirmed: json['sessionConfirmed'],
    );
  }

  static const String COLLECTION_NAME = 'appointments';
  static const String APPOINTMENT_TYPE = 'VIDEO';

  final String id, slotId;
  final String userId,
      userName,
      userImageUrl,
      doctorId,
      doctorName,
      doctorImageUrl;
  final DateTime date;
  final String startTime, endTime;
  final String type, status, title, selfDiagnosisReportId;
  final bool sessionConfirmed;
  final int createdAt;

  String getVideoChannelId() => '${doctorId}_$userId';

  String getInterval() => '$startTime - $endTime';

  int compare(Appointment another) {
    final DateTime current = DateTime.now();
    return getStartDateTime()
        .difference(current)
        .inSeconds
        .abs() >
        another
            .getStartDateTime()
            .difference(current)
            .inSeconds
            .abs()
        ? 1
        : -1;
  }

  bool isCancellable() {
    return getStartDateTime().difference(DateTime.now()) >
        Config.CANCEL_TIME_BEFORE_APPOINTMENT;
  }

  bool isReschedulable() => getStartDateTime().isAfter(DateTime.now());

  DateTime getStartDateTime() =>
      DateExtension.parseFullDateTime('$startTime, ${date.formatFullDate()}');

  DateTime getEndDateTime() =>
      DateExtension.parseFullDateTime('$endTime, ${date.formatFullDate()}');

  bool sessionNotStarted() {
    return getStartDateTime()
        .add(Config.SESSION_START_BEFORE_APPOINTMENT)
        .isAfter(DateTime.now());
  }

  bool sessionEnded() {
    return getStartDateTime().isBefore(DateTime.now()) &&
        getEndDateTime().isBefore(DateTime.now());
  }

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'userName': userName,
      'userImageUrl': userImageUrl,
      'doctorId': doctorId,
      'doctorName': doctorName,
      'doctorImageUrl': doctorImageUrl,
      'date': date.formatFullDate(),
      'startTime': startTime,
      'endTime': endTime,
      'type': type,
      'status': status,
      'sessionConfirmed': sessionConfirmed,
      'slotId': slotId,
      'selfDiagnosisReportId': selfDiagnosisReportId,
      'title': title,
      'createdAt': createdAt
    };
  }

  static List<Appointment> parseList(List<dynamic> list) {
    final List<Appointment> appointments = list
        .map((e) =>
        Appointment.fromJson(FirestoreService.convertDocumentToMap(e)))
        .toList();
    appointments.sort((a, b) => a.compare(b));
    return appointments;
  }
}
