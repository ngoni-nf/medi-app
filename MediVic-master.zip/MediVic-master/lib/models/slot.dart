import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:medivic/extensions/date_extensions.dart';
import 'package:medivic/services/api/firestoreService.dart';

class Slot {
  Slot(
    this.date,
    this.startTime,
    this.endTime, {
    this.documentId,
    this.doctorId,
    this.booked = false,
    this.insideOfficeHour = false,
  });

  factory Slot.fromJson(Map<String, dynamic> json) {
    return Slot(
      DateExtension.parseFullDate(json['date']),
      json['startTime'].toString().toUpperCase(),
      json['endTime'].toString().toUpperCase(),
      booked: json['booked'],
      documentId: json['docId'],
      doctorId: json['doctorId'],
    );
  }

  static const String COLLECTION_NAME = 'slots';

  DateTime date;
  final String documentId, startTime, endTime;
  String doctorId;
  final bool booked, insideOfficeHour;

  String getId() => getStartDateTime().formatFullDateTime();

  String getInterval() => '$startTime - $endTime';

  bool isDoctorAvailable() => doctorId != null && doctorId.isNotEmpty;

  DateTime getStartDateTime() =>
      DateExtension.parseFullDateTime('$startTime, ${date.formatFullDate()}');

  DateTime getEndDateTime() =>
      DateExtension.parseFullDateTime('$endTime, ${date.formatFullDate()}');

  void setDate(DateTime newDate) => date = newDate;

  Map<String, dynamic> toJson() {
    return {
      'date': date.formatFullDate(),
      'startTime': startTime,
      'endTime': endTime,
      'createdAt': DateTime.now().millisecondsSinceEpoch,
      'doctorId': doctorId,
      'booked': booked,
    };
  }

  static List<Slot> parseList(List<DocumentSnapshot> list) {
    return list
        .map((e) => Slot.fromJson(FirestoreService.convertDocumentToMap(e)))
        .toList();
  }

  bool equals(Slot slot) {
    return slot != null &&
        slot.date.isSameDay(date) &&
        slot.startTime == startTime &&
        slot.endTime == endTime;
  }
}
