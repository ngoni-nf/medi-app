class MAddress {
  String address;
  double lat, lng;

  // ignore: sort_constructors_first
  MAddress({this.address, this.lat, this.lng});
}
