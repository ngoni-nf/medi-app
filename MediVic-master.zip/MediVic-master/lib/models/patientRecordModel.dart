class PatientRecord{
  String userId;
  String imgUrl;
  String name;
  String appointmentDate;

  PatientRecord({this.userId,this.name,this.imgUrl,this.appointmentDate});
  
}