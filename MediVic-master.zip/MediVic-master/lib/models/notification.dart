import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class InAppNotification {
  const InAppNotification(this.title, this.body, this.type, this.timestamp);

  factory InAppNotification.fromJson(Map<String, dynamic> json) {
    return InAppNotification(
      json['title'],
      json['body'],
      json['type'],
      json['timestamp'],
    );
  }

  final String title, body, type;
  final int timestamp;

  String getDateTime() {
    return DateFormat('hh:mm a, d MMMM, yyyy')
        .format(DateTime.fromMillisecondsSinceEpoch(timestamp).toLocal());
  }

  static List<InAppNotification> parseList(AsyncSnapshot<QuerySnapshot> snapshot) {
    if (snapshot.data == null) {
      return [];
    }
    return snapshot.data.documents
        .map((e) => InAppNotification.fromJson(e.data))
        .toList();
  }
}
