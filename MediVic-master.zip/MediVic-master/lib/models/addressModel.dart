// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:google_map_location_picker/google_map_location_picker.dart';
import 'package:medivic/utils/common_utils.dart';

/// Model calss to store `Address` information of the user.
class Address {
  Address({this.state, this.street, this.city, this.country, this.pin});

  Address.fromMap(Map<String, dynamic> jsonData) {
    street = jsonData['street'] ?? '';
    city = jsonData['city'] ?? '';
    state = jsonData['state'] ?? '';
    pin = jsonData['pin'] ?? '';
    country = jsonData['country'] ?? '';
  }

  Address.empty() {
    street = '';
    city = '';
    state = '';
    pin = '';
    country = '';
  }

  String street, city, state, pin, country;

  Map<String, dynamic> toJson() {
    return {
      'state': state ?? '',
      'street': street ?? '',
      'city': city ?? '',
      'country': country ?? '',
      'pin': pin ?? '',
    };
  }
}

class Location {
  const Location(this.lat, this.lng);

  factory Location.empty() {
    return const Location(0, 0);
  }

  factory Location.fromJson(Map<String, dynamic> json) {
    return (json == null)
        ? Location.empty()
        : Location(
            CommonUtils.parseDouble(json['lat']),
            CommonUtils.parseDouble(json['lng']),
          );
  }

  factory Location.picked(LocationResult locationResult) {
    return Location(
        locationResult.latLng.latitude, locationResult.latLng.longitude);
  }

  factory Location.pickedNew(double latitude, double longitude) {
    return Location(latitude, longitude);
  }

  final double lat, lng;

  @override
  String toString() => '${lat.toStringAsFixed(6)}, ${lng.toStringAsFixed(6)}';

  Map<String, dynamic> toJson() {
    return {
      'lat': lat ?? 0,
      'lng': lng ?? 0,
    };
  }
}

class PatientAddress {
  PatientAddress(this.address, this.location);

  factory PatientAddress.fromJson(Map<String, dynamic> json) {
    if (json == null) {
      return PatientAddress.empty();
    }
    return PatientAddress(
      json['address'],
      Location.fromJson(json['location']),
    );
  }

  factory PatientAddress.fromPick(LocationResult locationResult) {
    return PatientAddress(
        locationResult.address,
        Location(
          locationResult.latLng.latitude,
          locationResult.latLng.longitude,
        ));
  }

  factory PatientAddress.fromPickNew(String address, double lat, double lng) {
    return PatientAddress(
        address,
        Location(
          lat,
          lng,
        ));
  }

  factory PatientAddress.empty() {
    return PatientAddress('', Location.empty());
  }

  final String address;
  final Location location;

  Map<String, dynamic> toJson() {
    return {
      'address': address ?? '',
      'location': (location ?? Location.empty()).toJson(),
    };
  }
}
