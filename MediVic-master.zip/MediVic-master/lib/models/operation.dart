import 'package:cloud_firestore/cloud_firestore.dart';

class Operation {
  const Operation(this.document, this.data);

  final DocumentReference document;
  final Map<String, dynamic> data;

  static const int chunkSize = 500;

  static List<List<Operation>> convertToChunks(List<Operation> operations) {
    final List<List<Operation>> chunks = [];
    for (int i = 0; i < operations.length; i += chunkSize) {
      chunks.add(operations.sublist(
        i,
        i + chunkSize > operations.length ? operations.length : i + chunkSize,
      ));
    }
    return chunks;
  }
}
