import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Message {
  const Message(
    this.text,
    this.userId,
    this.doctorId,
    this.sender,
    this.createdAt,
  );

  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      json['text'] ?? '',
      json['userId'],
      json['doctorId'],
      json['sender'] ?? 1,
      json['createdAt'] ?? 0,
    );
  }

  final String text, userId, doctorId;
  final int sender, createdAt;

  String getDateTime() {
    return DateFormat('hh:mm a, d MMM')
        .format(DateTime.fromMillisecondsSinceEpoch(createdAt));
  }

  Map<String, dynamic> toJson() {
    return {
      'text': text,
      'userId': userId,
      'doctorId': doctorId,
      'sender': sender,
      'createdAt': createdAt,
    };
  }

  static List<Message> parseList(AsyncSnapshot<QuerySnapshot> snapshot) {
    if (snapshot.data == null) {
      return [];
    }
    return snapshot.data.documents
        .map((e) => Message.fromJson(e.data))
        .toList();
  }
}
