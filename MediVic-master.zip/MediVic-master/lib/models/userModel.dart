// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:flutter/foundation.dart';
import 'package:medivic/utils/utils.dart';

import 'addressModel.dart';

/// Model class to store `User` information
class User {
  User({
    @required this.uid,
    @required this.name,
    @required this.email,
    this.age,
    this.imageUrl,
    this.gender,
    this.dob,
    this.phoneNumber,
    this.id,
    this.lastName,
    this.createdAt,
    this.updatedAt,
    this.address,
  })  : assert(uid != null),
        assert(name != null),
        assert(email != null);

  User.fromJson(Map<String, dynamic> json) {
    uid = json['uid'];
    name = json['name'] ?? '';
    email = json['email'] ?? '';
    age = json['age'];
    imageUrl = json['imageUrl'];
    gender = json['gender'];

    phoneNumber = json['phoneNumber'];
    nextOfKinName = json['nextOfKinName'] ?? '';
    nextOfKinRelationship = json['nextOfKinRelationship'] ?? '';
    id = json['id'];
    docsVisibility = Utils.getJSONData(json, 'docsVisibility') ?? false;
    lastName = json['lastName'];
    createdAt = Utils.getDateTime(json['createdAt']);
    updatedAt = Utils.getDateTime(json['updatedAt']);
    dob = Utils.getDateTime(json['dob']);
    address = PatientAddress.fromJson(json['address']);
    isOTP = json.containsKey('isOTP') ? json['isOTP'] : '0';
    isBlock = json['isBlock'] ?? false;
  }

  String uid,
      name,
      phoneNumber,
      email,
      gender,
      imageUrl,
      age,
      id,
      lastName,
      isOTP = '0',
      nextOfKinName,
      nextOfKinRelationship;
  DateTime createdAt, updatedAt, dob;
  bool docsVisibility, isBlock;
  PatientAddress address;

  Map<String, dynamic> toJson() {
    return {
      'uid': uid ?? '',
      'name': name,
      'lastName': lastName ?? '',
      'email': email ?? '',
      'age': age ?? '',
      'imageUrl': imageUrl ?? '',
      'id': id ?? '',
      'gender': gender ?? '',
      'nextOfKinName': nextOfKinName ?? '',
      'nextOfKinRelationship': nextOfKinRelationship ?? '',
      'dob': dob,
      'docsVisibility': docsVisibility ?? false,
      'phoneNumber': phoneNumber ?? '',
      'address': (address ?? PatientAddress.empty()).toJson(),
      'isOTP': isOTP ?? '0',
      'createdAt': createdAt ?? DateTime.now(),
      'updatedAt': updatedAt ?? DateTime.now(),
      'isBlock': isBlock ?? false,
    };
  }
}

///
/// ## Description
///
/// Model class for the firebase user.
/// Only takes the `id` and `email` of the user.
///
/// Note: Do not use for storing user info except to check if user is present.
///
class FAuthUser {
  FAuthUser({
    @required this.uid,
    @required this.email,
  }) : assert(uid != null);

  String uid, email;
}
