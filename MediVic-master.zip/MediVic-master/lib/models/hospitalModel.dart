// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:medivic/models/addressModel.dart';
import 'package:flutter/foundation.dart';

class Hospital {
  Hospital({
    @required this.uid,
    @required this.name,
    this.email,
    this.bio,
    this.phoneNumber,
    this.specialities,
    this.imageUrl,
    this.address,
  });

  Hospital.fromMap(Map<String,dynamic> jsonData) {
    uid = jsonData['uid'] ?? '';
    name = jsonData['name'] ?? '';
    bio = jsonData['bio'] ?? '';
    email = jsonData['email'] ?? '';
    phoneNumber = jsonData['phoneNumber'] ?? '';
    // imageUrl = jsonData['imageUrl'] ?? '';
    specialities = getList(jsonData,'specialities');
    address = jsonData['address'] != null
        ? Address.fromMap(jsonData['address'])
        : Address.empty();
  }

  String uid, rating, name, email, bio, imageUrl, phoneNumber;
  List<String> specialities;
  Address address;
}

List<String>getList(Map<String,dynamic>json,String key){
  if(json.containsKey(key)){
    try{
      return json[key].cast<String>();
    }catch(e){
      print('ERR FROM MAP $e');
      return [];
    }

  }
  return [];
}
