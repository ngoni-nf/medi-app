import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:medivic/utils/common_utils.dart';

class Payment {
  Payment(
    this.appointmentId,
    this.userId,
    this.doctorId,
    this.patientName,
    this.doctorName,
    this.title,
    this.fee,
    this.paid,
    this.createdAt,
  );

  factory Payment.fromMap(Map<String, dynamic> json) {
    return Payment(
      json['appointmentId'],
      json['userId'],
      json['doctorId'],
      json['patientName'] ?? '',
      json['doctorName'] ?? '',
      json['title'],
      CommonUtils.parseDouble(json['fee']),
      json['paid'],
      json['createdAt'],
    );
  }

  static const String COLLECTION_NAME = 'payments';
  static const double MEDIVIC_COMMISSION_PERCENTAGE = 20;
  final String appointmentId, userId, doctorId, patientName, doctorName, title;
  double fee;
  final bool paid;
  final int createdAt;

  Map<String, dynamic> toMap() {
    return {
      'appointmentId': appointmentId,
      'userId': userId,
      'doctorId': doctorId,
      'patientName': patientName,
      'doctorName': doctorName,
      'title': title,
      'fee': fee,
      'paid': paid,
      'createdAt': createdAt,
    };
  }

  DateTime getCreatedAt() {
    return DateTime.fromMillisecondsSinceEpoch(createdAt);
  }

  double feeWithoutCommission() {
    return (100 - MEDIVIC_COMMISSION_PERCENTAGE) * fee / 100;
  }

  double commission() {
    return MEDIVIC_COMMISSION_PERCENTAGE * fee / 100;
  }

  Payment copy(){
   return Payment(
      appointmentId,
      userId,
      doctorId,
      patientName,
      doctorName,
      title,
      fee,
      paid,
      createdAt,
    );
  }
  
  static List<Payment> parseList(QuerySnapshot querySnapshot) {
    return querySnapshot.documents.map((e) => Payment.fromMap(e.data)).toList();
  }
}
