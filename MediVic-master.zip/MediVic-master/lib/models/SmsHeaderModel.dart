
class SmsHeader {

  SmsHeader({
    this.token,
  });

  SmsHeader.fromJson(Map<String, dynamic> jsonData) {
    token = jsonData['token'] ?? '';

  }

  SmsHeader.empty() {
    token = '';

  }

  String token;

  Map<String, dynamic> toJson() {
    return {
      'token': token ?? '',

    };
  }
}