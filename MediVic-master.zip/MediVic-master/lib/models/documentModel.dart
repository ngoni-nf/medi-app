import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:medivic/utils/utils.dart';

class Document {
  String fileName;
  String fileUrl;
  String docId;
  DateTime createdAt;
  bool docsVisibility;

  Document(
      {this.docId,
      this.fileUrl,
      this.fileName,
      this.createdAt,
      this.docsVisibility});

  Document.fromMap(Map<String, dynamic> json) {
    fileName = json['fileName'];
    fileUrl = json['fileUrl'];
    docId = json['docId'];
    docsVisibility = Utils.getJSONData(json, 'docsVisibility');
    createdAt = Utils.getDateTime(json['createdAt']);
  }

  Map<String, dynamic> toMap() {
    return {
      'fileName': fileName ?? '',
      'fileUrl': fileUrl ?? '',
      'createdAt': createdAt ?? DateTime.now(),
      'docsVisibility': docsVisibility ?? false
    };
  }

  static List<Document> parseList(List<DocumentSnapshot> snapshots) {
    return snapshots
        .map((e) => FirestoreService.convertDocumentToMap(e))
        .map((e) => Document.fromMap(e))
        .toList();
  }
}
