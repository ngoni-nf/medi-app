
class AppointmentStatus{
  static const String UPCOMING = 'Upcoming';
  static const String CANCELLED = 'Cancelled';
  static const String COMPLETED = 'Completed';
}