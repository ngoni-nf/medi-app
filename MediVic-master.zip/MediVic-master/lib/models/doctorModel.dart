// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:algolia/algolia.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/extensions/string_extensions.dart';
import 'package:medivic/models/addressModel.dart';
import 'package:medivic/utils/common_utils.dart';
import 'package:medivic/utils/utils.dart';

class Doctor {
  Doctor({
    @required this.uid,
    @required this.name,
    this.fee,
    this.specialities,
    this.address,
    this.experience,
    this.imageUrl,
    this.email,
    this.lastName,
    this.dob,
    this.gender,
    this.age,
    this.id,
    this.hpcaNumber,
    this.ipaNumber,
    this.groupPracticeNumber,
    this.briefProfile,
    this.language,
    this.practices,
    this.phoneNumber,
    this.location,
    this.membership,
    this.education,
    this.aboutme,
    this.isActive,
    this.isOTP,
  })  : assert(uid != null),
        assert(name != null);

  Doctor.fromMap(Map<String, dynamic> jsonData) {
    uid = jsonData['uid'];
    name = jsonData['name'];
    lastName = jsonData['lastName'];
    gender = jsonData['gender'];
    age = jsonData['age'];
    id = jsonData['id'];
    hpcaNumber = jsonData['hpcaNumber'];
    ipaNumber = jsonData['IPANumber'];
    groupPracticeNumber = jsonData['groupPracticeNumber'];
    briefProfile = jsonData['briefPeople'];
    language = jsonData['preferredLanguage'];
    phoneNumber = jsonData['phoneNumber'];
    education = jsonData['education'];
    membership = jsonData['membership'];
    aboutme = jsonData['aboutme'];
    fee = jsonData['fee'] != null ? jsonData['fee'].toString() : '';
    specialities = jsonData['specialities'] != null ? jsonData['specialities'].cast<String>() : [];

    if (jsonData.containsKey("documentUrl")) {
      documentUrl = jsonData['documentUrl'] != null ? jsonData['documentUrl'].cast<String>() : [];
    }
    if (jsonData.containsKey("bankDocuments")) {
      bankDocuments = jsonData['bankDocuments'] != null ? jsonData['bankDocuments'].cast<Map<String, dynamic>>() : [];
    }
    practices = jsonData['practices'] != null ? jsonData['practices'].cast<String>() : [];
    address = jsonData['address'] != null ? Address.fromMap(jsonData['address']) : Address.empty();
    experience = jsonData['experience'] != null ? jsonData['experience'].toString() : '';
    email = jsonData['email'] ?? '';
    isOTP = jsonData['isOTP'];
    imageUrl = jsonData['imageUrl'] ?? Config.placeholedImageUrl;
    location = Location.fromJson(jsonData['_geoloc']);
    isActive = jsonData['isActive'] ?? 0;
    rating = CommonUtils.parseDouble(jsonData['rating']);
    createdAt = Utils.getDateTime(jsonData['createdAt']);
    updatedAt = Utils.getDateTime(jsonData['updatedAt']);
    dob = Utils.getDateTime(jsonData['dob']);
    isBlock = jsonData['isBlock'] ?? false;
    bankName = jsonData['bankName'];
    bankBranchName = jsonData['bankBranchName'];
    bankBranchCode = jsonData['bankBranchCode'];
    bankAccType = jsonData['bankAccType'];
    bankAccHolderName = jsonData['bankAccHolderName'];
    bankAccNumber = jsonData['bankAccNumber'];
  }

  String uid,
      name,
      imageUrl,
      experience,
      email,
      fee,
      lastName,
      gender,
      age,
      id,
      hpcaNumber,
      ipaNumber,
      groupPracticeNumber,
      briefProfile,
      language,
      phoneNumber,
      membership,
      education,
      aboutme,
      isOTP = "0",
      bankName,
      bankBranchName,
      bankAccType,
      bankAccHolderName;
  List<String> specialities;
  List<String> practices;
  List<String> documentUrl;
  List<Map<String, dynamic>> bankDocuments;
  Address address;
  Location location;
  int isActive;
  int bankBranchCode;
  int bankAccNumber;
  double rating;
  bool isBlock;
  DateTime createdAt, updatedAt, dob;

  Map<String, dynamic> toJson() {
    return {
      'uid': uid ?? '',
      'name': name ?? '',
      'lastName': lastName,
      'bankName': bankName,
      'bankBranchName': bankBranchName,
      'bankBranchCode': bankBranchCode,
      'bankAccHolderName': bankAccHolderName,
      'bankAccNumber': bankAccNumber,
      'bankAccType': bankAccType,
      'dob': dob,
      'gender': gender,
      'age': age,
      'groupPracticeNumber': groupPracticeNumber,
      'briefPeople': briefProfile,
      'email': email ?? '',
      'fee': fee ?? '',
      'membership': membership ?? '',
      'education': education ?? '',
      'aboutme': aboutme ?? '',
      'specialities': specialities ?? '',
      'address': address.toJson(),
      'experience': experience ?? '',
      'imageUrl': imageUrl ?? '',
      'id': id,
      'phoneNumber': phoneNumber,
      'isOTP': isOTP ?? '0',
      '_geoloc': location == null ? {} : location.toJson(),
      'isActive': isActive ?? 0,
      'rating': rating ?? 0,
      'createdAt': createdAt ?? DateTime.now(),
      'updatedAt': updatedAt ?? DateTime.now(),
      'isBlock': isBlock ?? false,
      'language': language,
      'hpcaNumber': hpcaNumber,
      'IPANumber': ipaNumber,
      'bankDocuments': bankDocuments,
      'documentUrl': documentUrl,
      'practices': practices ?? [],
    };
  }

  static List<Doctor> parseList(List<dynamic> list) {
    final List<Map<String, dynamic>> mapList = [];
    mapList.addAll(list.whereType<DocumentSnapshot>().map((e) => e.data).toList());
    mapList.addAll(list.whereType<AlgoliaObjectSnapshot>().map((e) => e.data).toList());

    return mapList.map((e) => Doctor.fromMap(e)).where((element) => element.isActive == 1).toList();
  }

  static List<Doctor> filterDoctorsBySpeciality(List<Doctor> doctors, String speciality) {
    if (speciality == null || speciality.isEmpty) {
      return doctors;
    }
    return doctors.where((element) => StringUtils.containsIgnoreCase(element.specialities, speciality)).toList();
  }
}
