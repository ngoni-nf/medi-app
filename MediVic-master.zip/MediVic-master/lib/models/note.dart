import 'package:medivic/utils/utils.dart';

class Note {
  String docId;
  String note;
  String patientId;
  String doctorId;
  String patientName;
  String fileUrl;
  String imageUrl;
  String title;
  DateTime createdAt, updatedAt;

  Note(
      {this.title,
      this.updatedAt,
      this.imageUrl,
      this.patientId,
      this.doctorId,
      this.patientName,
      this.fileUrl,
      this.createdAt,
      this.note});

  Note.fromMap(Map<String, dynamic> map) {
    docId = map['docId'];
    title = map['title'] ?? 'No given title';
    note = map['note'] ?? 'No given note';
    fileUrl = map['fileUrl'];
    imageUrl = map['imageUrl'];
    patientId = map['patientId'];
    doctorId = map['doctorId'];
    patientName = map['patientName'];
    createdAt = Utils.getDateTime(map['createdAt']);
    updatedAt = Utils.getDateTime(map['updatedAt']);
  }

  Map<String, dynamic> toMap() {
    return {
      'note': note,
      'title': title,
      'patientId': patientId,
      'doctorId': doctorId,
      'patientName': patientName,
      'fileUrl': fileUrl,
      'imageUrl': imageUrl,
      'createdAt': createdAt ?? DateTime.now(),
      'updatedAt': updatedAt ?? DateTime.now(),
    };
  }
}
