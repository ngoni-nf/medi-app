import 'package:medivic/utils/utils.dart';

class PrescriptionNew {
  String docId;
  String fromId;
  String toId;
  String note;
  String fileUrl;
  String imageUrl;
  String title;
  String doctorName;
  String patientName;
  DateTime createdAt, updatedAt;

  PrescriptionNew({this.title,this.doctorName,this.patientName,this.fromId, this.toId, this.updatedAt, this.imageUrl, this.fileUrl, this.createdAt, this.note});

  PrescriptionNew.fromMap(Map<String, dynamic> map) {
    docId = map['docId'];
    fromId = map['fromId'];
    toId = map['toId'];
    doctorName = map['doctorName']??'';
    patientName = map['patientName']??'';
    title = map['title']??'No given name';
    note = map['note']??'No given note';
    fileUrl = map['fileUrl'];
    imageUrl = map['imageUrl'];
    docId = map['docId'];
    createdAt = Utils.getDateTime(map['createdAt']);
    updatedAt = Utils.getDateTime(map['updatedAt']);
  }

  Map<String, dynamic> toMap() {
    return {
      'fromId': fromId,
      'toId': toId,
      'note': note,
      'title': title,
      'doctorName': doctorName,
      'patientName': patientName,
      'fileUrl': fileUrl,
      'imageUrl': imageUrl,
      'createdAt': createdAt ?? DateTime.now(),
      'updatedAt': updatedAt ?? DateTime.now(),
    };
  }
}
