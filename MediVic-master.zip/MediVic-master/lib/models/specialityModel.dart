// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

/// Model calss to store `Address` information of the user.
class Speciality {
  Speciality({this.speciality, this.metaData, this.ischecked});

  Speciality.fromMap(Map<String, dynamic> jsonData) {
    speciality = jsonData['speciality'] ?? '';
    metaData = jsonData['metaData'] ?? '';
  }

  Speciality.empty() {
    speciality = '';
    metaData = '';
  }

  String speciality, metaData;
  bool ischecked = false;

  Map<String, dynamic> toJson() {
    return {
      'speciality': speciality ?? '',
      'metaData': metaData ?? '',
    };
  }

  static List<Map<String, String>> getSpecialities() {
    final List<Map<String, String>> specialities = [];
    specialities.add({
      'name': 'Joints & Bones',
      'icon': 'lib/assets/images/joints_and_bones.png'
    });
    specialities.add({
      'name': "Women's Health",
      'icon': 'lib/assets/images/womens_health.png'
    });
    specialities.add({
      'name': 'Urinary Tract Health',
      'icon': 'lib/assets/images/urinary_tract_health.png'
    });
    specialities.add({'name': 'Skin', 'icon': 'lib/assets/images/skin.png'});
    specialities.add({
      'name': 'Sex Specialist',
      'icon': 'lib/assets/images/sex_specialist.png'
    });
    specialities.add({
      'name': 'Physical Inability',
      'icon': 'lib/assets/images/physical_inability.png'
    });
    specialities.add({
      'name': 'Diet And Fitness',
      'icon': 'lib/assets/images/diet_and_fitness.png'
    });
    specialities.add({
      'name': 'Mental Health',
      'icon': 'lib/assets/images/mental_health.png'
    });
    specialities.add(
        {'name': 'Lung Health', 'icon': 'lib/assets/images/lung_health.png'});
    specialities
        .add({'name': 'Kidneys', 'icon': 'lib/assets/images/kidneys.png'});
    specialities.add({
      'name': 'Alternative Medicine',
      'icon': 'lib/assets/images/alternative_medicine.png'
    });
    specialities
        .add({'name': 'HIV/AIDS', 'icon': 'lib/assets/images/hiv_aids.png'});
    specialities
        .add({'name': 'Digestive', 'icon': 'lib/assets/images/digestive.png'});
    specialities.add({
      'name': 'Heart Condition',
      'icon': 'lib/assets/images/heart_condition.png'
    });
    specialities
        .add({'name': 'Covid-19', 'icon': 'lib/assets/images/covid_19.png'});
    specialities.add({
      'name': 'Acute & Chronic Illness',
      'icon': 'lib/assets/images/acute_&_chronic_illness.png'
    });
    specialities.add({
      'name': 'Operative Management',
      'icon': 'lib/assets/images/operative_management.png'
    });
    specialities
        .add({'name': 'Eye Care', 'icon': 'lib/assets/images/eye_care.png'});
    specialities.add({
      'name': 'Ear, Nose & Throat',
      'icon': 'lib/assets/images/ear_nose_and_throat.png'
    });
    specialities.add({
      'name': 'Diabetes Specialist',
      'icon': 'lib/assets/images/diabetes_specialist.png'
    });
    specialities.add({
      'name': 'Dental Health',
      'icon': 'lib/assets/images/dental_health.png'
    });
    specialities.add({
      'name': 'Child Care Health',
      'icon': 'lib/assets/images/child_care_health.png'
    });
    specialities
        .add({'name': 'Cancer', 'icon': 'lib/assets/images/cancer.png'});
    specialities
        .add({'name': 'Nerves', 'icon': 'lib/assets/images/nerves.png'});
    specialities.sort(
        (a, b) => a['name'].toLowerCase().compareTo(b['name'].toLowerCase()));
    return specialities;
  }
}
