// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

const MOCK_USER_DATA = {
  'uid': '1',
  'name': 'MediVic',
  'email': 'medivic@akili.co.za',
  'age': '30',
  'profileImageUrl': 'https://via.placeholder.com/120',
  'gender': 'male',
  'dob': '01-01-1990',
  'number': '0814139408',
};

const MOCK_CHAT_USER_1_DATA = {
  'uid': 'OBzwMsrtH85VRlEhNFsi',
  'name': 'test1',
  'avatar': 'https://via.placeholder.com/120',
};

const MOCK_CHAT_USER_2_DATA = {
  'uid': 'h1QspFtRWRibPU8fxRY8',
  'name': 'test2',
  'avatar': 'https://via.placeholder.com/120',
};
