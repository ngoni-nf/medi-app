

import 'package:flutter/material.dart';

class Playground extends StatefulWidget {
  const Playground({Key key}) : super(key: key);
  @override
  _PlaygroundState createState() => _PlaygroundState();
}

class _PlaygroundState extends State<Playground> {
  List list;
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();

    list = generate();

    _scrollController.addListener(() {
      loadMore();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Playground')),
      body: Container(
        child: ListView.builder(
          controller: _scrollController,
          itemCount: list.length,
          itemBuilder: (context, i) {
            return Container(
              height: 100,
              padding: const EdgeInsets.all(16),
              margin: const EdgeInsets.all(20),
              color: Colors.red.shade100,
              child: Text('$i message - ${list[i].message}'),
            );
          },
        ),
      ),
    );
  }

  void loadMore() {
    final p = _scrollController.offset;

    if (p == 0.0) {
      final r = List.generate(10, (index) {
        return M(message: '$index more message');
      });
      list = [...r, ...list];
      setState(() {});
      print('calledMe');
    }
  }

  List<M> generate({int from = 0, int to = 20}) {
    return List.generate(to - from, (index) {
      return M(message: '$index generated message');
    });
  }
}

class M {
  M({this.message, this.id});
  String message, id;
}
