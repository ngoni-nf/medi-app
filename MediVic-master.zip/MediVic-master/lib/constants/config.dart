// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

abstract class Config {
  static const String ANDROID_PACKCAGE_NAME = 'com.centrax.medivic';
  static const String IOS_PACKCAGE_NAME = 'com.centrax.medivic';

  // Agora AppId --> Do not leave this empty or your video call will not work.
  static const AGORA_APP_ID = '9983b9dd0b084527a9b33cb4547ecd6d';

  // Algolia App Id --> Used to power text based search
  static const String ALGOLIA_APP_ID = 'ACHGMCFRYV';
  static const String ALGOLIA_SEARCH_API_KEY =
      '262a4491ab73f83a3f6d4d36e93b6c22';

  // DO NOT CHANGE THESE!!
  static const String ALGOLIA_DOCTORS_INDEX = 'DC_doctors';
  static const String ALGOLIA_HOSPITALS_INDEX = 'DC_hospitals';

  // Signup User placeholder image - Change this image during production for your own
  // firebase project.
  static const String placeholedImageUrl =
      'https://firebasestorage.googleapis.com/v0/b/medivic-c93ac.appspot.com/o/placeholder-img.jpg?alt=media&token=bde1ba67-359e-4816-93e3-69c12cadcce0';

  // Payment related API and Url strings to use for network request.
  //static const PAYMENT_API =
  //   'https://us-central1-flutter-doctor-consultation.cloudfunctions.net/paymentApi';
  static const PAYMENT_API =
      'https://us-central1-medivic-aa5d3.cloudfunctions.net/paymentApi';
  static const INITIATE_PAYMENT_URL = PAYMENT_API + '/initiate_payment';
  static const PAY_FAST_REAL = 'https://www.payfast.co.za/eng/process';
  static const PAY_FAST_DEMO = 'https://sandbox.payfast.co.za/eng/process';

  static const PAY_FAST_MERCHANT_KEY = 'nhttu14y6lr1z';
  static const PAY_FAST_MERCHANT_ID = '15118517';
  static const PAY_FAST_MERCHANT_ID_DEMO = '10000100';
  static const PAY_FAST_MERCHANT_KEY_DEMO = '46f0cd694581a';

  static const ABOUT_DOC = 'aboutus/iYLadl8v6CJ1gao3sPYm';

  static const CURRENCY = 'R';
  static const PAYMENT_CURRENCY = 'USD';
  static const CURRENCY_SYMBOL = '';

  // Notification topics which will be subscribed by all app users
  static const String NOTIFICATION_SUBSCRIPTION_TOPIC = 'TO_ALL_USERS';
  static const String NOTIFICATION_SUBSCRIPTION_TOPIC_DOCTORS =
      'TO_ALL_DOCTORS';

  static const String TERMS_OF_SERVICE_URL = 'https://www.google.com';
  static const String PRIVACY_POLICY_URL = 'https://www.google.com';

  static const String SPLASH_SCREEN_HEADING = 'MediVic';

  // There must not by any space in front or back of the following constants
  static const String HELP_TELEPHONE_NUMBER = '+000000000000';
  static const String CONTACT_EMAIL_ADDRESS = 'mail@email.com';

  static const int DOCTOR_FILTER_MAX_RADIUS = 100;
  static const int DOCTOR_FILTER_MIN_RADIUS = 0;
  static const int DOCTOR_FILTER_DEFAULT_RADIUS = 0;

  static const String GOOGLE_MAP_API_KEY =
      'AIzaSyAu8Fm9L0koDyXbNnEJCuma6R4HUREy0IU';

  static const Duration SESSION_START_BEFORE_APPOINTMENT =
      Duration(minutes: -3);
  static const Duration NOTIFY_BEFORE_APPOINTMENT_END = Duration(seconds: 30);
  static const Duration CANCEL_TIME_BEFORE_APPOINTMENT = Duration(hours: 2);
}
