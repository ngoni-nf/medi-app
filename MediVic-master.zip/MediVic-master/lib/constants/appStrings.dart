// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

class AppStrings {
  static const String appName = 'MediVic';

  // Generic strings
  static const String ok = 'OK';
  static const String cancel = 'Cancel';
  static const String and = 'and';
  static const String or = 'or';
  static const String no = 'no';
  static const String noUpperCase = 'No';
  static const String yesUpperCase = 'Yes';
  static const String reload = 'Reload';
  static const String go = 'Go';
  static const String noDataAvailable = 'No data available';
  static const String next = 'Next';
  static const String back = 'Back';
  static const String seeAll = 'See All';
  static const String about = 'About';
  static const String contact = 'Contact';
  static const String connectNow = 'Connect Now';
  static const String call = 'Call';
  static const String somethingWentWrong = 'Something went wrong!';
  static const String currencySign = '\$';
  static const String tryAgain = 'Try again';
  static const String date = 'Date';
  static const String type = 'Type';
  static const String noPermissions =
      'Permissions not given.\nPlease give camera and microphone permissions to proceed.';
  static const String givePermissions = 'Give permissions';
  static const String success = 'Success';
  static const String saved = 'Saved';
  static const String deleted = 'Deleted';
  static const String submit = 'Submit';
  static const String active = 'Active';
  static const String review = 'Review';
  static const String illness = 'Illness';
  static const String change = 'Change';
  static const String choose = 'Choose';
  static const String patient = 'Patient';

  // Communication controller
  static const String connecting = 'Connecting';
  static const String communicationMessage =
      'If you see this screen during the conversation then either there is network problem or the other user may have left the conversation';

  // Logout
  static const String logout = 'Logout';
  static const String logoutAreYouSure =
      'Are you sure that you want to logout?';
  static const String logoutFailed = 'Logout failed';

  // Login Page
  static const String login = 'Log In';
  static const String loginTagLine = 'Login with email and password';
  static const String loginWithFacebook = 'Login with Facebook';
  static const String loginWithOtp = 'Phone Authenticate';
  static const String loginWithGoogle = 'Login with Google';
  static const String goAnonymous = 'Go anonymous';
  static const String emptyFields = 'Empty Fields';
  static const String loginQues = 'Don\'t have an account ?';
  static const String resetPasswordMessage =
      'Please enter the email which is linked to your account. You will receive an email to reset your password.';

  // Sign up Page
  static const String signup = 'Sign Up';
  static const String signupButton = 'Sign up';
  static const String signUpTagLine =
      'Sign up to discover amazing things near you';
  static const String signupWithFacebook = 'Signup with Facebook';
  static const String signupWithGoogle = 'Signup with Google';
  static const String termsOfService = 'Terms of Service';
  static const String termsAndCondition = 'Terms & Conditions';
  static const String iAgreeTo = 'I Agree To';
  static const String privacyPolicy = 'Privacy Policy';
  static const String tosPreText = 'By signing up you agree to our ';
  static const String signUpQues = 'Already have an account ?';
  static const String displayName = 'Display name';
  static const String password = 'Password';
  static const String oldPassword = 'Old Password';
  static const String confirmPassword = 'Confirm Password';
  static const String blockedMsg = 'You are blocked! Please contact with admin';

  // Email & Password page
  static const String register = 'Register';
  static const String forgotPassword = 'Forgot password';
  static const String forgotPasswordQuestion = 'Forgot password?';
  static const String createAnAccount = 'Create an account';
  static const String needAnAccount = 'Need an account? Register';
  static const String haveAnAccount = 'Have an account? Sign in';
  static const String signInFailed = 'Sign in failed';
  static const String registrationFailed = 'Registration failed';
  static const String passwordResetFailed = 'Password reset failed';
  static const String sendResetLink = 'Send Reset Link';
  static const String backToSignIn = 'Back to sign in';
  static const String resetLinkSentTitle = 'Reset link sent';
  static const String emailAlreadyUsed =
      'The email address is already in use by another account.';
  static const String emailVerificationMsg =
      'Please check your email to verify';
  static const String resetLinkSentMessage =
      'Check your email to reset your password';
  static const String emailLabel = 'Email';
  static const String firstNameLabel = 'Name';
  static const String lastNameLabel = 'Last Name';
  static const String dateOfBirthLabel = 'Date of Birth';
  static const String nationalIdNumberLabel = 'ID';
  static const String nextOfKin = 'Next of Kin Name';
  static const String nextOfKinRelation = 'Next of Kin Relationship';
  static const String phoneNumberLabel = 'Mobile Number';
  static const String ageLabel = 'Age';
  static const String hpcsaLabel = 'HPCSA Number';
  static const String IPALabel = 'IPA affiliation Number';
  static const String groupPracticeLabel = 'Group Practice Number';
  static const String numberOfprcaticeandaddressabel = ' Practices Name';
  static const String AddPracticestabel = 'Add More Practices';
  static const String uploadDocumentLabel = 'Upload Document';
  static const String uploadBankDocumentLabel = 'Upload proof of banking';
  static const String briefProfileLabel = 'Brief Profile';
  static const String preferredLanguageLabel = 'Preferred Language';
  static const String emailHint = 'test@test.com';
  static const String password8CharactersLabel = 'Password (8+ characters)';
  static const String passwordLabel = 'Password';
  static const String addressLabel = 'Address';
  static const String cityLabel = 'City';
  static const String countryLabel = 'Country';
  static const String pinLabel = 'Postal Code';
  static const String stateLabel = 'State';
  static const String streetLabel = 'Street';
  static const String confirmPasswordLabel = 'Confirm Password';
  static const String invalidEmailErrorText = 'Email is invalid';
  static const String invalidEmailEmpty = 'Email can\'t be empty';
  static const String invalidPasswordTooShort = 'Password is too short';
  static const String invalidPasswordNoMatch = 'Passwords do not match';
  static const String invalidPasswordEmpty = 'Password can\'t be empty';
  static const String invalidFirstNameEmpty =
      'First Name should be at least 3 chars';
  static const String invalidLastNameEmpty =
      'Last Name should be at least 3 chars';
  static const String invalidAddressEmpty = 'City can\'t be empty';
  static const String invalidCountryEmpty = 'Country can\'t be empty';
  static const String invalidPinCodeEmpty = 'Postal Code can\'t be empty';
  static const String invalidStateNameEmpty = 'State Name can\'t be empty';
  static const String invalidStreetNameEmpty = 'Street Name can\'t be empty';
  static const String invalidDateOfBirthEmpty = 'Date Of Birth can\'t be empty';
  static const String invalidateNationalIdEmpty =
      'ID or Passport number can\'t be empty';
  static const String invalidateHpcsaNumberEmpty =
      'HPSCA Number can\'t be empty';
  static const String invalidateIPANumberEmpty =
      'IPA affeliation Number can\'t be empty';
  static const String invalidateGroupPracticeNumberEmpty =
      'Group Practice Number can\'t be empty';
  static const String invalidateBriefProfileEmpty =
      'Brief Profile can\'t be empty';
  static const String invalidatePreferredLanguageEmpty =
      'Preferred Language can\'t be empty';
  static const String invalidatePhoneEmpty = 'Mobile Number can\'t be empty';
  static const String invalidatePhonestartEmpty =
      'Mobile number should start with a country code (e.g. +27811234567)';
  static const String invalidatePhoneLength =
      'Mobile Number lenght can\'t be more than 10';
  static const String invalidateAgeLength = 'Age can\'t be be empty';
  static const String invalidFieldEmpty = 'This field cannot be empty';

  // Home page
  static const String homePage = 'Home Page';
  static const String goToHomeButton = 'Go to home';
  static const String homeHeading = 'Medical Practitioner\nSearch';
  static const String searchHealthConcern = 'Search by health concern';

  // Developer menu
  static const String developerMenu = 'Developer menu';
  static const String authenticationType = 'Authentication type';
  static const String firebase = 'Firebase';
  static const String mock = 'Mock';

  // Appointments page
  static const String appointmentsTitle = 'Appointments';
  static const String scheduledTab = 'Scheduled';
  static const String currentTab = 'Current';
  static const String previousTab = 'Previous';
  static const String cancelledTab = 'Cancelled';
  static const String nothing = 'Nothing yet';
  static const String appointmentQuestion = 'Is the appointment complete?';
  static const String bookAppointment = 'Book Appointment';

  // Edit Profile
  static const String editProfile = 'Edit Profile';
  static const String update = 'Update';
  static const String updated = 'Updated';
  static const String updatePhoto = 'Update Photo';
  static const String updateSpecialities = 'Update Specialities';
  static const String name = 'Name';
  static const String email = 'Email';
  static const String phoneNumber = 'Phone Number';
  static const String phoneNumberHint = '1234567890';
  static const String age = 'Age';
  static const String dob = 'Date Of Birth';
  static const String gender = 'Gender';
  static const String filterBy = 'Filter By';
  static const String filterPractitioners = 'Filter Medical Practitioners';
  static const String errorShortName = 'Field should not be empty';
  static const String errorFees = 'The minimum fee allowed is R250';
  static const String errorNumberInvalid = 'Phone number is invalid';
  static const String errorAgeInvalid = 'Age is invalid';
  static const String nationalIdInvalid = 'National ID is invalid';
  static const String errorInvalidDob = 'Invalid Date of birth';

  // Filter Options
  static const String doctor = 'Practitioner';
  static const String doctors = 'Practitioners';
  static const String hospital = 'Pharmacy';
  static const String hospitals = 'Pharmacies';
  static const String speciality = 'Speciality';
  static const String blogs = 'Blogs';

  // Search Screen
  static const String search = 'Search';
  static const String searchSomething = 'Search something';

  // Chat Screen
  static const String chatTitle = 'Chat';
  static const String endChatText = 'Are you sure you want to end the chat?';

  // Drawer - Account Info
  static const String accountInfo = 'Account Info';
  static const String help = 'Help';
  static const String contactUs = 'Contact Us';
  static const String settings = 'Settings';
  static const String savedBlogs = 'Saved Blogs';
  static const String medicineCourse = 'Prescriptions';
  static const String save = 'Save';

  // Account Info
  static const String makeChanges = 'Make Changes here';
  static const String changePassword = 'Change Password';

  // Help Screen
  static const String helpDialogue =
      'Ask anything that you want help with. We will answere your question as soon as possible.';
  static const String helpButton = 'Help Me';

  // Contact Us screen
  static const String contactUsDialogue =
      'You will be redirected to send an email to us, please mention your query in detatil for us to understand you fully. We will reply you as soon as possible.';
  static const String contactButton = 'Contact Us';

  // Video call
  static const String videoCall = 'Video Call';
  static const String endCallText = 'Are you sure you want to end the call?';

  // Payment screen
  static const String payment = 'Payment';
  static const String proceedToPay = 'Procees to pay';
  static const String paymentMessage =
      'Pay now to connect to the Practitioner. Once the payment is done you will be connected with the practitioner via the method you chose.';

  static const String processingPayment = 'Processing Payment';
  static const String paymentSuccessfull = 'Payment Successfull';
  static const String paymentFailed = 'Payment Failed';
  static const String settingUpAppointment = 'Setting Up Appointment';
  static const String noAppointment = "You haven't booked any appointment yet.";
  static const String appointmentFailed = 'Appointment failed';
  static const String appointmentSuccessfull = 'Your appoinment is successfull';

  static const String appointmentMessage =
      'The practitioner will contact you shortly.';
  static const String appointmentMessage2 =
      'Please make sure that you are available when the practitioner contacts you.';

  // On boarding
  static const String title1 = 'Qualified Practitioners';
  static const String desc1 =
      'Meticulously selected certified practitioners and personalised appointments in the comfort of your own space.';

  static const String title2 = '24x7 Emergency Services';
  static const String desc2 =
      '24x7 response to all calls for all types of disasters, a real person answers the line to help direct your call effectively.';

  static const String title3 =
      'Health-Care Practitioners \nat your finger tips';
  static const String desc3 = "We're changing the way you see your doctor.";

  static const String title4 = 'Get on board';
  static const String desc4 = '';

  // Doctors account
  static const String signupAsDoctor = 'Practitioner\'s Signup';
  static const String loginAsDoctor = 'Practitioner\'s Login';
  static const String iamDoctor = 'I am a Practitioner';
  static const String iamNotDoctor = 'I am not a Practitioner';
  static const String dr = 'Dr. ';
  static const String experience = 'Experience';
  static const String exp = 'Exp';
  static const String specialities = 'Cardiologist, Gynecologist';
  static const String specialitiesLable = 'Specialities';
  static const String addSpecialitiesLable = 'Add Specialities';
  static const String branchName = 'Branch Name';
  static const String branchCode = 'Branch Code';
  static const String accountNumber = 'Account Number';
  static const String accountType = 'Account Type';
  static const String accountHolderName = 'Account Holder';
  static const String yr = 'yr';
  static const String years = 'Years';
  static const String fee = 'Fee (Minimum 250)';
  static const String notProvided = 'Not provided';
  static const String updateAddress = 'Update Address';
  static const String writePrescription = 'Write a prescription';
  static const String prescription = 'Prescription';
  static const String tablets = 'Tablets';
  static const String dose = 'Dose';
  static const String remarks = 'Remarks';

  // Doctor home
  static const String accept = 'Accept';
  static const String reject = 'Reject';
  static const String reschedule = 'Reschedule';
  static const String upComing = 'Upcoming';
  static const String completed = 'Completed';
  static const String other = 'Other';
  static const String notifications = 'Notifications';

  // Update Address Screen
  static const String address = 'Address';
  static const String street = 'Street';
  static const String buildingNumber = 'Building Number';
  static const String city = 'City';
  static const String neighborhood = 'Neighborhood';
  static const String state = 'State';
  static const String pin = 'Pin/Zip';
  static const String country = 'Country';
  static const String latLng = 'Latitude/Longitude';

  // Support Screen
  static const String category = 'Category';
  static const String chooseConsultFormat = 'Choose consultation format';
  static const String chatSub =
      'When you are busy to talk you should pick this option';
  static const String callSub = 'Talk to a practitioner on the voice call';
  static const String videoCallSub = 'Talk to a practitioner in a video call';

  // Small list titles
  static const String hospitalsAndClinics = 'Pharmacies';
  static const String generalDoctor = 'General\nSurgeon';
  static const String generalDoctor2 = 'General Surgeon';
  static const String dentalCare = 'General\nPractitioner';
  static const String dentalCare2 = 'General Practitioner';

  // Invalid inputs
  static const String invalidNameShort = 'Name is too short.';
  static const String invalidExperience = 'Experience is invalid';
  static const String invalidExperienceTooMuch =
      'Hey, that\'s too much experience!';
  static const String invalidFee = 'Fee is invalid';
  static const String invalidFeeZero = 'Fee must be greater than 0';
  static const String invalidAmount = 'The amount/fee is invalid';
  static const String invalidSpecialities = 'No special characters allowed';
  static const String consultFormat = 'Consultation Format';
  static const String typeMessage = 'Type your message...';
  static const String exitQues = 'Are you sure you want to exit?';
  static const String id = 'Id';
  static const String moreInfo = 'More Information';
  static const String title = 'Title';
  static const String status = 'Status';
  static const String doctorId = 'Practitioner Id';
  static const String appointmentQuestionMessage =
      'You will not be able to undo this action. You will not be asked for any confirmation and the action will be performed immediately.';

  static const schedulePlanning = 'Schedule Planning';
  static const waitingRoom = 'Waiting Room';
  static const waitingRoomMessage = 'Please wait doctor will let you soon.';
  static const sessionNotStarted =
      'This session will start being accessible 3 minutes before the start time.';
  static const sessionEnded =
      'This session has ended. Please book another session.';
  static const sessionCancelled =
      'This session has been cancelled. Please book another session.';

  static const sessionConfirmationTitle = 'Session Confirmation';
  static const sessionConfirmationMessage =
      'The session was successfully concluded. For compliance and facilitation of payments, please confirm the following details:';
  static const sessionConfirmationConsultedPatient =
      'I consulted with patient on record.';
  static const sessionConfirmationDiagnosedPatient =
      'I was able to diagnose the patient and recorded the diagnosis.';
  static const noDoctorsForSpecialization =
      'We currently have no doctor listed under this specialisation.';

  static const msgInactivity =
      'Your MediVic app session has timed out. Please login again.';
}
