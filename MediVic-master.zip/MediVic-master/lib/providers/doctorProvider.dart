// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:developer';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/addressModel.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/services/api/firestoreService.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';

///
/// ## Description
///
/// Provider that handles `Doctor` data in the state.
/// Cares about the Doctor data after it has been loaded into memory from the server.
///
class DoctorProvider with ChangeNotifier {
  // Set the doctorId for the app when the Doctor signup or login.
  String _doctorId = '';

  String get doctorId => _doctorId;

  void setDoctorId(String value) {
    _doctorId = value;
    log(value, name: 'DoctorProvider setDoctorId');
  }

  Doctor _doctor;

  Doctor get doctor => _doctor;

  void setDoctor(Doctor doctor) {
    LocatorService.userProvider().clearData();
    _doctor = doctor;
  }

  /// Clears all the data in the storage variables when the user sign out.
  /// Must only be run when the user sign out of an account.
  void clearData() {
    _doctorId = '';
    _doctor = null;
  }

  Future<bool> fetchDoctorData(String id) async {
    try {
      log('Fetching doctor data for id $id', name: 'DP');
      final Map<String, dynamic> result =
          await FirestoreService.getDoctorInfo(id);
      if (result != null && result.keys.isNotEmpty) {
        final doctor = Doctor.fromMap(result);

        setDoctor(doctor);

        // Initialize the push notification token stream to track refreshed token
        LocatorService.pushNotificationService().setRefreshedTokenFor(
          doctorId: result['uid'],
        );

        return true;
      } else {
        return false;
      }
    } catch (e) {
      log(e.toString(), name: 'DP');
      return false;
    }
  }

  void updateName(String value) {
    _doctor.name = value;
    notifyListeners();
  }

  void updateImage(String url) {
    _doctor.imageUrl = url;
    notifyListeners();
  }

  void updateDoctorData(Doctor doctor) {
    setDoctor(doctor);
    notifyListeners();
  }

  void updateDoctorAddress(
    Map<String, dynamic> address,
    Map<String, dynamic> location,
  ) {
    _doctor.address = Address.fromMap(address);
    _doctor.location = Location.fromJson(location);
    notifyListeners();
  }
}
