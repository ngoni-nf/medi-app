// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:flutter/foundation.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/models/slot.dart';

///
/// ## `Description`
///
/// Holds information about the type of format chosen to
/// connect to the doctor.
///
class ConsultationProvider with ChangeNotifier {
  // Initial type
  ConsultationFormatType _formatType = ConsultationFormatType.CHAT;

  ConsultationFormatType get formatType => _formatType;

  set setConsultationFormatType(ConsultationFormatType type) {
    _formatType = type;
    _formatTypeString = getConsultationFormatString(type);
    notifyListeners();
  }

  // Get consultation format type string
  String _formatTypeString = 'Chat';

  String get formatTypeString => _formatTypeString;

  // Doctor id
  Doctor _doctor;

  Doctor get doctor => _doctor;

  set setDoctor(Doctor value) {
    _doctor = value;
    notifyListeners();
  }

  // User id
  String userId = LocatorService.userProvider().user.uid;

  // Amount to be paid
  String _amount;

  String get amount => _amount;

  set setAmount(String value) {
    _amount = value;
    notifyListeners();
  }

  // title of the appointment
  String _title;

  String get title => _title;

  set setTitle(String value) {
    _title = value;
    notifyListeners();
  }

  Slot _slot;

  Slot get slot => _slot;

  set setSlot(Slot value) {
    _slot = value;
    notifyListeners();
  }

  String _selfDiagnosisReportDocumentId;

  String get selfDiagnosisReportDocumentId => _selfDiagnosisReportDocumentId;

  set selfDiagnosisReportDocumentId(String value) {
    _selfDiagnosisReportDocumentId = value;
    notifyListeners();
  }

  /// Clears all the data in the storage variables when the user sign out.
  /// Must only be run when the user sign out of an account.
  void clearData() {
    _formatType = ConsultationFormatType.CHAT;
    _formatTypeString = 'Chat';
    _doctor = null;
    _amount = null;
    _title = null;
    _slot = null;
    _selfDiagnosisReportDocumentId= null;
  }

  /// Get the string value for the consultation type based on the enum
  static String getConsultationFormatString(ConsultationFormatType type) {
    switch (type) {
      case ConsultationFormatType.CHAT:
        return 'Chat';
        break;
      case ConsultationFormatType.VIDEO_CALL:
        return 'Video Call';
        break;
      case ConsultationFormatType.VOICE_CALL:
        return 'Voice Call';
        break;
      case ConsultationFormatType.NOT_DEFINED:
        return 'Not Defined';
        break;
      default:
        return 'Not Defined';
    }
  }
}

enum ConsultationFormatType {
  CHAT,
  VIDEO_CALL,
  VOICE_CALL,
  NOT_DEFINED,
}
