// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/appointment.dart';
import 'package:medivic/models/payment.dart';
import 'package:medivic/models/slot.dart';
import 'package:medivic/utils/common_utils.dart';

/// Handles all the communication related logic
class AppointmentSetupProvider with ChangeNotifier {
  // Flags to change the UI.
  bool isLoading = false;
  bool isAppointmentSuccessful = false;
  bool isAppointmentFailed = false;

  // message to display to the ui
  String displayMessage = '';

  // Updates the UI
  void updateUI(
    String message, {
    bool setLoading = true,
    bool setAppointmentSuccessful = false,
    bool setAppointmentFailed = false,
  }) {
    displayMessage = message;
    isLoading = setLoading;
    isAppointmentSuccessful = setAppointmentSuccessful;
    isAppointmentFailed = setAppointmentFailed;
    notifyListeners();
  }

  ///
  /// ## `Description`
  ///
  /// When an appointment is successfully created, update the UI to show
  /// success message.
  ///
  /// ### `Important`
  ///
  /// * Triggers an `Appointment Fetch` action to get all the new
  /// appointments and add the new one to the list as well.
  ///
  void onAppointmentSuccessful() {
    updateUI('', setLoading: false, setAppointmentSuccessful: true);
  }

  void onAppointmentFailed() {
    updateUI('', setLoading: false, setAppointmentFailed: true);
    Fluttertoast.showToast(msg: AppStrings.appointmentFailed);
  }

  Future<void> initiateAppointment() async {
    updateUI(AppStrings.settingUpAppointment);

    final Appointment appointment = Appointment(
      LocatorService.consultationProvider().slot.documentId,
      LocatorService.userProvider().user.uid,
      LocatorService.userProvider().user.name,
      LocatorService.userProvider().user.imageUrl,
      LocatorService.consultationProvider().doctor.uid,
      LocatorService.consultationProvider().doctor.name,
      LocatorService.consultationProvider().doctor.imageUrl,
      LocatorService.consultationProvider().slot.date,
      LocatorService.consultationProvider().slot.startTime,
      LocatorService.consultationProvider().slot.endTime,
      LocatorService.consultationProvider().selfDiagnosisReportDocumentId,
      LocatorService.consultationProvider().title,
      DateTime.now().millisecondsSinceEpoch,
    );

    Firestore.instance
        .collection(Appointment.COLLECTION_NAME)
        .add(appointment.toJson())
        .then(
      (value) async {
        await addPaymentRecord(value.documentID);
        await setSlotAsBooked();
        onAppointmentSuccessful();
      },
    ).catchError((err) => onAppointmentFailed());
  }

  Future<void> addPaymentRecord(String appointmentId) async {
    final Payment payment = Payment(
      appointmentId,
      LocatorService.userProvider().user.uid,
      LocatorService.consultationProvider().doctor.uid,
      LocatorService.userProvider().user.name,
      LocatorService.consultationProvider().doctor.name,
      LocatorService.consultationProvider().title,
      CommonUtils.parseDouble(LocatorService.consultationProvider().amount),
      false,
      DateTime.now().millisecondsSinceEpoch,
    );
    await Firestore.instance
        .collection(Payment.COLLECTION_NAME)
        .add(payment.toMap());
  }

  Future<void> setSlotAsBooked() async {
    await Firestore.instance
        .collection(Slot.COLLECTION_NAME)
        .document(LocatorService.consultationProvider().slot.documentId)
        .updateData({'booked': true});
  }

  Future<void> runMockTest() async {
    updateUI('Initiating an appointment');
    await Future.delayed(const Duration(seconds: 3));
    onAppointmentSuccessful();
    // onAppointmentFailed();
  }
}
