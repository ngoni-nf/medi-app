// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:developer';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/addressModel.dart';
import 'package:medivic/models/userModel.dart';
import 'package:medivic/services/api/firestoreService.dart';

///
/// ## Description
///
/// Provider that handles `User` data in the state.
/// Cares about the user data after it has been loaded into memory from the server.
///
class UserProvider with ChangeNotifier {
  // Set the userId for the app when the user signup or login.
  String _userId = '';

  String get userId => _userId;

  void setUserId(String value) {
    log(value, name: 'UserProvider setUserId');
    _userId = value;
  }

  User _user;

  User get user => _user;

  void setUser(User user) {
    LocatorService.doctorProvider().clearData();
    _user = user;
  }

  /// Clears all the data in the storage variables when the user sign out.
  /// Must only be run when the user sign out of an account.
  void clearData() {
    _userId = '';
    _user = null;
  }

  Future<bool> fetchUserData(String id) async {
    try {
      log('Fetching data for user id $id', name: 'UP');
      final Map<String, dynamic> result =
          await FirestoreService.getUserInfo(id);
      if (result != null) {
        setUser(User.fromJson(result));

        // Initialize the push notification token stream to track refreshed token
        LocatorService.pushNotificationService().setRefreshedTokenFor(
          userId: result['uid'],
        );

        return true;
      } else {
        return false;
      }
    } catch (e) {
      log(e.toString(), name: 'UP');
      return false;
    }
  }

  void updateImage(String url) {
    _user.imageUrl = url;
    notifyListeners();
  }

  void updateUserData(User user) {
    // set user again
    setUser(user);
    notifyListeners();
  }

  void updateAddress(PatientAddress address) {
    _user.address = address;
    notifyListeners();
  }
}
