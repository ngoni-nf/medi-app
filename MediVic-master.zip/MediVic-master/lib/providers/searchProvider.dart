// Copyright (c) 2020 MediVic
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of MediVic. The intellectual and technical concepts
// contained herein are proprietary to MediVic and are protected
// by trade secret or copyright law.
//
// Dissemination of this information or reproduction of this material
// is strictly forbidden unless prior written permission is obtained from
// MediVic.

import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:medivic/constants/appStrings.dart';
import 'package:medivic/constants/config.dart';
import 'package:medivic/extensions/string_extensions.dart';
import 'package:medivic/locator.dart';
import 'package:medivic/models/doctorModel.dart';
import 'package:medivic/models/hospitalModel.dart';
import 'package:medivic/models/specialityModel.dart';
import 'package:medivic/providers/utils/baseProvider.dart';
import 'package:medivic/services/api/firestoreService.dart';

/// Manages the state of the search screen
class SearchProvider extends BaseProvider {
  String _searchTerm = '';

  String get searchTerm => _searchTerm;

  set setSearchTerm(String value) {
    _searchTerm = value;
  }

  // By default this is the search filter type.
  SearchFilterType _filter = SearchFilterType.DOCTOR;

  SearchFilterType get filter => _filter;

  set setFilter(SearchFilterType type) {
    _filter = type;
    if (_searchTerm.isNotEmpty) {
      // NotifyLoading calls the fetch data automatically.
      notifyLoading();
    }
  }

  int _radius = Config.DOCTOR_FILTER_DEFAULT_RADIUS;

  int get radius => _radius;

  set setRadius(int radius) {
    _radius = radius;
    notifyLoading();
  }

  String _speciality;

  String get speciality => _speciality;

  set setSpeciality(String speciality) {
    _speciality = speciality;
    notifyLoading();
  }

  void resetDoctorFilter() {
    _speciality = null;
    _radius = Config.DOCTOR_FILTER_DEFAULT_RADIUS;
    notifyLoading();
  }

  // Data stores:
  List<Doctor> _doctorList = [];
  List<Doctor> _specialityDoctorList = [];
  List<Hospital> _hospitalList = [];

  List<Doctor> get doctorList => _doctorList;

  List<Doctor> get specialityDoctorList => _specialityDoctorList;

  List<Hospital> get hospitalList => _hospitalList;

  // Ref to last DocumentSnapshot for query results
  DocumentSnapshot _lastSpecialityDoctorDocument;

  /// Clears all the data in the storage variables when the user sign out.
  /// Must only be run when the user sign out of an account.
  void clearData() {
    _searchTerm = '';
    _filter = SearchFilterType.DOCTOR;
    _doctorList = [];
    _specialityDoctorList = [];
    _hospitalList = [];
    _lastSpecialityDoctorDocument = null;
  }

  void searchData() {
    switch (_filter) {
      case SearchFilterType.DOCTOR:
        searchDoctors();
        break;

      case SearchFilterType.HOSPITAL:
        searchHospitals();
        break;

      case SearchFilterType.SPECIALITY:
        searchDoctorsSpeciality();
        break;

      default:
        searchDoctors();
    }
  }

  /// ********************************************************
  /// `Hospitals Functions`
  /// ********************************************************

  Future<void> searchHospitals() async {
    try {
      final result = await LocatorService.algoliaApi()
          .search(searchTerm, Config.ALGOLIA_HOSPITALS_INDEX);

      if (result == null) {
        notifyError(errorText: AppStrings.searchSomething);
        return;
      } else {
        final list = <Hospital>[];
        for (final elem in result) {
          final Hospital obj = Hospital.fromMap(elem.data);
          list.add(obj);
        }
        _hospitalList = list;
        notifyState(ViewState.DATA);
      }
    } catch (e) {
      notifyError(errorText: e.toString());
    }
  }

  Future<List<Hospital>> getHospitals(String searchTerm) async {
    try {
      final result = await LocatorService.algoliaApi()
          .search(searchTerm, Config.ALGOLIA_HOSPITALS_INDEX);

      if (result == null) {
        // notifyError(errorText: AppStrings.searchSomething);
        return [];
      } else {
        final list = <Hospital>[];
        for (final elem in result) {
          final Hospital obj = Hospital.fromMap(elem.data);
          list.add(obj);
        }
        _hospitalList = list;
        // notifyState(ViewState.DATA);
      }
    } catch (e) {
      notifyError(errorText: e.toString());
    }
    return _hospitalList;
  }


  Future<void> searchMoreHospitals(int page) async {
    try {
      log('Searching more Hospitals');
      final result = await LocatorService.algoliaApi()
          .search(searchTerm, Config.ALGOLIA_HOSPITALS_INDEX, page: page);

      if (result.isEmpty && _hospitalList.isEmpty) {
        log('No data');
        notifyState(ViewState.NO_DATA_AVAILABLE);
        return;
      } else {
        for (final elem in result) {
          final Hospital obj = Hospital.fromMap(elem.data);
          _hospitalList.add(obj);
        }
        notifyState(ViewState.DATA);
      }
    } catch (e) {
      if (_hospitalList.isNotEmpty) {
        notifyState(ViewState.DATA);
      } else {
        log('Error $e');
        notifyError(errorText: e.toString());
      }
    }
  }

  /// ***********************************************************
  /// `Doctors Functions`
  /// ***********************************************************

  Future<void> searchDoctors() async {
    try {
      log('Calling search doctors');
      final result = await LocatorService.algoliaApi()
          .search(searchTerm, Config.ALGOLIA_DOCTORS_INDEX, radius: radius);
      _doctorList = Doctor.filterDoctorsBySpeciality(Doctor.parseList(result).toList(),speciality);

      if (_doctorList.isEmpty) {
        notifyState(ViewState.NO_DATA_AVAILABLE);
        return;
      }
      notifyState(ViewState.DATA);
    } catch (e) {
      notifyError(errorText: e.toString());
    }
  }

  Future<void> searchMoreDoctors(int page) async {
    try {
      log('Searching more doctors');
      final result = await LocatorService.algoliaApi().search(
          searchTerm, Config.ALGOLIA_DOCTORS_INDEX,
          page: page, radius: radius);

      if (result.isEmpty && _doctorList.isEmpty) {
        log('No data');
        notifyState(ViewState.NO_DATA_AVAILABLE);
        return;
      } else {
        _doctorList.addAll(Doctor.parseList(result));
        notifyState(ViewState.DATA);
      }
    } catch (e) {
      if (_doctorList.isNotEmpty) {
        notifyState(ViewState.DATA);
      } else {
        log('Error $e');
        notifyError(errorText: e.toString());
      }
    }
  }

  /// ******************************************************
  /// Speciality related functions
  /// ******************************************************

  Future<void> searchDoctorsSpeciality() async {
    if (_searchTerm.isEmpty) {
      return;
    }

    final List<String> searchList = _searchTerm.split(',').map<String>((e) {
      return e.toLowerCase();
    }).toList();

    try {
      log('Calling speciality search doctors');
      final result =
          await FirestoreService.searchDoctorsWithSpeciality(searchList);

      if (result.isEmpty && _specialityDoctorList.isEmpty) {
        log('No data');
        notifyState(ViewState.NO_DATA_AVAILABLE);
        return;
      } else {
        // set the last document reference
        _lastSpecialityDoctorDocument = result.last;
        _specialityDoctorList = Doctor.parseList(result);
        notifyState(ViewState.DATA);
      }
    } catch (e) {
      notifyError(errorText: e.toString());
    }
  }

  Future<void> searchMoreDoctorsSpeciality() async {
    if (_searchTerm.isEmpty) {
      return;
    }

    final List<String> searchList = _searchTerm.split(',').map<String>((e) {
      return e.toLowerCase();
    }).toList();

    try {
      log('Searching more doctors');
      final result = await FirestoreService.searchMoreDoctorsWithSpeciality(
          _lastSpecialityDoctorDocument, searchList);

      if (result.isEmpty && _specialityDoctorList.isEmpty) {
        log('No data');
        notifyState(ViewState.NO_DATA_AVAILABLE);
        return;
      } else {
        // set the last document reference
        _lastSpecialityDoctorDocument =
            result.last ?? _lastSpecialityDoctorDocument;

        _specialityDoctorList.addAll(Doctor.parseList(result));
        notifyState(ViewState.DATA);
      }
    } catch (e) {
      if (_specialityDoctorList.isNotEmpty) {
        notifyState(ViewState.DATA);
      } else {
        log('Error $e');
        notifyError(errorText: e.toString());
      }
    }
  }
}

/// Types of data filters that can be sorted through.
enum SearchFilterType {
  DOCTOR,
  HOSPITAL,
  BLOGS,
  DISEASE,
  SPECIALITY,
}
