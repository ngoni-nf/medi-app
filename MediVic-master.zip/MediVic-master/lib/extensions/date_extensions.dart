import 'package:intl/intl.dart';

extension DateExtension on DateTime {
  static const String _FULL_DATE_FORMAT = 'EEEE, d MMMM, yyyy';
  static const String _FULL_TIME_FORMAT = 'hh:mm a';

  String getSubtitle() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final tomorrow = DateTime(now.year, now.month, now.day + 1);

    final dateToCheck = DateTime(year, month, day);
    if (dateToCheck == today)
      return 'Today';
    else if (dateToCheck == tomorrow) return 'Tomorrow';
    return '';
  }

  String formatMonthName() {
    return DateFormat('MMMM').format(this);
  }

  bool isSameDay(DateTime dateTime) {
    final int diffDays = difference(dateTime).inDays;
    return diffDays == 0 && day == dateTime.day;
  }

  bool isToday() => isSameDay(DateTime.now());

  bool isBeforeToday() {
    final DateTime today = DateTime.now();
    return year < today.year ||
        (year == today.year && month < today.month) ||
        (year == today.year && month == today.month && day < today.day);
  }

  bool isAfterToday() => !isBeforeToday() && !isToday();

  String formatWeekDate() {
    return DateFormat('dd MMM yyyy').format(this);
  }

  String formatMonthYear() {
    return DateFormat('MMMM, yyyy').format(this);
  }

  String formatShortDate() {
    return DateFormat('EEE, dd MMM, yyyy').format(this);
  }

  String formatFullDate() {
    return DateFormat(DateExtension._FULL_DATE_FORMAT).format(this);
  }

  String formatFullTime() {
    return DateFormat(DateExtension._FULL_TIME_FORMAT).format(this);
  }

  String formatFullDateTime() => '${formatFullTime()} , ${formatFullDate()}';

  String formatDayOfWeek() {
    return DateFormat('EEE').format(this);
  }

  String formatDayAndMonthShort() {
    return DateFormat('d MMM').format(this).toUpperCase();
  }

  String formatDayAndMonthLong() {
    return DateFormat('MMMM d').format(this);
  }

  DateTime copyDate() {
    return DateTime(year, month, day);
  }

  int weekNumber() {
    final int dayOfYear = int.parse(DateFormat('D').format(this));
    return ((dayOfYear - weekday + 10) / 7).floor() + 1;
  }

  int compareTo(DateTime dateTime) {
    if (isBefore(dateTime)) {
      return -1;
    }
    if (isAfter(dateTime)) {
      return 1;
    }
    return 0;
  }

  bool isSameOfBefore(DateTime dateTime) {
    return isAtSameMomentAs(dateTime) || isBefore(dateTime);
  }

  bool isSameOfAfter(DateTime dateTime) {
    return isAtSameMomentAs(dateTime) || isAfter(dateTime);
  }

  static DateTime parseFullDate(String rawDate) {
    try {
      return DateFormat(DateExtension._FULL_DATE_FORMAT).parse(rawDate);
    } catch (e) {
      return DateTime.now();
    }
  }

  static DateTime parseFullDateTime(String rawDateTime) {
    try {
      return DateFormat(
              '${DateExtension._FULL_TIME_FORMAT}, ${DateExtension._FULL_DATE_FORMAT}')
          .parse(rawDateTime);
    } catch (e) {
      return DateTime.now();
    }
  }

  static DateTime getStartOfToday() {
    final DateTime current = DateTime.now();
    return DateTime(current.year, current.month, current.day);
  }

  static DateTime getStartOfWeek() {
    final DateTime current = DateTime.now();
    final DateTime startOfWeek =
        current.subtract(Duration(days: current.weekday - 1));
    return DateTime(startOfWeek.year, startOfWeek.month, startOfWeek.day);
  }

  static DateTime getStartOfMonth() {
    final DateTime current = DateTime.now();
    return DateTime(current.year, current.month);
  }

  static DateTime getStartOfYear() => DateTime(DateTime.now().year);
}
