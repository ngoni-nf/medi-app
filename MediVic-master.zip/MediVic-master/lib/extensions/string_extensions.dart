extension StringExtension on String {
  String capitalize() {
    return isEmpty ? '' : '${this[0].toUpperCase()}${substring(1)}';
  }
}



class StringUtils {
  static bool containsIgnoreCase(List<String> list, String value) {
    return list
        .where((element) => element.toLowerCase() == value.toLowerCase())
        .isNotEmpty;
  }

  static String capFirstOfEach(String data) {
    if (data == null || data.isEmpty) {
      return '';
    }
    return data.split(' ').map((str) {
      if(str.toLowerCase()=='hiv/aids'){
        return str.toUpperCase();
      }
      return '${str[0].toUpperCase()}${str.substring(1)}';
    }).join(' ');
  }
}
