package com.akili.medivic.video

import android.util.Log
import android.view.Gravity.END
import android.view.Gravity.START
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.akili.medivic.R
import kotlinx.android.synthetic.main.layout_message.view.*
import java.text.SimpleDateFormat
import java.util.*

class MessageListAdapter(
        private val messages: List<Map<String, Any>>,
        private val senderId: Long
) :
        RecyclerView.Adapter<MessageListAdapter.MessageViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        return MessageViewHolder(
                LayoutInflater.from(parent.context).inflate(
                        R.layout.layout_message,
                        parent,
                        false
                ),
                senderId
        )
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.bind(messages[position], if (position < messages.size - 1) messages[position + 1] else null)
    }

    override fun getItemCount(): Int = messages.size


    class MessageViewHolder(itemView: View, private val senderId: Long) : RecyclerView.ViewHolder(itemView) {
        private val txtMessageContent: TextView = itemView.findViewById(R.id.txtMessageContent)
        private val txtMessageDate: TextView = itemView.findViewById(R.id.txtMessageDate)
        private val txtMessageTime: TextView = itemView.findViewById(R.id.txtMessageTime)
        private val llMessageContainer: LinearLayout =
                itemView.findViewById(R.id.llMessageContainer)

        fun bind(message: Map<String, Any>, nextMessage: Map<String, Any>?) {
            val previousDateTime = getMessageDateTime(if (nextMessage == null) 0 else nextMessage["createdAt"])
            val dateTime = getMessageDateTime(message["createdAt"])
            txtMessageDate.text = dateTime[0]
            txtMessageTime.text = dateTime[1]
            txtMessageDate.visibility = if (nextMessage == null || dateTime[0] != previousDateTime[0]) View.VISIBLE else View.GONE
            txtMessageTime.visibility = if (nextMessage == null || nextMessage["sender"] != message["sender"] || dateTime[1] != previousDateTime[1]) View.VISIBLE else View.GONE
            txtMessageContent.text = message["text"] as String?
            if ((message["sender"] as Long?) == senderId) {
                llMessageContainer.gravity = END
                itemView.txtMessageContent.setBackgroundResource(R.drawable.sent_message_background)
            } else {
                itemView.txtMessageContent.setBackgroundResource(R.drawable.received_message_background)
                llMessageContainer.gravity = START
            }
        }

        private fun getMessageDateTime(timestamp: Any?): Array<String> {
            var date = ""
            var time = ""
            if (timestamp is Long) {
                try {
                    val dateFormat = SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH)
                    val timeFormat = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
                    val formattedDate = Date(timestamp)
                    date = dateFormat.format(formattedDate)
                    time = timeFormat.format(formattedDate)
                    if (date == dateFormat.format(Date())) {
                        date = "Today"
                    }
                } catch (e: Exception) {
                    Log.e(Const.LOG_TAG, e.message ?: "")
                }
            }
            return arrayOf(date, time)
        }

    }

}