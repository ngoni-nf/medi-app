package com.akili.medivic.video

import android.content.Context
import android.os.CountDownTimer
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import com.akili.medivic.R
import com.akili.medivic.video.Const.Companion.CALL_END_NOTIFICATION_INTERVAL
import com.akili.medivic.video.Const.Companion.CALL_END_NOTIFICATION_TIME
import kotlinx.android.synthetic.main.layout_call_timer.view.*

class CallTimer @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    init {
        LayoutInflater.from(context).inflate(R.layout.layout_call_timer, this, true)
    }

    fun setUpTimer(endTime: Long, onTimerFinish: () -> Unit) {
        val timeToCallEnd = endTime - System.currentTimeMillis()
        val timer = object : CountDownTimer(timeToCallEnd, CALL_END_NOTIFICATION_INTERVAL) {
            override fun onTick(millisUntilFinished: Long) {
                if (millisUntilFinished <= CALL_END_NOTIFICATION_TIME) {
                    showCallTerminatingMessage(millisUntilFinished)
                }
            }

            override fun onFinish() = onTimerFinish()
        }
        timer.start()
    }

    private fun showCallTerminatingMessage(millisUntilFinished: Long) {
        txtTimerMessage.visibility = VISIBLE
        txtTimerMessage.text = String.format(
                context.getString(R.string.call_ending_message),
                (millisUntilFinished / 1000).toInt()
        )
    }

}