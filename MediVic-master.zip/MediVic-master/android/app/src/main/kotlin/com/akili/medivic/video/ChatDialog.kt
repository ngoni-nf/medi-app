package com.akili.medivic.video

import android.app.Dialog
import android.content.Context
import android.graphics.Color.TRANSPARENT
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.Window.FEATURE_NO_TITLE
import com.akili.medivic.R
import com.google.firebase.Timestamp
import com.google.firebase.firestore.Query.Direction.DESCENDING
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.dialog_chat.*

class ChatDialog(context: Context,
                 private val participantName: String,
                 private val doctorId: String,
                 private val patientId: String,
                 isPatient: Boolean)
    : Dialog(context) {

    private lateinit var messageListAdapter: MessageListAdapter
    private var messages = mutableListOf<Map<String, Any>>()
    private val db = Firebase.firestore
    private val senderId: Long = if (isPatient) 1 else 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_chat)
        populateChat()
    }

    private fun populateChat() {
        setUpRecyclerView()
        txtParticipantName.text = participantName
        btnCloseChat.setOnClickListener {
            hide()
        }
        btnSendMessage.setOnClickListener {
            sendMessage()
        }
    }

    private fun setUpRecyclerView() {
        messageListAdapter = MessageListAdapter(messages, senderId)
        rvMessages.adapter = messageListAdapter
        db.collection("messages")
                .whereEqualTo("userId", patientId)
                .whereEqualTo("doctorId", doctorId)
                .orderBy("createdAt", DESCENDING)
                .addSnapshotListener { value, e ->
                    if (e == null && value != null) {
                        messages.clear()
                        messages.addAll(value.map { it.data })
                        messageListAdapter.notifyDataSetChanged()
                    }
                }
    }

    private fun sendMessage() {
        if (edtMessage.text.isBlank()) return
        val timestamp = Timestamp.now()
        val createdAt: Long = (timestamp.seconds * 1000) + timestamp.nanoseconds / 1000000
        val data = mapOf(
                "createdAt" to createdAt,
                "doctorId" to doctorId,
                "userId" to patientId,
                "sender" to senderId,
                "text" to edtMessage.text.toString()
        )
        db.collection("messages").add(data)
        edtMessage.setText("")
    }

    override fun show() {
        super.show()
        window?.setLayout(MATCH_PARENT, MATCH_PARENT)
        window?.setBackgroundDrawable(ColorDrawable(TRANSPARENT))
    }

}