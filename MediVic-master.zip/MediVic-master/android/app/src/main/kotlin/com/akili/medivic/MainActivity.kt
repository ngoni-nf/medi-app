package com.akili.medivic

import android.content.Intent
import com.akili.medivic.video.Const.Companion.CHANNEL
import com.akili.medivic.video.Const.Companion.VIDEO_ACTIVITY_RC
import com.akili.medivic.video.VideoActivity
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private lateinit var videoCallResult: MethodChannel.Result

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
                .setMethodCallHandler { call, result ->
                    if (call.method == "startVideoCall") {
                        videoCallResult = result
                        navigateToVideoCallActivity(call)
                    } else {
                        result.notImplemented()
                    }
                }
    }

    private fun navigateToVideoCallActivity(call: MethodCall) {
        val intent = Intent(this@MainActivity, VideoActivity::class.java)
        intent.putExtra("appointmentId", call.argument<String>("appointmentId")!!)
        intent.putExtra("isPatient", call.argument<Boolean>("isPatient")!!)
        intent.putExtra("doctorId", call.argument<String>("doctorId")!!)
        intent.putExtra("patientId", call.argument<String>("patientId")!!)
        intent.putExtra("doctorImageUrl", call.argument<String>("doctorImageUrl")!!)
        intent.putExtra("patientImageUrl", call.argument<String>("patientImageUrl")!!)
        intent.putExtra("doctorName", call.argument<String>("doctorName")!!)
        intent.putExtra("patientName", call.argument<String>("patientName")!!)
        intent.putExtra("endTime", call.argument<Long>("endTime")!!)
        startActivityForResult(intent, VIDEO_ACTIVITY_RC)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VIDEO_ACTIVITY_RC) {
            if (::videoCallResult.isInitialized)
                videoCallResult.success(true)
        }
    }


}
