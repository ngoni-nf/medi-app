package com.akili.medivic.video

import android.annotation.SuppressLint
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.akili.medivic.R
import com.akili.medivic.video.Const.Companion.LOG_TAG
import com.google.firebase.ktx.Firebase
import com.google.firebase.ktx.initialize
import com.koushikdutta.ion.Ion
import com.opentok.android.*
import com.opentok.android.PublisherKit.PublisherListener
import com.opentok.android.Session.SessionListener
import kotlinx.android.synthetic.main.activity_video.*


class VideoActivity : AppCompatActivity(), SessionListener, PublisherListener {
    private lateinit var session: Session
    private lateinit var publisher: Publisher
    private var subscriber: Subscriber? = null
    private lateinit var waitingDialog: WaitingDialog
    private lateinit var chatDialog: ChatDialog
    private lateinit var appointmentId: String
    private lateinit var patientId: String
    private lateinit var patientName: String
    private lateinit var patientImageUrl: String
    private lateinit var doctorId: String
    private lateinit var doctorName: String
    private lateinit var doctorImageUrl: String
    private var endTime: Long = 0
    private var isPatient: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video)
        init()
    }

    private fun init() {
        Firebase.initialize(this)
        getIntentData()
        initDialogs()
        initTimer()
        showParticipantImages()
        getVonageCredentials()
        buildControls()
        makePublisherVideoDraggable()
        if (isPatient) waitingDialog.show()
    }

    private fun getIntentData() {
        appointmentId = intent.getStringExtra("appointmentId")!!
        isPatient = intent.getBooleanExtra("isPatient", true)
        patientId = intent.getStringExtra("patientId")!!
        patientName = intent.getStringExtra("patientName")!!
        patientImageUrl = intent.getStringExtra("patientImageUrl")!!
        doctorId = intent.getStringExtra("doctorId")!!
        doctorName = intent.getStringExtra("doctorName")!!
        doctorImageUrl = intent.getStringExtra("doctorImageUrl")!!
        endTime = intent.getLongExtra("endTime", 0)
    }

    private fun showParticipantImages() {
        Ion.with(this)
                .load(if (isPatient) patientImageUrl else doctorImageUrl)
                .intoImageView(imgPublisher)
        Ion.with(this)
                .load(if (isPatient) doctorImageUrl else patientImageUrl)
                .intoImageView(imgSubscriber)
    }

    private fun initTimer() {
        callTimer.setUpTimer(endTime) { exitCallScreen() }
    }

    private fun initDialogs() {
        waitingDialog = WaitingDialog(
                this@VideoActivity,
                patientName,
                patientImageUrl
        ) {
            exitCallScreen()
        }
        chatDialog = ChatDialog(
                this@VideoActivity,
                if (isPatient) doctorName else patientName,
                doctorId,
                patientId,
                isPatient
        )
    }

    private fun dismissWaitingDialog() {
        if (::waitingDialog.isInitialized) waitingDialog.dismiss()
    }

    private fun buildControls() {
        fabSwitchCamera.setOnClickListener {
            publisher.cycleCamera()
        }
        fabMute.setOnClickListener {
            publisher.publishAudio = !publisher.publishAudio
            fabMute.setImageResource(if (publisher.publishAudio) R.drawable.ic_mic else R.drawable.ic_mic_off)
        }
        fabEndCall.setOnClickListener {
            callEndConfirmation()
        }
        fabChat.setOnClickListener {
            chatDialog.show()
        }
    }

    private fun createSession(apiKey: String, sessionId: String, token: String) {
        session = Session.Builder(this, apiKey, sessionId).build()
        session.setSessionListener(this)
        session.connect(token)
    }

    private fun renderPublisherVideoFeed() {
        publisher = Publisher.Builder(this).build()
        publisher.setPublisherListener(this)
        publisher_container.addView(publisher.view)
        if (publisher.view is GLSurfaceView) {
            (publisher.view as GLSurfaceView).setZOrderOnTop(true)
        }
        session.publish(publisher)
        fabSwitchCamera.isEnabled = true
        fabMute.isEnabled = true
    }

    private fun renderSubscriberVideoFeed(stream: Stream?) {
        if (subscriber == null) {
            subscriber = Subscriber.Builder(this, stream).build()
            session.subscribe(subscriber)
            subscriber_container.addView(subscriber?.view)
        }
    }

    private fun getVonageCredentials() {
        Log.i(LOG_TAG, "Fetching Vonage Credentials")
        Ion.with(this)
                .load("https://us-central1-medivic-aa5d3.cloudfunctions.net/generateVonageToken?appointmentId=${appointmentId}")
                .asJsonObject()
                .setCallback { e, result ->
                    if (e == null) {
                        if (result.get("success").asBoolean) {
                            createSession(
                                    result.get("apiKey").asString,
                                    result.get("sessionId").asString,
                                    result.get("token").asString,
                            )
                        } else {
                            showErrorDialog()
                        }
                    } else {
                        showErrorDialog()
                    }
                }
    }

    private fun showErrorDialog() {
        if (isFinishing) return
        AlertDialog.Builder(this)
                .setMessage("Something went wrong. Please try again later.")
                .setCancelable(false)
                .setPositiveButton("OK") { dialog, _ ->
                    dialog.dismiss()
                    exitCallScreen()
                }.create().show()
    }

    private fun callEndConfirmation() {
        AlertDialog.Builder(this)
                .setTitle("End Call")
                .setMessage("Are you sure you want to end this call?")
                .setCancelable(false)
                .setPositiveButton("Yes") { dialog, _ ->
                    dialog.dismiss()
                    exitCallScreen()
                }.setNegativeButton("No") { dialog, _ ->
                    dialog.dismiss()
                }.create().show()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makePublisherVideoDraggable() {
        val listener = View.OnTouchListener { view, motionEvent ->
            if (motionEvent.action == MotionEvent.ACTION_MOVE) {
                view.y = motionEvent.rawY - view.height / 2
                view.x = motionEvent.rawX - view.width / 2
            }
            true
        }
        publisher_container.setOnTouchListener(listener)
    }

    private fun exitCallScreen() {
        if (::session.isInitialized) session.disconnect()
        dismissWaitingDialog()
        if (::chatDialog.isInitialized) chatDialog.dismiss()
        finish()
    }

    override fun onConnected(session: Session?) {
        Log.i(LOG_TAG, "Session Connected")
        renderPublisherVideoFeed()
    }

    override fun onDisconnected(session: Session?) {
        Log.i(LOG_TAG, "Session Disconnected")
    }

    override fun onStreamReceived(session: Session?, stream: Stream?) {
        Log.i(LOG_TAG, "Stream Received")
        dismissWaitingDialog()
        renderSubscriberVideoFeed(stream)
    }

    override fun onStreamDropped(session: Session?, stream: Stream?) {
        Log.i(LOG_TAG, "Stream Dropped")
        if (subscriber != null) {
            subscriber = null
            subscriber_container.removeAllViews()
        }
    }

    override fun onError(session: Session?, opentokError: OpentokError) {
        Log.e(LOG_TAG, "Session error: " + opentokError.message)
        showErrorDialog()
    }

    override fun onStreamCreated(publisherKit: PublisherKit?, stream: Stream?) {
        Log.i(LOG_TAG, "Publisher onStreamCreated")
    }

    override fun onStreamDestroyed(publisherKit: PublisherKit?, stream: Stream?) {
        Log.i(LOG_TAG, "Publisher onStreamDestroyed")
    }

    override fun onError(publisherKit: PublisherKit?, opentokError: OpentokError) {
        Log.e(LOG_TAG, "Publisher error: " + opentokError.message)
        showErrorDialog()
    }

    override fun onBackPressed() = callEndConfirmation()

}