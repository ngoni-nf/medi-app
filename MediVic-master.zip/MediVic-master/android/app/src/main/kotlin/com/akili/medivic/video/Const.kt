package com.akili.medivic.video

class Const {

    companion object {
        const val CHANNEL = "com.centrax.medivic"
        const val VIDEO_ACTIVITY_RC = 101
        const val LOG_TAG = "VONAGE_VIDEO"
        const val CALL_END_NOTIFICATION_TIME: Long = 30000
        const val CALL_END_NOTIFICATION_INTERVAL: Long = 5000
    }

}