package com.akili.medivic.video

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.Window
import com.akili.medivic.R
import com.koushikdutta.ion.Ion
import kotlinx.android.synthetic.main.dialog_waiting.*

class WaitingDialog(context: Context,
                    private val patientName: String,
                    private val patientImageUrl: String,
                    private val onClose: () -> Unit
) : Dialog(context) {

    init {
        setCancelable(false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_waiting)
        populatePatientDetails()
        btnClose.setOnClickListener {
            dismiss()
            onClose()
        }
    }

    override fun show() {
        super.show()
        window?.setLayout(MATCH_PARENT, MATCH_PARENT)
    }

    private fun populatePatientDetails() {
        txtPatientName.text = patientName
        Ion.with(context)
                .load(patientImageUrl)
                .intoImageView(imgPatientImage)
    }
}