import UIKit
import Flutter
import GoogleMaps
import Firebase

@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {
    override func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        //    GeneratedPluginRegistrant.register(with: self)
        if(!UserDefaults.standard.bool(forKey: "Notification")) {
            UIApplication.shared.cancelAllLocalNotifications()
            UserDefaults.standard.set(true, forKey: "Notification")
        }
        
        if #available(iOS 10.0, *) {
            UNUserNotificationCenter.current().delegate = self as? UNUserNotificationCenterDelegate
        }
        FirebaseApp.configure()
        GMSServices.provideAPIKey("AIzaSyAC53EnO9budvkF6xVC77qnA9XbFkKkVms")
        GeneratedPluginRegistrant.register(with: self)
        setUpMethodChannel()
        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
    
    func setUpMethodChannel() {
        let flutterViewController: FlutterViewController = window?.rootViewController as! FlutterViewController
        let navigationController = UINavigationController(rootViewController: flutterViewController)
        let channel = FlutterMethodChannel(name: "com.akili.medivic", binaryMessenger: flutterViewController.binaryMessenger)
        
        channel.setMethodCallHandler({
            (call: FlutterMethodCall, result: FlutterResult) -> Void in
            guard call.method == "startVideoCall" else {
                result(FlutterMethodNotImplemented)
                return
            }
            self.navigateToVideoController(call: call, controller: navigationController)
        })
        
        navigationController.isNavigationBarHidden = true
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()
    }
    
    func navigateToVideoController (call: FlutterMethodCall, controller: UINavigationController) {
        let info = self.getChannelArguments(call: call)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let container = storyboard.instantiateViewController(withIdentifier: "VideoCallViewController") as? VideoCallViewController {
            container.callInfo = info
            let tempVC = container.getNavigationBarWithCloseButton()
            controller.present(tempVC, animated: true, completion: nil)
        }
    }
    
    func getChannelArguments(call: FlutterMethodCall) -> CallInfo? {
        guard let args = call.arguments else { return nil }
        if let myArgs = args as? [String: Any] {
            let appointmentId = myArgs["appointmentId"] as? String
            let isPatient = myArgs["isPatient"] as? Int
            let doctorId =  myArgs["doctorId"] as? String
            let patientId = myArgs["patientId"] as? String
            let doctorImageUrl = myArgs["doctorImageUrl"] as? String
            let patientImageUrl = myArgs["patientImageUrl"] as? String
            let doctorName = myArgs["doctorName"] as? String
            let patientName = myArgs["patientName"] as? String
            let endtime = myArgs["endTime"] as? Int
            
            let info = CallInfo(appointmentId: appointmentId!, isPatient: isPatient!, doctorId: doctorId!, patientId: patientId!, doctorImageUrl: doctorImageUrl, patientImageUrl: patientImageUrl, doctorName: doctorName!, patientName: patientName!, endtime: endtime!)
            return info
        }
        return nil
    }
    
}
