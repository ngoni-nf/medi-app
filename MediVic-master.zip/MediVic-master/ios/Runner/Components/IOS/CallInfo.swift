//
//  CallInfo.swift
//  Runner
//
//  Created by Anish on 9/27/20.
//  Copyright © 2020 The Chromium Authors. All rights reserved.
//

import Foundation

struct CallInfo {
    let appointmentId: String
    let isPatient: Int
    let doctorId: String
    let patientId: String
    let doctorImageUrl: String?
    let patientImageUrl: String?
    let doctorName: String
    let patientName: String
    let endtime: Int
}
