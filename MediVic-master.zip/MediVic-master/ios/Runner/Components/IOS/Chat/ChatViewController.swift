//
//  ChatViewController.swift
//  Runner
//
//  Created by Anish Parajuli on 27/9/20.
//

import UIKit
import MessageKit
import InputBarAccessoryView
import Firebase

class ChatViewController: MessagesViewController, MessagesLayoutDelegate {
    
    var callInfo: CallInfo?
    var messages: [ChatMessage] = []
    let db = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureMessageInputBar()
        configureMessageCollectionView()
        loadMessages()
        setUpRealTimeUpdatesListener()
    }
    
    func loadMessages() {
        let ref = db.collection("messages")
        let query = ref.whereField("doctorId", isEqualTo: callInfo!.doctorId)
            .whereField("userId", isEqualTo: callInfo!.patientId)
        query.getDocuments() { (querySnapshot, err) in
            if err == nil {
                self.processDocumentSnapshot(snapShot: querySnapshot)
            }
        }
    }
    
    func reloadChatView() {
        DispatchQueue.global(qos: .userInitiated).async {
            DispatchQueue.main.async {
                self.messagesCollectionView.reloadData()
                self.messagesCollectionView.scrollToBottom()
            }
        }
    }
    
    func setUpRealTimeUpdatesListener () {
        let ref = db.collection("messages")
        let query = ref.whereField("doctorId", isEqualTo: callInfo!.doctorId)
            .whereField("userId", isEqualTo: callInfo!.patientId)
        query.addSnapshotListener { documentSnapshot, error in
            if let err = error {
                self.displayErrorMessage(msg: err.localizedDescription ?? "Something went wrong while fetching latest messages")
            } else  {
                self.processDocumentSnapshot(snapShot: documentSnapshot)
            }
        }
    }
    
    func processDocumentSnapshot(snapShot: QuerySnapshot?) {
        var tempMessages: [ChatMessage] = []
        guard let document = snapShot else {
            print("Error fetching document")
            return
        }
        for document in document.documents {
            let data = document.data()
            print(data)
            if let date =  data["createdAt"] as? Double, let sender = data["sender"] as? Int,  let msg = data["text"]as? String {
                let msg = ChatMessage(createdAt: date, doctorId: self.callInfo!.doctorId, patientId: self.callInfo!.patientId, sender: sender, text: msg, callInfo: callInfo!)
                tempMessages.append(msg)
            }
        }
        tempMessages.sort{$0.sentDate < $1.sentDate}
        self.messages = tempMessages
        self.reloadChatView()
    }
    
    func configureMessageCollectionView() {
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesLayoutDelegate = self
        messagesCollectionView.messagesDisplayDelegate = self
        let layout = messagesCollectionView.collectionViewLayout as? MessagesCollectionViewFlowLayout
        layout?.setMessageOutgoingAvatarSize(.zero)
        layout?.setMessageIncomingAvatarSize(.zero)
    }
    
    func configureMessageInputBar() {
        messageInputBar.delegate = self
        messageInputBar.sendButton.title = "Send"
        messageInputBar.inputTextView.placeholder = "Enter Message"
        messageInputBar.sendButton.setSize(CGSize(width: 36, height: 36), animated: false)
    }
}

extension ChatViewController: MessagesDataSource {
    func currentSender() -> SenderType {
        if (callInfo!.isPatient == 1) {
            return Sender(senderId: callInfo!.patientId, displayName: callInfo!.patientName)
        } else {
            return Sender(senderId: callInfo!.doctorId, displayName: callInfo!.doctorName)
        }
    }
    
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
        return messages[indexPath.row]
    }
    
    func numberOfSections(in messagesCollectionView: MessagesCollectionView) -> Int {
        return 1
    }
    
    func numberOfItems(inSection section: Int, in messagesCollectionView: MessagesCollectionView) -> Int {
        return messages.count
    }
}

extension ChatViewController: MessagesDisplayDelegate {
    func configureAvatarView(_ avatarView: AvatarView, for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) {
        avatarView.isHidden = true
    }
}

extension ChatViewController: InputBarAccessoryViewDelegate {
    
    @objc func inputBar(_ inputBar: InputBarAccessoryView, didPressSendButtonWith text: String) {
        processInputBar(messageInputBar)
    }
    
    func processInputBar(_ inputBar: InputBarAccessoryView) {
        let components = inputBar.inputTextView.text
        inputBar.invalidatePlugins()
        inputBar.sendButton.startAnimating()
        inputBar.inputTextView.placeholder = "Sending..."
        inputBar.inputTextView.resignFirstResponder()
        DispatchQueue.global(qos: .default).async {
            DispatchQueue.main.async { [weak self] in
                self?.insertMessages(components ?? "", inputBar: inputBar)
            }
        }
    }
    
    private func insertMessages(_ data: String, inputBar: InputBarAccessoryView) {
        var ref: DocumentReference? = nil
        let timeStamp = Timestamp()
        let seconds = timeStamp.seconds * 1000
        let nanoSeconds = Int64(timeStamp.nanoseconds / 1000000)
        let createdAt = Int(seconds + nanoSeconds)
        ref = db.collection("messages").addDocument(data: [
            "doctorId": callInfo!.doctorId,
            "sender": callInfo!.isPatient,
            "createdAt": createdAt,
            "userId": callInfo!.patientId,
            "text": data
        ]) { err in
            if let err = err {
                self.displayErrorMessage(msg: err.localizedDescription)
                inputBar.sendButton.stopAnimating()
            } else {
                inputBar.inputTextView.text = String()
                inputBar.sendButton.stopAnimating()
                inputBar.inputTextView.placeholder = "Enter message"
                print("Document added with ID: \(ref!.documentID)")
            }
        }
    }
}

