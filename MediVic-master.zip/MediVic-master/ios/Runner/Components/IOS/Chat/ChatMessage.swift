//
//  ChatMessage.swift
//  Runner
//
//  Created by Anish Parajuli on 27/9/20.
//

import Foundation
import MessageKit

public struct Sender: SenderType, Equatable {
    public let senderId: String
    public let displayName: String
}

struct ChatMessage: MessageType {
    var sender: SenderType
    var messageId: String
    var sentDate: Date
    var kind: MessageKind
    
    init(createdAt: Double, doctorId: String, patientId: String, sender: Int, text: String, callInfo: CallInfo ) {
        if (sender == 1) {
            self.sender = Sender(senderId: patientId, displayName: callInfo.patientName)
        } else {
            self.sender = Sender(senderId: doctorId, displayName: callInfo.doctorName)
        }
        messageId = ""
        sentDate = Date(timeIntervalSince1970: createdAt)
        kind = .text(text)
    }
}
