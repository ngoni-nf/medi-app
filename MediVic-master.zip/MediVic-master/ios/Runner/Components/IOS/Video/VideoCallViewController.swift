//
//  VideoCallViewController.swift
//  Runner
//
//  Created by Anish Parajuli on 27/9/20.
//

import UIKit
import OpenTok

class VideoCallViewController: UIViewController {
    
    @IBOutlet weak var endCallButton: UIButton!
    @IBOutlet weak var muteButton: UIButton!
    @IBOutlet weak var messageButton: UIButton!
    @IBOutlet weak var flipCameraButton: UIButton!
    @IBOutlet weak var selfImageViewContainer: UIView!
    @IBOutlet weak var selfImageView: UIImageView!
    @IBOutlet weak var notificationContainer: UIView!
    @IBOutlet weak var notificationLabel: UILabel!
    @IBOutlet weak var videoContainerView: UIView!
    @IBOutlet var subscriberImageView: UIImageView!
    
    private let notificationTimerTime = 1.0
    private let notificationAnimationDuration = 1.0
    private var draggableCenter: CGPoint? = nil
    var callInfo: CallInfo!
    var session: OTSession?
    var publisher: OTPublisher?
    var subscriber: OTSubscriber?
    var secondsLeft = 30

    
    //MARK: Waiting View
    @IBOutlet var waitingContainerView: UIView!
    @IBOutlet var waitingImageView: UIImageView!
    @IBOutlet var waitingNameLabel: UILabel!
    @IBOutlet var waitingCloseButton: UIButton!
    
    @IBAction func waitingCloseButtonAction(_ sender: UIButton) {
        closeVideoView()
    }
    
    var firstTimer: Timer?
    var secondTimer: Timer?
    
    //MARK:- LifeCycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        setupWaitingView()
        setupSessionTimer()
        let handler = OpenTokSessionHandler()
        handler.getOpenTokSessionId(forAppointment: callInfo!.appointmentId) {[weak self] (model, error)  in
            guard let strongSelf = self else  {return}
            if let err = error {
                self?.displayErrorMessage(msg: err.localizedDescription)
            } else if let obj = model {
                strongSelf.connectToAnOpenTokSession(apiKey: obj.apiKey, sessionId: obj.sessionId, token: obj.token)
            } else {
                self?.displayErrorMessage(msg: "Couldnot Initialize Opentok session")
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if session != nil {
            session?.disconnect(nil)
            session = nil
        }
        
        if publisher != nil {
            publisher = nil
        }
        
        if subscriber != nil {
            subscriber = nil
        }
        
        invalidateFirstTimer()
        invalidateSecondTimer()
    }
    
    func invalidateFirstTimer() {
        if firstTimer != nil {
            firstTimer?.invalidate()
            firstTimer = nil
        }
    }
    
    func invalidateSecondTimer() {
        if secondTimer != nil {
            secondTimer?.invalidate()
            secondTimer = nil
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if let center = draggableCenter {
            selfImageViewContainer.center = center
        }
    }
    
    func connectToAnOpenTokSession(apiKey: String, sessionId: String, token: String) {
        session = OTSession(apiKey: apiKey, sessionId: sessionId, delegate: self)
        var error: OTError?
        session?.connect(withToken: token, error: &error)
        if let err = error {
            self.displayErrorMessage(msg: err.localizedDescription)
        }
    }
    
    func getData(from url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
    }
    
    func setupWaitingView() {
        //Only for patient
        if(callInfo.isPatient == 1) {
            if let patientImage = callInfo.patientImageUrl {
                waitingImageView.downloaded(from: patientImage)
            }
            waitingNameLabel.text = callInfo.patientName
            let yOffSet = self.navigationController?.navigationBar.frame.height ?? 64
            waitingContainerView.frame = CGRect(x: 0, y:yOffSet,  width: view.bounds.width, height: view.bounds.height - (2 * yOffSet))
            view.addSubview(waitingContainerView)
        }
    }
    
    func resetWaitingView() {
        waitingContainerView.removeFromSuperview()
    }
    
    func setupView() {
        selfImageViewContainer.layer.cornerRadius = 4.0
        muteButton.layer.cornerRadius = 22
        endCallButton.layer.cornerRadius = 22
        messageButton.layer.cornerRadius = 22
        flipCameraButton.layer.cornerRadius = 22
        muteButton.backgroundColor = .gray
        messageButton.backgroundColor = .green
        flipCameraButton.backgroundColor = .gray
        endCallButton.backgroundColor = .red
        notificationContainer.isHidden = true
        selfImageViewContainer.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(self.panImageView(_:))))
        if callInfo!.isPatient == 1 {
            if let patientImage = callInfo.patientImageUrl {
                selfImageView.downloaded(from: patientImage)
            }
            if let subscriberImage = callInfo.doctorImageUrl {
                subscriberImageView.downloaded(from: subscriberImage)
            }
        }else {
            if let subscriberImage = callInfo.doctorImageUrl {
                selfImageView.downloaded(from: subscriberImage)
            }
            if let patientImage = callInfo.patientImageUrl {
                subscriberImageView.downloaded(from: patientImage)
            }
        }
    }
    
    func setupSessionTimer() {
        let startTime = Date()
        let endTime = Date.init(timeIntervalSince1970: TimeInterval(callInfo.endtime/1000))
        
        let timeDifference = endTime.timeIntervalSince(startTime)
        let whenToAlert = timeDifference - 30
        firstTimer = Timer.scheduledTimer(timeInterval: whenToAlert, target: self, selector: #selector(self.myMethod), userInfo: nil, repeats: false)
        
    }

    @objc func myMethod() {
        invalidateFirstTimer()
        self.showNotification(with: "\(secondsLeft) seconds left")
        self.secondTimer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(self.secondTimerAction), userInfo: nil, repeats: true)
    }
    
    @objc func secondTimerAction() {
        secondsLeft -= 5
        let endTime = Date.init(timeIntervalSince1970: TimeInterval(callInfo.endtime/1000))
        self.showNotification(with: "\(secondsLeft) seconds left")
        if(Date() >= endTime) {
            invalidateSecondTimer()
            self.navigationController?.dismiss(animated: true, completion: nil)
        }
    }
    
    //MARK:- IBActions
    @IBAction func endCallButtonAction(_ sender: Any) {
        closeVideoView()
    }
    
    @IBAction func muteButtonAction(_ sender: Any) {
        if let isAudioOn = publisher?.publishAudio, isAudioOn {
            muteButton.setImage(UIImage(named: "mic_off"), for: [])
            publisher?.publishAudio = false
        } else  {
            muteButton.setImage(UIImage(named: "mic_on"), for: [])
            publisher?.publishAudio = true
        }
    }
    
    @IBAction func messageButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let container = storyboard.instantiateViewController(withIdentifier: "ChatViewController") as? ChatViewController else {return}
        let nav = container.getNavigationBarWithCloseButton()
        (nav.topViewController as? ChatViewController)?.callInfo = callInfo
        self.present(nav, animated: true, completion: nil)
    }
    
    @IBAction func flipCameraButtonAction(_ sender: Any) {
        if let pos = publisher?.cameraPosition, pos == .back  {
            publisher?.cameraPosition = AVCaptureDevice.Position.front
        } else if let pos = publisher?.cameraPosition, pos == .front {
            publisher?.cameraPosition = AVCaptureDevice.Position.back
        }
    }
    
    func showNotification(with message: String) {
        UIView.animate(withDuration: notificationAnimationDuration) {
            self.notificationLabel.text = message
            self.notificationContainer.isHidden = false
        } completion: { (completion) in
            Timer.scheduledTimer(timeInterval: self.notificationTimerTime, target: self, selector: #selector(self.hideNotification), userInfo: nil, repeats: false)
        }
    }
    
    @objc func hideNotification() {
        self.notificationLabel.text = ""
        self.notificationContainer.isHidden = true
    }
    
    @objc func panImageView(_ sender: UIPanGestureRecognizer) {
        let translation = sender.translation(in: self.view)
        
        if let viewToDrag = sender.view {
            let viewWidth = viewToDrag.bounds.width
            let viewHeight = viewToDrag.bounds.height
            
            var newCenterX = viewToDrag.center.x + translation.x
            var newCenterY = viewToDrag.center.y + translation.y
            
            if(newCenterX + viewWidth/2 > self.view.bounds.width) {
                newCenterX = self.view.bounds.width  - viewWidth/2
            }
            
            if(newCenterX < viewWidth/2) {
                newCenterX =  viewWidth/2
            }
            
            if(newCenterY + viewHeight/2 > self.view.bounds.height) {
                newCenterY = self.view.bounds.height  - viewHeight/2
            }
            
            if(newCenterY < viewHeight/2) {
                newCenterY =  viewHeight/2
            }
            
            let newCenter = CGPoint(x: newCenterX, y: newCenterY)
            draggableCenter = newCenter
            
            UIView.transition(with: viewToDrag, duration: 0.1, options:.allowUserInteraction) {
                viewToDrag.center = newCenter
                sender.setTranslation(CGPoint(x: 0, y: 0), in: viewToDrag)
            }
        }
    }
    
    @objc private func closeVideoView() {
        let alert = UIAlertController(title: "Alert", message: "Are you sure you want to close the session?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { action in
            self.navigationController?.dismiss(animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
}

//MARK: OTSessionDelegate
extension VideoCallViewController: OTSessionDelegate {
    func sessionDidConnect(_ session: OTSession) {
        let settings = OTPublisherSettings()
        settings.name = UIDevice.current.name
        guard let publisher = OTPublisher(delegate: self, settings: settings) else { return }
        
        self.publisher = publisher
        var error: OTError?
        session.publish(publisher, error: &error)
        guard error == nil else { print(error!); return}
        guard let publisherView = publisher.view else { return }
        publisherView.frame = selfImageViewContainer.bounds
        selfImageViewContainer.addSubview(publisherView)
    }
    
    func sessionDidDisconnect(_ session: OTSession) {
        print("The client disconnected from the OpenTok session.")
    }
    
    func session(_ session: OTSession, didFailWithError error: OTError) {
        print("The client failed to connect to the OpenTok session: \(error).")
    }
    
    func session(_ session: OTSession, streamCreated stream: OTStream) {
        subscriber = OTSubscriber(stream: stream, delegate: self)
        guard let subscriber = subscriber else {return}
        var error: OTError?
        session.subscribe(subscriber, error: &error)
        guard error == nil else {print(error!) ; return }
        guard let subscriberView = subscriber.view else { return }
        subscriberView.frame = videoContainerView.bounds
        videoContainerView.addSubview(subscriberView)
    }
    
    func session(_ session: OTSession, streamDestroyed stream: OTStream) {
        print("A stream was destroyed in the session.")
    }
    
}

// MARK: - OTPublisherDelegate callbacks
extension VideoCallViewController: OTPublisherDelegate {
    func publisher(_ publisher: OTPublisherKit, didFailWithError error: OTError) {
        self.displayErrorMessage(msg: error.localizedDescription)
    }
}

// MARK: - OTSubscriberDelegate callbacks
extension VideoCallViewController: OTSubscriberDelegate {
    public func subscriberDidConnect(toStream subscriber: OTSubscriberKit) {
        print("The subscriber did connect to the stream.")
        resetWaitingView()
    }
    
    public func subscriber(_ subscriber: OTSubscriberKit, didFailWithError error: OTError) {
        self.displayErrorMessage(msg: error.localizedDescription)
    }
}
