//
//  UIViewController.swift
//  Runner
//
//  Created by Anish Parajuli on 9/27/20.
//  Copyright © 2020 The Chromium Authors. All rights reserved.
//

import UIKit

extension UIViewController {
    
    func getNavigationBarWithCloseButton() -> UINavigationController {
        let navigationController: UINavigationController = UINavigationController(rootViewController: self)
        navigationController.navigationBar.isTranslucent = true
        self.addCloseBtn()
        return navigationController
    }
    
    func addCloseBtn() {
        let barButtonItem = UIBarButtonItem(image: UIImage(named:"close"), style: .plain, target: self, action: #selector(closeView))
        barButtonItem.tintColor = UIColor.black
        self.navigationItem.rightBarButtonItem = barButtonItem
    }

    @objc private func closeView() {
        self.navigationController?.dismiss(animated: true, completion: nil)
    }
    
    func displayErrorMessage(msg: String) {
        let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
    }

}
