//
//  OpenTokSessionHandler.swift
//  Runner
//
//  Created by Anish on 9/27/20.
//  Copyright © 2020 The Chromium Authors. All rights reserved.
//

import Foundation

class OpenTokSessionHandler {
    
    var dataTask: URLSessionDataTask?
    
    func getOpenTokSessionId(forAppointment id: String, completionHandler: @escaping (OpenTokKey?, Error?) -> ()) {
        let defaultSession = URLSession(configuration: .default)
        dataTask?.cancel()
        
        let appointMentId = id
        if var urlComponents = URLComponents(string: "https://us-central1-medivic-aa5d3.cloudfunctions.net/generateVonageToken") {
            urlComponents.query = "appointmentId=\(appointMentId)"
            guard let url = urlComponents.url else {
                return
            }
            dataTask = defaultSession.dataTask(with: url) { [weak self] data, response, error in
                defer {
                    self?.dataTask = nil
                }
                if let error = error {
                    completionHandler(nil, error)
                } else if
                    let data = data,
                    let response = response as? HTTPURLResponse,
                    response.statusCode == 200 {
                    let jsonDecoder = JSONDecoder()
                    if let tokenObj = try? jsonDecoder.decode(OpenTokKey.self, from: data) {
                        DispatchQueue.main.async {
                            completionHandler(tokenObj,nil)
                        }
                    }
                }
            }
            dataTask?.resume()
        }
    }
}
