//
//  OpenTokKey.swift
//  Runner
//
//  Created by Anish on 9/27/20.
//  Copyright © 2020 The Chromium Authors. All rights reserved.
//

import Foundation

struct OpenTokKey: Codable {
    var apiKey: String
    var sessionId: String
    var token: String
}
